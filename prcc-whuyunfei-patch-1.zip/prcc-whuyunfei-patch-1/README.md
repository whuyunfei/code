# Pseudorandom Cyclic Codes (PRCC)

Working paper + experiment scaffold for a **rotation-tolerant zero-bit image watermark**
built from a **block-circulant** parity-check code, a two-coset **lattice** spatial
carrier, and a small **two-center × residual-angle** detector search.

## Status

- Full \(n\times n\) circulant candidate **retracted** (trivial kernel at default params).
- Locked detector **C**: \(m=64\), \(w=1\), \(\eta=0\), two centers \(\times L=8\),
  lattice step \(\approx 0.1416\) (median PSNR \(\approx 38\,\mathrm{dB}\) on tested configs).
- Hold-out confirmation: **5/5** keys on COCO `train2017` confirm split
  (`figures/confirm_holdout.json`).
- Formal JPEG protocol: **mixed-Q calibration** for every key; Q70-only is migration only
  (`experiments/src/bench_jpeg_unified.py`).
- Paper draft: `paper/main.tex` (methods + experiments + abstract/intro aligned to C).
  Performance claims at \(\eta=0\); no unverified PR / undetectability claims.

## Repo layout

- `paper/` — LaTeX source (`main.tex`)
- `experiments/` — Python reference implementation and scripts
- `notes/` — definition, construction, and round exit notes
- `figures/` — JSON/PNG result artifacts cited in the paper
- `vendor/` — optional PRC-Watermark clone (gitignored)

## Quick start

```bash
cd experiments
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python3 -m src.bootstrap_images
python3 -m pytest tests/ -q
```

Method/experiments outline: `notes/paper-method-experiments.md`.  
Performance boundary index: `notes/round-performance-boundary.md`.

## Citation

Draft only — do not cite publicly until authors finalize.
