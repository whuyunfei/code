# PRCC Construction Attempts (revised)

Aligned with `notes/PRCC-definition-aligned.md`  
Group action: simultaneous ring shift \(T_k\). Robustness: \(\mathrm{BSC}_p\) in v1.

---

## Attempt A0 — Full \(n\times n\) circulant (RETRACTED)

### Idea
Secret weight-\(w\) generator \(h\); \(H\) full circulant; encode from \(\ker H\) + noise; detect on syndrome weight.
Then \(HR_k=R_kH\), so Detect is shift-invariant.

### Failure
For \(n=2^\ell\), \(X^n-1=(X+1)^n\). Odd \(w\) ⇒ \(h(1)=1\) ⇒ \(H\) invertible ⇒ \(\ker H=\{0\}\).
Default params \(n=256,w=7\) collapse encoding to \(\Bern(\eta)\); small \(\eta\) breaks (P) by Hamming weight.
Even \(w\) avoids only this argument; kernels usually remain tiny.
Greedy low-syndrome sampling ≠ kernel sampling; observed syndrome weights can exceed \(\tau\).

### Verdict
**Keep as reproducible counterexample / regression test.** Not a candidate.

---

## Attempt A1 — Block-circulant under \(T_k\) (PRIMARY)

### Idea
\(b\) rings, \(m\) angular samples, \(n=bm\).
\[
H=[A_1\mid\cdots\mid A_b],\qquad A_j\text{ circulant }m\times m.
\]
Then \(HT_k=R_kH\). Require \(A_b\) invertible in the circulant algebra for systematic encoding.
Encode into coset \(Hc=\mathbf{1}\) (rotation-invariant target) + \(\Bern(\eta)\).
Detect: \(\mathrm{wt}(Hy+\mathbf{1})\le\tau\).

### Why this matches geometry
Image rotation shifts all rings by the same angle; \(T_k\) is the natural action, not a global length-\(n\) shift of the concatenation.

### Algebra
- \(\dim\ker H\ge (b-1)m\); equality when \(A_b\) invertible.
- Full rank ⇒ \(HU\) uniform on \(\mathbb{F}_2^m\) ⇒ binomial soundness.
- Effective BSC rate \(p'=\eta(1-p)+(1-\eta)p\); marginal syndrome flip \(q(p',W)\) with \(W=\sum w_j\).
- Syndrome bits dependent: do not use independent Chernoff for (R); report expectation gap + empirical tails (McDiarmid too loose at watermark scale for negl claims).
- \(\eta=0\) is insecure: evaluation / gcd distinguishers on units.

### Mapping to axioms
| Axiom | Status |
|-------|--------|
| (C) | Yes, via \(HT_k=R_kH\) and coset \(\mathbf{1}\) |
| (S) | Yes under full rank + \(\tau\ll m/2\) |
| (P) | Conjectural structured/QC-LPN for \(\eta>0\); \(\eta=0\) fails |
| (R) | Expectation budget + experiments; no negl claim from independence |

### Verdict
**Proceed as primary.** Implement systematic encoder; compare to ring-OR PRC baseline after geometry gate.

---

## Attempt B — Ring-OR PRC baseline (COMPARISON)

### Idea
Keep any zero-bit sparse-syndrome PRC encoder; detect with
\[
D_{\mathrm{ring}}(y)=\bigvee_{k=0}^{m-1} D_{\mathrm{PRC}}(T_k y).
\]
(Not global length-\(n\) OR, which mismatches geometry and inflates FPR to \(n\varepsilon\).)

### Mapping
(P) inherited; (C)/(R) for exact \(T_k\)+\(\mathrm{BSC}_p\) inherited up to union-bound FPR \(m\varepsilon\).
Cost: \(m\) sparse matvecs vs one structured matvec.

### Verdict
**Mandatory baseline.** PRCC must win on runtime or detection under matched FPR/\(p\).

---

## Attempt C — Rotation-invariant features only (DOWNGRADED)

Amplitude-only ring templates. Not a PRCC (fails bit pseudorandomness story).

---

## Attempt D — Message on cyclic group (EXTENSION)

Defer until zero-bit A1 works.

---

## Experimental gate order

1. Reproduce A0 counterexample (full rank + greedy wt).
2. Algebra tests for A1 (kernel, invariance, \(\mathbf{1}\) coset, \(\eta=0\) distinguisher).
3. **Geometry first:** random-bit embed–rotate–extract BER (half-bin critical).
4. If half-bin BER high (\(\gtrsim 0.4\)): stop coding claims; redesign embed.
5. If half-bin BER low (\(\lesssim 0.15\)): compare A1 vs Attempt B under empirical \(p\).

### Geometry readings (toy)

**FFT-ring point/sector paint (Cartesian bins):** angle 0 OK; \(90^\circ\) mostly OK; half-bin grid-aligned BER stays \(\sim 0.4\)–\(0.5\) even after fixing alignment sign and trying exclusive sectors. Discrete FFT coefficients do not survive fractional rotation as a cyclic bit shift.

**Spatial annulus exclusive sectors (redesign):** with known-angle grid alignment, half-bin **gridBER \(\approx 0\)** (pad/crop). Gate → `compare_codes`.
Integer-only bit roll at half-bin still looks like \(\sim 1/2\) BER — a practical detector must search a fine angular grid (keyed soft score), not only \(m\) discrete \(T_k\).
Blind sync by maximizing \(\sum|\mathrm{soft}|\) without a key fails; keyed PRCC/PRC detection can absorb continuous angle search.
