# 探索总览（收敛）

早期五阶段与可靠信道 / 低 FPR / 改结构轮次见各 `phase*.md`、`round-*.md`。  
**当前主线已收敛到可写方法与实验的块循环抗旋转原型。**

## 收敛结论

- **工作点：** 约 38 dB（已测试配置中最高达标）、两中心×L=8、m=64,w=1,η=0。  
- **确认：** 新图 5/5 钥。  
- **JPEG：** 正式用预先规定的 mixed-Q 单一阈值；检测不按 Q 换阈值。  
- **相对 PRC：** 码检 64×、码时间 ≈50×、总时间 ≈2.1×（分项报告）。  
- **边界：** 额外平移 ≥0.5 px 失效。

提纲与写作约束：[paper-method-experiments.md](paper-method-experiments.md)  
数字总览：[round-performance-boundary.md](round-performance-boundary.md)
