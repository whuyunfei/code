# Pseudorandom Cyclic Code (PRCC) — Aligned Definition

**Status:** Revised 2026-10-07 after full-circulant counterexample review  
**Name:** Pseudorandom Cyclic Code (PRCC); not a standard PRC

## Locked design choices

| Item | Choice |
|------|--------|
| Alphabet | \(\Sigma = \{0,1\}\) |
| Length | \(n = b m\) (\(b\) rings, \(m\) angular samples) |
| Group action | Simultaneous ring shift \(T_k=\mathrm{diag}(R_k,\ldots,R_k)\), \(k\in\mathbb{Z}/m\mathbb{Z}\) |
| Equivariance strength | **Detect-sense** under \(T_k\) |
| Primary object | **Zero-bit PRCC** |
| Message version | Extension only |
| Pseudorandomness | **Single-sample** first (multi-sample is a comparison target) |
| Robustness (R) | **\(\mathrm{BSC}_p\) in v1**; worst-case \(p\)-bounded deferred |

## Motivation (watermark)

Concentric DFT rings do **not** induce a single global cyclic shift of the concatenated \(bm\)-bit string.
Image rotation (ideally) applies the **same** angular shift to every ring:
\[
T_k=\operatorname{diag}(R_k,\ldots,R_k).
\]
Detection with \(sk\) should accept without estimating the angle. This is **not** standard PRC (which targets substitution/deletion after alignment).

Extraction noise acts like bit substitutions on the rings, so cyclic+BSC robustness is part of the main definition.
Uniform-string soundness does **not** imply low FPR on unmarked image extractions (bits need not be uniform). Homogeneous syndrome detectors always accept the all-zero string.

---

## Preliminaries

- Security parameter \(\lambda\), rings \(b\ge 2\), angular length \(m\), \(n=bm\).
- Length-\(m\) cyclic shift: \((R_k x)_i = x_{i-k\bmod m}\).
- Simultaneous action \(T_k\) as above.
- Uniform string: \(U\leftarrow\{0,1\}^n\).
- \(\mathrm{BSC}_p\): independent bit flips with probability \(p\).

---

## Main definition: Zero-bit PRCC

**Syntax.** \((\mathsf{KeyGen}, \mathsf{Encode}, \mathsf{Detect})\).

### (C) Completeness / Detect-sense \(T_k\)-closure

\[
\forall\, k\in\mathbb{Z}/m\mathbb{Z}:\quad
\Pr\bigl[\mathsf{Detect}(sk, T_k(\mathsf{Encode}(sk))) = 1\bigr] \ge 1 - \mathsf{negl}(\lambda).
\]

### (S) Soundness (uniform strings only)

\[
\Pr\bigl[\mathsf{Detect}(sk, U) = 1\bigr] \le \mathsf{negl}(\lambda).
\]

### (P) Pseudorandomness (single-sample)

One sample without \(sk\) is indistinguishable from uniform. Multi-sample under one \(sk\) deferred / comparison target.

### (R) Robustness under \(\mathrm{BSC}_p\)

\[
\forall\, k\in\mathbb{Z}/m\mathbb{Z}:\quad
\Pr\bigl[\mathsf{Detect}(sk, \mathrm{BSC}_p(T_k(\mathsf{Encode}(sk)))) = 1\bigr] \ge 1 - \mathsf{negl}(\lambda).
\]

### Trivial baseline

\[
D_{\mathrm{ring}}(y)=\bigvee_{k=0}^{m-1} D_{\mathrm{PRC}}(T_k y).
\]
Encoder unchanged ⇒ (P) inherited; FPR \(\le m\varepsilon\). A useful PRCC must reduce detection cost or improve end-to-end metrics under matched FPR/attack.

---

## Application seam (research hypothesis)

\[
v(\Pi_\theta(x))\approx T_{k(\theta)}(v(x))
\]
is **not** automatic: fractional shifts, interpolation, crop/pad, conjugate symmetry, and diffusion inversion can break it.
Measure residual BER (especially half angular bin) before claiming a watermark scheme.
Bit pseudorandomness \(\not\Rightarrow\) image undetectability.

---

## Related context

- Distinct from Christ–Gunn PRC and follow-ons
- Distinct from RingID / Tree-Ring engineering
- Full \(n\times n\) circulant candidate **retracted** (trivial kernel at \(n=2^\ell\), odd \(w\))
- Primary construction: **block-circulant** \(H=[A_1\mid\cdots\mid A_b]\) with coset \(Hc=\mathbf{1}\)
