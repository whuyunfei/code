# 性能边界总览（基线 C 起，收敛口径）

**检测器 C：** m=64,w=1,η=0，两中心×L=8，256，pad+crop 旋转。  
通过门：随机θ与残余最低 TPR≥90%，两类 FPR 95% 上界≤1%。  
**方法/实验提纲：** [paper-method-experiments.md](paper-method-experiments.md)。

## 结论（可写进论文的表述）

1. **失真工作点：** **已测试配置中的最高达标工作点**约为中位 **38 dB**（step≈0.1416）。  
2. **迁移：** 独立 train2017 确认集上 **5/5 钥**达标。  
3. **JPEG：** 正式方法采用**预先规定的 mixed-Q 校准**冻结每钥单一阈值；检测时不按 Q 切换。实现已对齐（`bench_jpeg_unified` 每钥直接 mixed-Q）。该规则下已测 Q∈{50,60,70,80,90} 均覆盖。Q70 单独校准的 2/3 覆盖仅作迁移实验。  
4. **相对 PRC 的效率（须分三项写）：** 码检调用 **64×**；码时间约 **50×**；含提取总时间约 **2.1×**。  
5. **平移边界：** 额外平移 ≥0.5 px 无可用工作点；两中心只解决裁剪半像素。

## 公平对照的误报脚注

`prc_fair_C` 中 PRCC 第三钥受攻击 FPR 为 10/1500（95% 上界≈1.13%）。  
→ 对照表**不得**写「三钥均满足严格 1% 上界」。调用次数与计时仍成立。若需严格预算下的三钥性能表，对该钥收紧阈值后重报。

## 产物索引

| 内容 | 文件 |
|------|------|
| 提纲 | paper-method-experiments.md |
| 失真扫描 | figures/psnr_scan.*, round-psnr-scan.md |
| 新图确认 | figures/confirm_holdout.json, round-confirm.md |
| PRC 对照 | figures/prc_fair_C.*, round-prc-fair.md |
| 分 Q / 偏移 | figures/attack_boundary.*, round-attack-boundary.md |
| 统一 JPEG | figures/jpeg_unified.json（历史：2 钥 Q70 thr + 1 钥 mixed-Q；代码已改 always-mixed） |
| 模板相关对照 | figures/corr_fair_C.*, round-corr-fair.md |
