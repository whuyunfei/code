"""Pad+crop rotation can shift the content center by half a pixel."""

from __future__ import annotations

import numpy as np

from src.fast_radial import make_layout
from src.lattice_carrier import embed_lattice, extract_lattice
from src.spatial_multiring import (
    apply_attack,
    content_center_after_rot_crop,
    expanded_rotate_shape,
    rotate_keep_center,
)


def test_content_center_parity_matches_expand_shape():
    size = 256
    for ang in (0.176, 1.055, 4.922, 5.625, 11.25, 30.0, 45.0):
        h, w = expanded_rotate_shape(size, ang)
        cy, cx = content_center_after_rot_crop(size, ang)
        expect = (size - 1) / 2.0
        if h % 2 == 0:
            assert cy == expect
        else:
            assert cy == expect + 0.5
        if w % 2 == 0:
            assert cx == expect
        else:
            assert cx == expect + 0.5


def test_true_center_helps_or_matches_on_coco_odd_expand():
    from pathlib import Path

    from src.coco_photos import load_image, split_paths

    paths = split_paths("tune")
    rng = np.random.default_rng(0)
    m, b, size, step = 64, 4, 256, 0.19745071411132814
    layout = make_layout(size, m, b, 0.15, 0.0)
    ang = None
    for a in np.linspace(0.1, 10.0, 40):
        h, w = expanded_rotate_shape(size, float(a))
        if h % 2 == 1:
            ang = float(a)
            break
    assert ang is not None
    bers0, bers1 = [], []
    for path in paths[:12]:
        img = load_image(path, size)
        bits = rng.integers(0, 2, size=(b, m), dtype=np.uint8)
        marked = embed_lattice(img, layout, bits, step)
        attacked = apply_attack(marked, "rot_jpeg", ang, 70, size)
        true_c = content_center_after_rot_crop(size, ang)
        hat0, _ = extract_lattice(attacked, layout, ang, step, center=None)
        hat1, _ = extract_lattice(attacked, layout, ang, step, center=true_c)
        bers0.append(float(np.mean(hat0 != bits)))
        bers1.append(float(np.mean(hat1 != bits)))
    assert float(np.mean(bers1)) <= float(np.mean(bers0))
    assert float(np.mean(bers1)) < 0.02


def test_keep_center_preserves_default_center():
    img = np.zeros((256, 256))
    img[128, 128] = 1.0
    out = rotate_keep_center(img, 15.0)
    assert out.shape == (256, 256)
