"""Two-row H algebra and lattice coset round-trip."""

from __future__ import annotations

import numpy as np

from src.block_circulant import gf2_solve_affine, simultaneous_shift
from src.lattice_carrier import embed_lattice, extract_lattice, nearest_lattice
from src.spatial_multiring import MultiRingLayout, default_annuli
from src.two_row_h import detect_score, encode, keygen_two_row, score_invariant_under_Tk


def test_two_row_full_rank_and_invariant():
    rng = np.random.default_rng(0)
    key = keygen_two_row(m=8, b=4, weights=3, eta=0.0, rng=rng)
    assert key.rank >= 15
    assert key.kernel_dim == 8 * 4 - key.rank
    c = encode(key, rng=rng, add_noise=False)
    assert detect_score(key, c) == 0
    assert score_invariant_under_Tk(key, c)
    # Shifted codeword still score 0
    assert detect_score(key, simultaneous_shift(c, key.m, 3)) == 0


def test_gf2_solve_rejects_bad_target():
    rng = np.random.default_rng(1)
    H = np.zeros((2, 3), dtype=np.uint8)
    H[0, 0] = 1
    H[1, 0] = 1
    try:
        gf2_solve_affine(H, np.array([1, 0], dtype=np.uint8), rng)
        assert False, "expected failure"
    except np.linalg.LinAlgError:
        pass


def test_lattice_roundtrip_on_flat():
    rng = np.random.default_rng(2)
    size = 96
    layout = MultiRingLayout(size, default_annuli(size, 2), m=8, guard_frac=0.15, strength=0.0, mode="qim")
    img = np.full((size, size), 128.0)
    bits = rng.integers(0, 2, size=(2, 8), dtype=np.uint8)
    marked = embed_lattice(img, layout, bits, step=0.05)
    hat, _ = extract_lattice(marked, layout, 0.0, step=0.05)
    assert float(np.mean(hat != bits)) < 0.05


def test_nearest_lattice_does_not_require_sign_flip():
    # Large negative coeff with bit=1 can stay negative on an odd coset point.
    c = np.array([[-0.12]])
    b = np.array([[1]], dtype=np.uint8)
    t = nearest_lattice(c, b, step=0.05)
    assert t[0, 0] < 0
