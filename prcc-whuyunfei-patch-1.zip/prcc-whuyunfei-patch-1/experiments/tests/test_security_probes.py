"""Phase-1 security probe smoke tests."""

from __future__ import annotations

import numpy as np

from src.block_circulant import detect_score, encode, keygen
from src.security_probes import (
    detect_with_constant_reject,
    fixed_inputs,
    probe_fixed_accepts,
    probe_single_sample,
    reject_near_constant_blocks,
)


def test_odd_block_ones_score_zero():
    rng = np.random.default_rng(0)
    key = keygen(m=32, b=4, weights=3, tau=8, eta=0.05, rng=rng)
    y = fixed_inputs(32, 4)["odd_blocks_ones_last"]
    assert detect_score(key, y) == 0
    fa = probe_fixed_accepts(key)
    assert fa["odd_blocks_ones_last"]["accept"] == 1.0


def test_constant_reject_catches_block_ones_keeps_randomish():
    rng = np.random.default_rng(1)
    key = keygen(m=32, b=4, weights=3, tau=8, eta=0.05, rng=rng)
    y = fixed_inputs(32, 4)["odd_blocks_ones_last"]
    assert reject_near_constant_blocks(y, 32)
    assert not detect_with_constant_reject(key, y)
    c = encode(key, rng=rng)
    # Honest noisy codewords are not all near-constant blocks
    assert not reject_near_constant_blocks(c, 32)


def test_weak_b2_w1_has_nonzero_advantage():
    rng = np.random.default_rng(2)
    key = keygen(m=32, b=2, weights=1, tau=4, eta=0.03, rng=rng)
    adv = probe_single_sample(key, rng, n_samples=40)
    assert adv["max_adv"] >= 0.2
