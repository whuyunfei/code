"""Fast radial path matches the sector-mask implementation."""

from __future__ import annotations

import numpy as np

from src.fast_radial import push_to_margin, radial_soft
from src.integer_threshold import clopper_upper, largest_integer_threshold
from src.spatial_multiring import MultiRingLayout, default_annuli, embed_weak, extract_soft, make_bits


def test_fast_radial_matches_sector_masks():
    rng = np.random.default_rng(0)
    size = 96
    layout = MultiRingLayout(size, default_annuli(size, 2), m=8, guard_frac=0.15, strength=0.04, mode="qim")
    img = rng.integers(20, 220, size=(size, size, 3)).astype(np.float64)
    bits = make_bits(layout, rng)
    slow = embed_weak(img, layout, bits)
    fast = push_to_margin(img, layout, bits)
    assert np.allclose(slow, fast, atol=1e-6)
    for ang in (0.0, 11.25, 33.0):
        a = extract_soft(fast, layout, ang)
        b = radial_soft(fast, layout, ang)
        assert np.allclose(a, b, atol=1e-8)


def test_integer_threshold_drops_tied_zero_mass():
    scores = [0, 0, 0] + [5] * 97
    assert largest_integer_threshold(scores, 0.01) is None
    scores = [0] + [5] * 99
    assert largest_integer_threshold(scores, 0.01) == 4


def test_zero_event_upper_bound_near_three_over_n():
    hi = clopper_upper(0, 3000)
    assert 0.0009 < hi < 0.0012
