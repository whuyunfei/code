"""Algebraic regression tests for retracted and block-circulant constructions."""

from __future__ import annotations

import numpy as np
import pytest

from src.block_circulant import (
    circulant_invertible,
    detect,
    detect_score,
    encode,
    eta_zero_distinguisher,
    evaluation_at_one,
    gf2_rank,
    keygen as block_keygen,
    kernel_dimension,
    simultaneous_shift,
    syndrome,
    verify_shift_invariance,
)
from src.circulant_code import encode as greedy_encode
from src.circulant_code import is_full_rank, keygen as full_keygen


def test_full_circulant_counterexample_n256_w7():
    rng = np.random.default_rng(0)
    key = full_keygen(n=256, w=7, tau=30, eta=0.0, rng=rng)
    assert is_full_rank(key)
    assert gf2_rank(key.H) == 256
    # Odd weight generator is a unit when n=2^ell
    assert circulant_invertible(key.h)
    # Ideal ker-sampling collapses: only the zero vector has syndrome 0
    assert np.array_equal((key.H @ np.zeros(256, dtype=np.uint8)) % 2, np.zeros(256, dtype=np.uint8))
    # Limited greedy often fails former tau (spot-check style; not a hard math claim)
    wts = [
        int(((key.H @ greedy_encode(key, rng=rng, max_flips=5_000, restarts=2)) % 2).sum())
        for _ in range(3)
    ]
    print(f"greedy syndrome weights under limited budget: {wts}")


def test_block_kernel_dimension():
    rng = np.random.default_rng(1)
    m, b = 32, 4
    key = block_keygen(m=m, b=b, weights=5, tau=4, eta=0.05, rng=rng)
    assert kernel_dimension(key) == (b - 1) * m
    assert gf2_rank(key.H) == m


def test_block_coset_and_invariance():
    rng = np.random.default_rng(2)
    key = block_keygen(m=16, b=3, weights=3, tau=2, eta=0.0, rng=rng)
    c = encode(key, rng=rng, add_noise=False)
    s = syndrome(key, c)
    assert np.array_equal(s, np.ones(key.m, dtype=np.uint8))
    assert detect_score(key, c) == 0
    ok, scores = verify_shift_invariance(key, c)
    assert ok
    assert all(s == 0 for s in scores)
    for k in range(key.m):
        assert detect(key, simultaneous_shift(c, key.m, k))


def test_eta_zero_distinguisher():
    rng = np.random.default_rng(3)
    key = block_keygen(m=16, b=3, weights=3, tau=2, eta=0.0, rng=rng)
    # Ensure generators evaluate to 1 at X=1 when odd weight
    for h in key.generators:
        assert evaluation_at_one(h) == 1
    c = encode(key, rng=rng, add_noise=False)
    assert eta_zero_distinguisher(c, key.m, key.b, key.generators)
    # Uniform fails about half the time; check many samples average near 1/2
    hits = 0
    trials = 200
    for _ in range(trials):
        u = rng.integers(0, 2, size=key.b * key.m, dtype=np.uint8)
        hits += int(eta_zero_distinguisher(u, key.m, key.b, key.generators))
    rate = hits / trials
    assert 0.35 <= rate <= 0.65


def test_reject_all_zero():
    rng = np.random.default_rng(4)
    key = block_keygen(m=16, b=3, weights=3, tau=2, eta=0.05, rng=rng)
    z = np.zeros(key.b * key.m, dtype=np.uint8)
    # H*0+1 has weight m > tau
    assert detect_score(key, z) == key.m
    assert not detect(key, z)


def test_soundness_uniform_tail_small():
    rng = np.random.default_rng(5)
    key = block_keygen(m=32, b=4, weights=5, tau=4, eta=0.05, rng=rng)
    accept = 0
    trials = 500
    for _ in range(trials):
        u = rng.integers(0, 2, size=key.b * key.m, dtype=np.uint8)
        accept += int(detect(key, u))
    # Bin(32,1/2) <= 4 is tiny
    assert accept / trials < 0.05
