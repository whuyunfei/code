"""JPEG range, constant-block filtering, and radial coefficient."""

from __future__ import annotations

import numpy as np

from src import block_circulant as bc
from src.bench_fair_compare import extraction_shift_sign, reuse_matches_reextract
from src.residual_search import SearchResult, passes_lower, select_valid_candidate
from src.soft_detect import bit_probs, fit_logistic, shift_invariant
from src.spatial_multiring import (
    MultiRingLayout,
    default_annuli,
    embed_weak,
    extract_soft,
    jpeg_compress,
    make_bits,
)


def test_jpeg70_keeps_gradient_range():
    g = np.linspace(20, 230, 64 * 64).reshape(64, 64)
    out = jpeg_compress(g, 70)
    assert out.min() < 40
    assert out.max() > 200
    assert out.mean() < 200
    assert not np.all(out > 250)


def test_jpeg70_unit_interval_not_white():
    g = np.linspace(0.1, 0.9, 32 * 32).reshape(32, 32)
    out = jpeg_compress(g, 70)
    assert out.max() <= 1.0 + 1e-6
    assert out.min() < 0.3
    assert out.max() > 0.7


def test_select_skips_constant_block_score_zero():
    m = 8
    y_const = np.ones(m * 2, dtype=np.uint8)
    y_other = np.array([1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0], dtype=np.uint8)
    best, y, idx, n_valid = select_valid_candidate(
        [(0.0, y_const), (3.0, y_other)], m, constant_reject=True
    )
    assert n_valid == 1
    assert idx == 1
    assert best == 3.0
    assert y is y_other
    empty = SearchResult(float("nan"), float("inf"), False, [], [], n_valid=0)
    assert not passes_lower(empty, 0.0)


def test_reuse_matches_full_angle_grid():
    img = np.zeros((64, 64, 3))
    img[:, :, 0] = np.linspace(20, 220, 64)[:, None]
    img[:, :, 1] = np.linspace(30, 180, 64)[None, :]
    img[:, :, 2] = 90
    layout = MultiRingLayout(64, default_annuli(64, 2), m=8, guard_frac=0.15, strength=0.05, mode="mean")
    sign = extraction_shift_sign(img, layout)
    assert sign in (1, -1)
    assert reuse_matches_reextract(img, layout, 4, sign)


def test_soft_scores_shift_invariant():
    rng = np.random.default_rng(1)
    key = bc.keygen(m=16, b=2, weights=3, tau=4, eta=0.03, rng=rng)
    soft = rng.normal(size=key.b * key.m)
    a, b = fit_logistic(soft, rng.integers(0, 2, size=soft.shape))
    probs = bit_probs(soft, a, b)
    for kind in ("hard", "soft", "erasure"):
        assert shift_invariant(key, probs, kind, gamma=0.2)


def test_qim_pushes_radial_coeff_on_flat():
    rng = np.random.default_rng(0)
    size = 128
    layout = MultiRingLayout(size, default_annuli(size, 2), m=8, guard_frac=0.15, strength=0.04, mode="qim")
    img = np.full((size, size), 128.0)
    bits = make_bits(layout, rng)
    marked = embed_weak(img, layout, bits)
    soft = extract_soft(marked, layout, 0.0)
    sign = np.where(bits == 1, 1.0, -1.0)
    margin = sign * soft
    # Clipping and rasterization leave a little slack; the sign should hold.
    assert float(np.mean(margin > 0)) > 0.9
