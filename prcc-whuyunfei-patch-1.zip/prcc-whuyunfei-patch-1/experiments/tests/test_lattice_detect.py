"""Lattice blind bits are readable after a known half-step rotation."""

from __future__ import annotations

import numpy as np

from src import block_circulant as bc
from src.fast_radial import make_layout
from src.lattice_carrier import embed_lattice
from src.lattice_detect import known_angle_ber, scores_over_angles_lattice
from src.residual_search import shared_grids
from src.spatial_multiring import apply_attack


def test_lattice_half_step_known_angle_low_ber():
    rng = np.random.default_rng(0)
    m, b, size, step = 32, 4, 128, 0.2
    layout = make_layout(size, m, b, 0.15, 0.0)
    key = bc.keygen(m, b, 1, tau=2, eta=0.0, rng=rng)
    img = np.full((size, size, 3), 140.0)
    c = bc.encode(key, rng=rng, add_noise=False).reshape(b, m)
    marked = embed_lattice(img, layout, c, step)
    angle = 180.0 / m
    attacked = apply_attack(marked, "rot_jpeg", angle, 70, size)
    assert known_angle_ber(attacked, layout, c, step, angle) < 0.15
    deltas, _ = shared_grids(m, 4)
    sc = scores_over_angles_lattice(key, attacked, layout, deltas, step).best
    assert sc <= 2
