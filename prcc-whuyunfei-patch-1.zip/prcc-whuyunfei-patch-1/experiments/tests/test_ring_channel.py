"""Sanity checks for ring embed/extract (geometry gate primitives)."""

from __future__ import annotations

import numpy as np

from src.ring_channel import (
    RingLayout,
    bit_error_rate,
    bits_iid,
    embed_bits,
    extract_bits,
    gate_decision,
    make_carrier,
    run_channel_sweep,
)


def test_embed_extract_angle_zero_point():
    rng = np.random.default_rng(0)
    layout = RingLayout(
        size=128,
        radii=[16.0, 24.0, 32.0, 40.0],
        m=32,
        amp=80.0,
        embed_mode="point",
        extract_mode="nearest",
    )
    bits = bits_iid(layout, rng)
    marked = embed_bits(make_carrier(layout, rng), layout, bits)
    got = extract_bits(marked, layout)
    assert bit_error_rate(bits, got) == 0.0


def test_spatial_angle_zero_and_half_bin():
    rng = np.random.default_rng(1)
    layout = RingLayout(
        size=128,
        radii=[28.0, 48.0],
        m=8,
        amp=0.5,
        embed_mode="spatial",
        extract_mode="spatial",
        sector_frac=0.9,
    )
    bits = bits_iid(layout, rng)
    marked = embed_bits(make_carrier(layout, rng, sigma=0.01), layout, bits)
    assert bit_error_rate(bits, extract_bits(marked, layout)) == 0.0

    results = run_channel_sweep(
        layout,
        rng,
        angles=[0.0, 0.5 * (360.0 / 8)],
        modes=("pad",),
        patterns=("iid",),
        trials_per=3,
    )
    half = [r for r in results if r.angle_deg > 0][0]
    assert half.grid_aligned_ber <= 0.05
    assert gate_decision(results, m=8) == "compare_codes"
