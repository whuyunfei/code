"""PRCC experiment package: block-circulant candidate, ring channel, PRC baseline."""
