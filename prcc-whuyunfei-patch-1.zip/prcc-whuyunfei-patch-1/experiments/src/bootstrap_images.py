"""Create a fixed proxy natural-image set under experiments/data/images/.

These are structured scenes (gradients, edges, low-frequency textures), not
iid noise. Prefer replacing with real photos when available; scripts fail if
the folder has fewer than the required count.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

try:
    from PIL import Image, ImageDraw
except ImportError as e:
    raise SystemExit("pip install pillow") from e


def _lowfreq_texture(rng: np.random.Generator, size: int) -> np.ndarray:
    F = np.zeros((size, size), dtype=np.complex128)
    for _ in range(40):
        fy = int(rng.integers(1, max(2, size // 8)))
        fx = int(rng.integers(1, max(2, size // 8)))
        amp = rng.normal(0, 1)
        phase = rng.uniform(0, 2 * np.pi)
        F[fy, fx] = amp * np.exp(1j * phase)
        F[-fy, -fx] = np.conj(F[fy, fx])
    img = np.real(np.fft.ifft2(F))
    img = (img - img.min()) / (img.max() - img.min() + 1e-12)
    return img


def make_one(rng: np.random.Generator, size: int = 256, kind: int = 0) -> np.ndarray:
    yy, xx = np.mgrid[0:size, 0:size]
    base = _lowfreq_texture(rng, size)
    if kind % 5 == 0:
        base = 0.6 * base + 0.4 * (xx / size)
    elif kind % 5 == 1:
        base = 0.6 * base + 0.4 * (yy / size)
    elif kind % 5 == 2:
        base = 0.5 * base + 0.5 * ((xx - size / 2) ** 2 + (yy - size / 2) ** 2)
        base = (base - base.min()) / (base.max() - base.min() + 1e-12)
    elif kind % 5 == 3:
        base = 0.7 * base + 0.3 * (np.sin(8 * np.pi * xx / size) > 0)
    else:
        base = 0.65 * base + 0.35 * rng.random((size, size)) * 0.3 + 0.2

    rgb = np.stack(
        [
            np.clip(base * (0.8 + 0.4 * rng.random()), 0, 1),
            np.clip(base * (0.7 + 0.5 * rng.random()), 0, 1),
            np.clip(base * (0.6 + 0.5 * rng.random()), 0, 1),
        ],
        axis=2,
    )
    pil = Image.fromarray((rgb * 255).astype(np.uint8), mode="RGB")
    draw = ImageDraw.Draw(pil)
    # A few geometric shapes for edges / structure
    for _ in range(3):
        x0, x1 = sorted(int(v) for v in rng.integers(0, size, size=2))
        y0, y1 = sorted(int(v) for v in rng.integers(0, size, size=2))
        if x1 == x0:
            x1 = min(size - 1, x0 + 8)
        if y1 == y0:
            y1 = min(size - 1, y0 + 8)
        color = tuple(int(c) for c in rng.integers(40, 220, size=3))
        if rng.random() < 0.5:
            draw.ellipse([x0, y0, x1, y1], outline=color, width=3)
        else:
            draw.rectangle([x0, y0, x1, y1], outline=color, width=3)
    return np.asarray(pil)


def main() -> None:
    root = Path(__file__).resolve().parents[1] / "data" / "images"
    root.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(42)
    n = 24
    for i in range(n):
        arr = make_one(rng, size=256, kind=i)
        Image.fromarray(arr).save(root / f"proxy_{i:02d}.png")
    print(f"wrote {n} images to {root}")
    readme = root / "README.md"
    readme.write_text(
        "Proxy structured images for channel experiments.\n"
        "Replace with real photographs when possible; keep at least 20 files.\n"
    )


if __name__ == "__main__":
    main()
