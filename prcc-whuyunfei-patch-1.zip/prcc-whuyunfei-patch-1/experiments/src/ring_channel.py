"""Ring embed / rotate / extract channel diagnostics.

Two domains:
  - fft: paint angular samples on DFT rings (Cartesian FFT bins)
  - spatial: paint exclusive angular sectors on a pixel-domain annulus

Fractional rotations destroy high-frequency FFT-ring patterns even with
known-angle grid alignment; spatial annulus sectors are the redesigned
embedding under test for the geometry gate.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Literal, Sequence, Tuple

import numpy as np
from scipy.ndimage import rotate as nd_rotate

EmbedMode = Literal["point", "sector", "spatial"]
ExtractMode = Literal["nearest", "bilinear", "sector", "spatial"]


@dataclass
class RingLayout:
    size: int
    radii: List[float]  # FFT ring radii; for spatial, [r_inner, r_outer] (extra ignored)
    m: int
    amp: float = 50.0
    embed_mode: EmbedMode = "spatial"
    extract_mode: ExtractMode = "spatial"
    sector_frac: float = 0.9
    radial_half: float = 1.0
    n_ang: int = 9
    n_rad: int = 5

    @property
    def n_rings(self) -> int:
        if self.embed_mode == "spatial":
            return 1
        return len(self.radii)

    @property
    def annulus(self) -> Tuple[float, float]:
        r0, r1 = float(self.radii[0]), float(self.radii[-1])
        if r1 < r0:
            r0, r1 = r1, r0
        return r0, r1


def _center(size: int) -> float:
    return size / 2.0


def ring_angle(t: int, m: int) -> float:
    return 2.0 * np.pi * t / m


def polar_to_yx(layout: RingLayout, radius: float, theta: float) -> Tuple[float, float]:
    cy = cx = _center(layout.size)
    return cy + radius * np.sin(theta), cx + radius * np.cos(theta)


def independent_bit_mask(m: int) -> np.ndarray:
    mask = np.zeros(m, dtype=bool)
    mask[: m // 2] = True
    return mask


def make_carrier(layout: RingLayout, rng: np.random.Generator, sigma: float = 0.05) -> np.ndarray:
    return rng.normal(0.0, sigma, size=(layout.size, layout.size))


def bits_iid(layout: RingLayout, rng: np.random.Generator) -> np.ndarray:
    b = layout.n_rings
    m = layout.m
    bits = np.zeros((b, m), dtype=np.uint8)
    free = rng.integers(0, 2, size=(b, m // 2), dtype=np.uint8)
    bits[:, : m // 2] = free
    bits[:, m // 2 :] = free
    return bits


def bits_low_freq_arc(layout: RingLayout, rng: np.random.Generator, repeats: int = 2) -> np.ndarray:
    b = layout.n_rings
    m = layout.m
    out = np.zeros((b, m), dtype=np.uint8)
    half = m // 2
    for j in range(b):
        n_unique = max(1, (half + repeats - 1) // repeats)
        seeds = rng.integers(0, 2, size=n_unique, dtype=np.uint8)
        for t in range(half):
            out[j, t] = seeds[min(t // repeats, n_unique - 1)]
        out[j, half:] = out[j, :half]
    return out


def _bilinear_sample(arr: np.ndarray, y: float, x: float) -> complex:
    h, w = arr.shape
    y0 = int(np.floor(y)) % h
    x0 = int(np.floor(x)) % w
    y1 = (y0 + 1) % h
    x1 = (x0 + 1) % w
    wy = y - np.floor(y)
    wx = x - np.floor(x)
    return (
        (1 - wy) * ((1 - wx) * arr[y0, x0] + wx * arr[y0, x1])
        + wy * ((1 - wx) * arr[y1, x0] + wx * arr[y1, x1])
    )


def _bilinear_set(arr: np.ndarray, y: float, x: float, value: complex, weight: float = 1.0) -> None:
    h, w = arr.shape
    y0 = int(np.floor(y)) % h
    x0 = int(np.floor(x)) % w
    y1 = (y0 + 1) % h
    x1 = (x0 + 1) % w
    wy = y - np.floor(y)
    wx = x - np.floor(x)
    for yi, xi, ww in (
        (y0, x0, (1 - wy) * (1 - wx)),
        (y0, x1, (1 - wy) * wx),
        (y1, x0, wy * (1 - wx)),
        (y1, x1, wy * wx),
    ):
        wloc = weight * ww
        if wloc <= 0:
            continue
        arr[yi, xi] = (1 - wloc) * arr[yi, xi] + wloc * value


def _sector_offsets(layout: RingLayout) -> Tuple[np.ndarray, np.ndarray]:
    half_ang = 0.5 * layout.sector_frac
    a = np.linspace(-half_ang, half_ang, layout.n_ang)
    if layout.n_rad == 1:
        r = np.array([0.0])
    else:
        r = np.linspace(-layout.radial_half, layout.radial_half, layout.n_rad)
    return a, r


def _paint_fft_sector(F: np.ndarray, layout: RingLayout, radius: float, theta: float, value: complex) -> None:
    a_offs, r_offs = _sector_offsets(layout)
    bin_ang = 2.0 * np.pi / layout.m
    for a in a_offs:
        th = theta + a * bin_ang
        for rr in r_offs:
            r = radius + rr
            if r <= 1.0:
                continue
            y, x = polar_to_yx(layout, r, th)
            _bilinear_set(F, y, x, value, weight=1.0)


def _integrate_fft_sector(F: np.ndarray, layout: RingLayout, radius: float, theta: float) -> float:
    a_offs, r_offs = _sector_offsets(layout)
    bin_ang = 2.0 * np.pi / layout.m
    acc = 0.0
    n = 0
    for a in a_offs:
        th = theta + a * bin_ang
        for rr in r_offs:
            r = radius + rr
            if r <= 1.0:
                continue
            y, x = polar_to_yx(layout, r, th)
            acc += float(np.real(_bilinear_sample(F, y, x)))
            n += 1
    return acc / max(n, 1)


def _spatial_grids(layout: RingLayout):
    n = layout.size
    yy, xx = np.mgrid[0:n, 0:n]
    cy = cx = (n - 1) / 2.0
    y = yy - cy
    x = xx - cx
    rad = np.sqrt(x * x + y * y)
    ang = (np.arctan2(y, x) + 2.0 * np.pi) % (2.0 * np.pi)
    r0, r1 = layout.annulus
    mask_r = (rad >= r0) & (rad <= r1)
    return ang, mask_r


def embed_bits(image: np.ndarray, layout: RingLayout, bits: np.ndarray) -> np.ndarray:
    m = layout.m
    half = m // 2
    if layout.embed_mode == "spatial":
        # Pixel-domain annulus sectors (amp is spatial intensity)
        amp = min(layout.amp, 1.0) if layout.amp > 1 else layout.amp
        if layout.amp >= 1.0:
            amp = 0.5  # sane default when callers pass FFT-scale amps
        img = image.astype(np.float64).copy()
        ang, mask_r = _spatial_grids(layout)
        bin_w = 2.0 * np.pi / m
        for t in range(half):
            sign = 1.0 if bits[0, t] == 1 else -1.0
            for tt in (t, t + half):
                a0 = tt * bin_w
                a1 = (tt + layout.sector_frac) * bin_w
                if a1 <= 2.0 * np.pi:
                    sect = (ang >= a0) & (ang < a1)
                else:
                    sect = ((ang >= a0) & (ang < 2.0 * np.pi)) | (ang < (a1 - 2.0 * np.pi))
                img[mask_r & sect] = sign * amp
        return img

    F = np.fft.fftshift(np.fft.fft2(image)).astype(np.complex128)
    for j, radius in enumerate(layout.radii):
        for t in range(half):
            sign = 1.0 if bits[j, t] == 1 else -1.0
            val = complex(sign * layout.amp, 0.0)
            theta = ring_angle(t, m)
            theta2 = ring_angle(t + half, m)
            if layout.embed_mode == "point":
                for th in (theta, theta2):
                    y, x = polar_to_yx(layout, radius, th)
                    yi, xi = int(np.rint(y)) % layout.size, int(np.rint(x)) % layout.size
                    F[yi, xi] = val
            else:
                _paint_fft_sector(F, layout, radius, theta, val)
                _paint_fft_sector(F, layout, radius, theta2, val)
    return np.real(np.fft.ifft2(np.fft.ifftshift(F)))


def extract_soft(
    image: np.ndarray,
    layout: RingLayout,
    angle_offset_deg: float = 0.0,
) -> np.ndarray:
    """Soft scores. ``angle_offset_deg`` tracks scipy CCW image rotation (content φ→φ+θ)."""
    offset = np.deg2rad(angle_offset_deg)
    if layout.embed_mode == "spatial" or layout.extract_mode == "spatial":
        ang, mask_r = _spatial_grids(layout)
        # Empirically, with scipy.ndimage.rotate(+θ), recovering painted sectors
        # requires labeling by (atan2 + θ). (FFT ring sampling uses θ_t + θ.)
        ang = (ang + offset) % (2.0 * np.pi)
        soft = np.zeros((1, layout.m), dtype=np.float64)
        bin_w = 2.0 * np.pi / layout.m
        for t in range(layout.m):
            a0 = t * bin_w
            a1 = (t + layout.sector_frac) * bin_w
            if a1 <= 2.0 * np.pi:
                sect = (ang >= a0) & (ang < a1)
            else:
                sect = ((ang >= a0) & (ang < 2.0 * np.pi)) | (ang < (a1 - 2.0 * np.pi))
            sel = mask_r & sect
            soft[0, t] = float(image[sel].mean()) if np.any(sel) else 0.0
        return soft

    F = np.fft.fftshift(np.fft.fft2(image))
    soft = np.zeros((len(layout.radii), layout.m), dtype=np.float64)
    for j, radius in enumerate(layout.radii):
        for t in range(layout.m):
            theta = ring_angle(t, layout.m) + offset
            if layout.extract_mode == "nearest":
                y, x = polar_to_yx(layout, radius, theta)
                yi, xi = int(np.rint(y)) % layout.size, int(np.rint(x)) % layout.size
                soft[j, t] = float(np.real(F[yi, xi]))
            elif layout.extract_mode == "bilinear":
                y, x = polar_to_yx(layout, radius, theta)
                soft[j, t] = float(np.real(_bilinear_sample(F, y, x)))
            else:
                soft[j, t] = _integrate_fft_sector(F, layout, radius, theta)
    return soft


def extract_bits(
    image: np.ndarray,
    layout: RingLayout,
    angle_offset_deg: float = 0.0,
) -> np.ndarray:
    soft = extract_soft(image, layout, angle_offset_deg=angle_offset_deg)
    return (soft >= 0).astype(np.uint8)


def rotate_image(image: np.ndarray, angle_deg: float, mode: str) -> np.ndarray:
    if mode == "pad":
        return nd_rotate(image, angle=angle_deg, reshape=True, order=1, mode="constant", cval=0.0)
    if mode == "crop":
        return nd_rotate(image, angle=angle_deg, reshape=False, order=1, mode="constant", cval=0.0)
    raise ValueError("mode must be pad or crop")


def center_crop_or_pad(arr: np.ndarray, size: int) -> np.ndarray:
    out = np.zeros((size, size), dtype=np.float64)
    h, w = arr.shape
    ys = max(0, (size - h) // 2)
    xs = max(0, (size - w) // 2)
    ye = ys + min(h, size)
    xe = xs + min(w, size)
    sy = max(0, (h - size) // 2)
    sx = max(0, (w - size) // 2)
    out[ys:ye, xs:xe] = arr[sy : sy + (ye - ys), sx : sx + (xe - xs)]
    return out


def fractional_align_bits(bits: np.ndarray, shift: float) -> np.ndarray:
    b, m = bits.shape
    k = int(np.round(shift)) % m
    out = np.zeros_like(bits)
    for j in range(b):
        out[j] = np.roll(bits[j], k)
    return out


def bit_error_rate(ref: np.ndarray, got: np.ndarray, use_half: bool = True) -> float:
    if use_half:
        mask = independent_bit_mask(ref.shape[1])
        errs = tot = 0
        for j in range(ref.shape[0]):
            errs += int(np.sum(ref[j, mask] != got[j, mask]))
            tot += int(np.sum(mask))
        return errs / max(1, tot)
    return float(np.mean(ref != got))


def soft_agreement(ref_bits: np.ndarray, soft: np.ndarray, use_half: bool = True) -> float:
    signs = 2 * ref_bits.astype(np.float64) - 1
    if use_half:
        mask = independent_bit_mask(ref_bits.shape[1])
        num = 0.0
        den = 0
        for j in range(ref_bits.shape[0]):
            num += float(np.sum(signs[j, mask] * soft[j, mask]))
            den += int(np.sum(mask))
        return num / max(1, den)
    return float(np.mean(signs * soft))


@dataclass
class ChannelTrial:
    angle_deg: float
    mode: str
    pattern: str
    ber: float
    soft_agree: float
    aligned_ber: float
    grid_aligned_ber: float
    method: str = ""


def default_angles(m: int) -> List[float]:
    step = 360.0 / m
    angles = [step * f for f in (0.0, 0.25, 0.5, 0.75, 1.0)]
    for extra in (15.0, 45.0, 90.0):
        if all(abs(extra - a) > 1e-9 for a in angles):
            angles.append(extra)
    return angles


def run_channel_sweep(
    layout: RingLayout,
    rng: np.random.Generator,
    angles: Sequence[float] | None = None,
    modes: Sequence[str] = ("pad", "crop"),
    patterns: Sequence[str] = ("iid", "lowfreq"),
    trials_per: int = 3,
) -> List[ChannelTrial]:
    angles = list(angles) if angles is not None else default_angles(layout.m)
    results: List[ChannelTrial] = []
    step = 360.0 / layout.m
    method = f"{layout.embed_mode}/{layout.extract_mode}/sf={layout.sector_frac:g}/m={layout.m}"
    for pattern in patterns:
        for mode in modes:
            for angle in angles:
                bers, softs, aligned, grid = [], [], [], []
                for _ in range(trials_per):
                    img0 = make_carrier(layout, rng)
                    bits = bits_iid(layout, rng) if pattern == "iid" else bits_low_freq_arc(layout, rng)
                    marked = embed_bits(img0, layout, bits)
                    if abs(angle) < 1e-12:
                        rot = marked
                    else:
                        rot = rotate_image(marked, angle, mode)
                        rot = center_crop_or_pad(rot, layout.size)
                    got = extract_bits(rot, layout, angle_offset_deg=0.0)
                    soft0 = extract_soft(rot, layout, angle_offset_deg=0.0)
                    shift_bins = angle / step
                    # Content moves +shift bins under CCW rotation; roll extracted bits back.
                    k = -int(np.round(shift_bins)) % layout.m
                    got_aligned = fractional_align_bits(got, k)
                    bers.append(bit_error_rate(bits, got))
                    aligned.append(bit_error_rate(bits, got_aligned))
                    got_grid = extract_bits(rot, layout, angle_offset_deg=angle)
                    soft_grid = extract_soft(rot, layout, angle_offset_deg=angle)
                    softs.append(soft_agreement(bits, soft_grid))
                    grid.append(bit_error_rate(bits, got_grid))
                results.append(
                    ChannelTrial(
                        angle_deg=float(angle),
                        mode=mode,
                        pattern=pattern,
                        ber=float(np.mean(bers)),
                        soft_agree=float(np.mean(softs)),
                        aligned_ber=float(np.mean(aligned)),
                        grid_aligned_ber=float(np.mean(grid)),
                        method=method,
                    )
                )
    return results


def unmarked_bit_stats(layout: RingLayout, rng: np.random.Generator, trials: int = 20) -> Dict[str, float]:
    ones = []
    for _ in range(trials):
        img = make_carrier(layout, rng)
        bits = extract_bits(img, layout)
        ones.append(float(np.mean(bits[:, : layout.m // 2])))
    mean_ones = float(np.mean(ones))
    return {"mean_bit": mean_ones, "bias_from_half": abs(mean_ones - 0.5)}


def gate_decision(
    results: List[ChannelTrial],
    m: int,
    high: float = 0.4,
    low: float = 0.15,
    use_grid_aligned: bool = True,
) -> str:
    half_angle = 0.5 * (360.0 / m)
    candidates = [
        r
        for r in results
        if r.pattern == "iid" and r.mode == "pad" and abs(r.angle_deg - half_angle) < 1e-6
    ]
    if not candidates:
        pad_iid = [r for r in results if r.pattern == "iid" and r.mode == "pad"]
        if not pad_iid:
            return "unknown"
        candidates = [min(pad_iid, key=lambda r: abs(r.angle_deg - half_angle))]
    ber = float(
        np.mean([r.grid_aligned_ber if use_grid_aligned else r.aligned_ber for r in candidates])
    )
    if ber >= high:
        return "redesign_embedding"
    if ber <= low:
        return "compare_codes"
    return "report_soft"


def compare_embed_methods(
    size: int,
    radii: Sequence[float],
    rng: np.random.Generator,
    trials_per: int = 3,
    amp: float = 80.0,
) -> List[ChannelTrial]:
    out: List[ChannelTrial] = []
    configs = [
        dict(m=32, embed_mode="point", extract_mode="nearest", sector_frac=0.9, amp=amp),
        dict(m=16, embed_mode="sector", extract_mode="sector", sector_frac=0.7, amp=amp),
        dict(m=16, embed_mode="spatial", extract_mode="spatial", sector_frac=0.9, amp=0.5),
        dict(m=8, embed_mode="spatial", extract_mode="spatial", sector_frac=0.9, amp=0.5),
        dict(m=8, embed_mode="spatial", extract_mode="spatial", sector_frac=0.7, amp=0.5),
    ]
    for cfg in configs:
        m = int(cfg["m"])
        half = 0.5 * (360.0 / m)
        layout = RingLayout(
            size=size,
            radii=list(radii),
            m=m,
            amp=float(cfg["amp"]),
            embed_mode=cfg["embed_mode"],  # type: ignore[arg-type]
            extract_mode=cfg["extract_mode"],  # type: ignore[arg-type]
            sector_frac=float(cfg["sector_frac"]),
        )
        out.extend(
            run_channel_sweep(
                layout,
                rng,
                angles=[0.0, half, 90.0],
                modes=("pad",),
                patterns=("iid", "lowfreq"),
                trials_per=trials_per,
            )
        )
    return out
