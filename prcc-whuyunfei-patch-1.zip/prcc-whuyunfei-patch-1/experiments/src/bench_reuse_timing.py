"""Compare PRC full re-extraction with extract-once-then-shift.

Both searches use the same angle grid. Times are split into extract and code.
Mean-shift embedding. This does not by itself restate an end-to-end speedup.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from time import perf_counter

import numpy as np

from .bench_fair_compare import extraction_shift_sign, prc_reuse_search, reuse_matches_reextract
from .block_circulant import simultaneous_shift
from .kodak_photos import load_split
from .prc_watermark_adapter import KeyGen, available as prc_available, score_from_bits
from .residual_search import hard_score, search_deltas, shared_grids
from .spatial_multiring import MultiRingLayout, default_annuli, extract_bits
from . import block_circulant as bc


def prc_reextract(prc_key, image, layout, L: int):
    _deltas, angles = shared_grids(layout.m, L)
    t_ext = 0.0
    t_code = 0.0
    best = -1e18
    for a in angles:
        t0 = perf_counter()
        bits = extract_bits(image, layout, angle_offset_deg=float(a)).reshape(-1)
        t_ext += perf_counter() - t0
        t1 = perf_counter()
        sc = score_from_bits(prc_key, bits)
        t_code += perf_counter() - t1
        if sc > best:
            best = sc
    return best, 1e3 * t_ext, 1e3 * t_code


def block_split(key, image, layout, deltas):
    t_ext = 0.0
    t_code = 0.0
    t0 = perf_counter()
    # search_deltas extracts inside; time it as extract+code together then
    # recompute code-only on the same bits for the split.
    for d in deltas:
        t_e = perf_counter()
        y = extract_bits(image, layout, angle_offset_deg=float(d)).reshape(-1)
        t_ext += perf_counter() - t_e
        t_c = perf_counter()
        hard_score(key, y)
        t_code += perf_counter() - t_c
    dt = perf_counter() - t0
    return 1e3 * t_ext, 1e3 * t_code, 1e3 * dt


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", type=int, default=256)
    ap.add_argument("--m", type=int, default=8)
    ap.add_argument("--b", type=int, default=4)
    ap.add_argument("--L", type=int, default=4)
    ap.add_argument("--guard", type=float, default=0.15)
    ap.add_argument("--strength", type=float, default=0.05)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", type=str, default="../figures/reuse_timing.json")
    args = ap.parse_args()
    if not prc_available():
        raise SystemExit("galois required")

    rng = np.random.default_rng(args.seed)
    images = load_split("test", args.size)
    layout = MultiRingLayout(
        args.size, default_annuli(args.size, args.b), args.m, args.guard, args.strength, mode="mean"
    )
    sign = extraction_shift_sign(images[0], layout)
    if sign == 0:
        raise SystemExit("extract(angle) does not match a cyclic shift; fix the angle definition before timing")
    match = all(reuse_matches_reextract(im, layout, args.L, sign) for im in images[:3])
    if not match:
        raise SystemExit("reuse hard bits differ from re-extraction on the shared grid")

    n = args.m * args.b
    enc, dec = KeyGen(n, message_length=max(4, n // 8), false_positive_rate=1e-2, t=3, noise_rate=0.05, g=8, r=max(8, n // 3))
    prc_key = type("K", (), {})()
    prc_key.encoding_key = enc
    prc_key.decoding_key = dec
    prc_key.n = n
    prc_key.fpr = 1e-2

    tau = bc.suggest_tau(args.m, args.b, 0.03, 0.20)
    block_key = bc.keygen(args.m, args.b, 1, tau, 0.03, rng)
    deltas, angles = shared_grids(args.m, args.L)

    rows = []
    for im in images:
        b_ext, b_code, _b_tot = block_split(block_key, im, layout, deltas)
        p_score, p_ext, p_code = prc_reuse_search(prc_key, im, layout, args.L, sign)
        f_score, f_ext, f_code = prc_reextract(prc_key, im, layout, args.L)
        # Reuse and reextract must pick the same best score.
        if abs(p_score - f_score) > 1e-6:
            raise SystemExit(f"PRC reuse score {p_score} != reextract {f_score}")
        rows.append(
            {
                "block_extract_ms": b_ext,
                "block_code_ms": b_code,
                "prc_reuse_extract_ms": p_ext,
                "prc_reuse_code_ms": p_code,
                "prc_full_extract_ms": f_ext,
                "prc_full_code_ms": f_code,
            }
        )

    def med(k):
        return float(np.median([r[k] for r in rows]))

    summary = {
        "shift_sign": sign,
        "bits_match": match,
        "scores_match": True,
        "grid": "shared k*Delta+delta",
        "L": args.L,
        "m": args.m,
        "code_evals_prcc": args.L,
        "code_evals_prc": args.m * args.L,
        "median_block_extract_ms": med("block_extract_ms"),
        "median_block_code_ms": med("block_code_ms"),
        "median_prc_reuse_extract_ms": med("prc_reuse_extract_ms"),
        "median_prc_reuse_code_ms": med("prc_reuse_code_ms"),
        "median_prc_full_extract_ms": med("prc_full_extract_ms"),
        "median_prc_full_code_ms": med("prc_full_code_ms"),
        "n_images": len(images),
        "angles": int(len(angles)),
    }
    wall_block = summary["median_block_extract_ms"] + summary["median_block_code_ms"]
    wall_prc = summary["median_prc_reuse_extract_ms"] + summary["median_prc_reuse_code_ms"]
    wall_full = summary["median_prc_full_extract_ms"] + summary["median_prc_full_code_ms"]
    summary["wall_prcc_ms"] = wall_block
    summary["wall_prc_reuse_ms"] = wall_prc
    summary["wall_prc_full_ms"] = wall_full
    summary["speedup_vs_reuse"] = wall_prc / max(wall_block, 1e-9)
    summary["speedup_vs_full_reextract"] = wall_full / max(wall_block, 1e-9)
    extract_share = summary["median_prc_reuse_extract_ms"] / max(wall_prc, 1e-9)
    summary["prc_reuse_extract_fraction"] = extract_share
    summary["claim"] = (
        "code-detection complexity"
        if extract_share >= 0.5
        else "end-to-end detection speed"
    )
    # silence unused import if simultaneous_shift only used inside helpers
    _ = simultaneous_shift
    out = Path(args.out)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
