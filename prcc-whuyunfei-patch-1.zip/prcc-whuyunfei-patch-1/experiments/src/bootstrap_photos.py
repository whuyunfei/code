"""Download the 24 Kodak lossless images into experiments/data/photos/.

Source: https://www.r0k.us/graphics/kodak/kodak/kodimXX.png
Uses curl because this machine's Python trust store rejects the host certificate.
Does not write into data/images (proxy set).
"""

from __future__ import annotations

import subprocess
from pathlib import Path

URL = "https://www.r0k.us/graphics/kodak/kodak/{name}"


def main() -> None:
    root = Path(__file__).resolve().parents[1] / "data" / "photos"
    root.mkdir(parents=True, exist_ok=True)
    failed = []
    for i in range(1, 25):
        name = f"kodim{i:02d}.png"
        dest = root / name
        if dest.is_file() and dest.stat().st_size > 10000:
            print(f"have {name}")
            continue
        url = URL.format(name=name)
        proc = subprocess.run(["curl", "-fsSL", "-o", str(dest), url], check=False)
        if proc.returncode != 0 or not dest.is_file() or dest.stat().st_size < 10000:
            if dest.exists():
                dest.unlink()
            failed.append(name)
            print(f"fail {name}")
        else:
            print(f"got {name} {dest.stat().st_size}")
    if failed:
        raise SystemExit(f"download failed for {failed}; not using proxy images")
    n = len(list(root.glob("kodim*.png")))
    if n < 24:
        raise SystemExit(f"need 24 Kodak images, found {n}")
    print(f"ok {n} images in {root}")


if __name__ == "__main__":
    main()
