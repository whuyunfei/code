"""Fixed-PSNR comparison of mean, radial, and qim on random bits.

Strength is chosen on the tune split. Metrics are on the test split only.
Known-angle extraction (not a code, not a blind search).
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from .kodak_photos import load_split
from .spatial_multiring import (
    MultiRingLayout,
    apply_attack,
    ber,
    default_annuli,
    embed_weak,
    extract_soft,
    make_bits,
    psnr,
)


def matched_strength(mode: str, images, bits_list, size, m, b, guard, target: float) -> tuple[float, float, str]:
    def mean_psnr(strength: float) -> float:
        layout = MultiRingLayout(size, default_annuli(size, b), m, guard, strength, mode=mode)
        vals = [psnr(im, embed_weak(im, layout, bits)) for im, bits in zip(images, bits_list)]
        return float(np.mean(vals))

    lo, hi = 1e-4, 0.8
    p_lo, p_hi = mean_psnr(lo), mean_psnr(hi)
    note = "ok"
    if p_hi > target + 0.5:
        return hi, p_hi, "cannot_spend_budget"
    if p_lo < target - 0.5:
        return lo, p_lo, "smallest_step_already_below_target"
    for _ in range(16):
        mid = 0.5 * (lo + hi)
        if mean_psnr(mid) > target:
            lo = mid
        else:
            hi = mid
    strength = 0.5 * (lo + hi)
    got = mean_psnr(strength)
    if got < 30.0 and target >= 35.0:
        note = "fell_through_to_below_30"
    return strength, got, note


def one_image_metrics(ref: np.ndarray, soft: np.ndarray) -> dict:
    hard = (soft >= 0).astype(np.uint8)
    err = (hard != ref).astype(np.float64)
    sign = np.where(ref == 1, 1.0, -1.0)
    margin = sign * soft
    neigh = np.roll(err, -1, axis=1)
    rate = float(err.mean())
    adj = float(np.mean(err * neigh) / rate) if rate > 0 else 0.0
    ring_ber = err.mean(axis=1)
    return {
        "ber": rate,
        "margin_mean": float(margin.mean()),
        "margin_p10": float(np.percentile(margin, 10)),
        "adj_given_err": adj,
        "frac_rings_majority_wrong": float(np.mean(ring_ber > 0.5)),
    }


def aligned_offset(angle: float, sign: int) -> float:
    return float(sign) * float(angle)


def offset_sign(layout: MultiRingLayout, rng: np.random.Generator, angle: float) -> int:
    img = np.full((layout.size, layout.size, 3), 140.0)
    bits = make_bits(layout, rng)
    marked = embed_weak(img, layout, bits)
    attacked = apply_attack(marked, "rot", angle, size=layout.size)
    best_sign, best_ber = 1, 1.0
    for sign in (1, -1):
        soft = extract_soft(attacked, layout, aligned_offset(angle, sign))
        b = ber(bits, (soft >= 0).astype(np.uint8))
        if b < best_ber:
            best_ber, best_sign = b, sign
    if best_ber > 0.2:
        raise SystemExit(f"known-angle alignment failed (best BER {best_ber:.2f}); fix rotation/extract before comparing embeds")
    return best_sign


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", type=int, default=256)
    ap.add_argument("--m", type=int, default=8)
    ap.add_argument("--b", type=int, default=4)
    ap.add_argument("--guard", type=float, default=0.15)
    ap.add_argument("--target-psnr", type=float, default=35.0)
    ap.add_argument("--angle", type=float, default=22.5)
    ap.add_argument("--trials", type=int, default=2)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", type=str, default="../figures/embed_compare.json")
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    tune = load_split("tune", args.size)
    test = load_split("test", args.size)
    modes = ("mean", "radial", "qim")
    tune_bits = []
    for _im in tune:
        layout0 = MultiRingLayout(args.size, default_annuli(args.size, args.b), args.m, args.guard, 0.01, mode="mean")
        tune_bits.append(make_bits(layout0, rng))

    chosen = {}
    for mode in modes:
        strength, got, note = matched_strength(
            mode, tune, tune_bits, args.size, args.m, args.b, args.guard, args.target_psnr
        )
        if note != "ok" and args.target_psnr >= 35.0:
            strength, got, note2 = matched_strength(
                mode, tune, tune_bits, args.size, args.m, args.b, args.guard, 30.0
            )
            note = f"{note}; retarget_30:{note2}"
        chosen[mode] = {"strength": strength, "tune_psnr": got, "note": note}
        print(f"match {mode}: strength={strength:.4f} tunePSNR={got:.2f} {note}")

    probe = MultiRingLayout(
        args.size, default_annuli(args.size, args.b), args.m, args.guard, chosen["mean"]["strength"], mode="mean"
    )
    sign = offset_sign(probe, rng, args.angle)
    attacks = ("none", "rot", "jpeg", "rot_jpeg")
    table = []
    by_mode = {}
    for mode in modes:
        layout = MultiRingLayout(
            args.size,
            default_annuli(args.size, args.b),
            args.m,
            args.guard,
            chosen[mode]["strength"],
            mode=mode,
        )
        per_attack = {}
        for kind in attacks:
            per_image_ber = []
            margins = []
            margin_p10 = []
            adj = []
            rings = []
            psnrs = []
            for img in test:
                bers = []
                for _ in range(args.trials):
                    bits = make_bits(layout, rng)
                    marked = embed_weak(img, layout, bits)
                    psnrs.append(psnr(img, marked))
                    attacked = apply_attack(marked, kind, args.angle, 70, args.size)
                    off = 0.0 if kind in ("none", "jpeg") else aligned_offset(args.angle, sign)
                    soft = extract_soft(attacked, layout, off)
                    met = one_image_metrics(bits, soft)
                    bers.append(met["ber"])
                    margins.append(met["margin_mean"])
                    margin_p10.append(met["margin_p10"])
                    adj.append(met["adj_given_err"])
                    rings.append(met["frac_rings_majority_wrong"])
                per_image_ber.append(float(np.mean(bers)))
            row = {
                "mode": mode,
                "attack": kind,
                "ber_mean": float(np.mean(per_image_ber)),
                "ber_p90": float(np.percentile(per_image_ber, 90)),
                "ber_std_across_images": float(np.std(per_image_ber)),
                "margin_mean": float(np.mean(margins)),
                "margin_p10": float(np.mean(margin_p10)),
                "adj_given_err": float(np.mean(adj)),
                "frac_rings_majority_wrong": float(np.mean(rings)),
                "psnr_mean": float(np.mean(psnrs)),
                "strength": chosen[mode]["strength"],
            }
            table.append(row)
            per_attack[kind] = row
            print(
                f"{mode:6} {kind:8} BER={row['ber_mean']:.3f} p90={row['ber_p90']:.3f} "
                f"margin={row['margin_mean']:.4f} PSNR={row['psnr_mean']:.1f}"
            )
        by_mode[mode] = per_attack

    def better(mode: str) -> bool:
        base = by_mode["mean"]
        alt = by_mode[mode]
        for kind in ("jpeg", "rot_jpeg"):
            if not (alt[kind]["ber_p90"] <= base[kind]["ber_p90"] - 0.05 and alt[kind]["margin_mean"] > base[kind]["margin_mean"]):
                return False
        return True

    winners = [m for m in ("qim", "radial") if better(m)]
    winner = None
    if winners:
        winner = min(winners, key=lambda m: by_mode[m]["jpeg"]["ber_p90"])
    summary = {
        "target_psnr": args.target_psnr,
        "offset_sign": sign,
        "angle": args.angle,
        "chosen": chosen,
        "rows": table,
        "winner": winner,
        "rule": "jpeg and rot_jpeg: ber_p90 at least 0.05 below mean AND higher mean margin; prefer lower jpeg ber_p90",
        "continue_to_code": winner is not None,
    }
    out = Path(args.out)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(summary, indent=2))
    print(f"winner={winner} wrote {out}")


if __name__ == "__main__":
    main()
