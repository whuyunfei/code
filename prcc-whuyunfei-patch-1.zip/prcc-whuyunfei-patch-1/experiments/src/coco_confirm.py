"""Fresh COCO train2017 splits for independent confirmation (not val2017).

Downloads annotations, samples 5000 filenames, then fetches those JPEGs only.
"""

from __future__ import annotations

import json
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, List

import numpy as np

from .coco_photos import load_image

ANN_URL = "http://images.cocodataset.org/annotations/annotations_trainval2017.zip"
IMG_URL = "http://images.cocodataset.org/train2017/{name}"

CONFIRM_SLICES = {
    "tune": (0, 400),
    "calib": (400, 1400),
    "test_neg": (1400, 4400),
    "test_pos": (4400, 5000),
}


def coco_root() -> Path:
    return Path(__file__).resolve().parents[1] / "data" / "coco"


def coco_train_dir() -> Path:
    return coco_root() / "train2017_confirm"


def confirm_manifest_path() -> Path:
    return coco_root() / "confirm_splits.json"


def _ensure_train_filenames(seed: int = 0, n: int = 5000) -> List[str]:
    ann_dir = coco_root() / "annotations"
    inst = ann_dir / "instances_train2017.json"
    if not inst.is_file():
        zip_path = coco_root() / "annotations_trainval2017.zip"
        coco_root().mkdir(parents=True, exist_ok=True)
        print(f"downloading {ANN_URL}", flush=True)
        subprocess.run(
            ["curl", "-L", "--fail", "--retry", "3", "-C", "-", "-o", str(zip_path), ANN_URL],
            check=True,
        )
        subprocess.run(["unzip", "-q", "-o", str(zip_path), "-d", str(coco_root())], check=True)
    data = json.loads(inst.read_text())
    names = sorted(img["file_name"] for img in data["images"])
    rng = np.random.default_rng(seed)
    pick = rng.choice(len(names), size=n, replace=False)
    return sorted(names[i] for i in pick.tolist())


def _download_one(name: str, dest: Path) -> None:
    if dest.is_file() and dest.stat().st_size > 1000:
        return
    url = IMG_URL.format(name=name)
    tmp = dest.with_suffix(dest.suffix + ".part")
    proc = subprocess.run(
        ["curl", "-L", "--fail", "--retry", "3", "-o", str(tmp), url],
        check=False,
        capture_output=True,
    )
    if proc.returncode != 0:
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"failed {name}: {proc.returncode}")
    tmp.replace(dest)


def ensure_confirm_images(seed: int = 0, n: int = 5000, workers: int = 16) -> List[str]:
    root = coco_train_dir()
    root.mkdir(parents=True, exist_ok=True)
    names = _ensure_train_filenames(seed=seed, n=n)
    missing = [nm for nm in names if not (root / nm).is_file()]
    if missing:
        print(f"downloading {len(missing)} train2017 confirm images…", flush=True)
        done = 0
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(_download_one, nm, root / nm): nm for nm in missing}
            for fut in as_completed(futs):
                fut.result()
                done += 1
                if done % 200 == 0:
                    print(f"  {done}/{len(missing)}", flush=True)
    return names


def write_confirm_manifest(seed: int = 0) -> Dict[str, List[str]]:
    names = ensure_confirm_images(seed=seed, n=5000)
    manifest = {
        split: names[span[0] : span[1]] for split, span in CONFIRM_SLICES.items()
    }
    confirm_manifest_path().write_text(json.dumps(manifest))
    return manifest


def load_confirm_manifest() -> Dict[str, List[str]]:
    path = confirm_manifest_path()
    if not path.is_file():
        return write_confirm_manifest()
    return json.loads(path.read_text())


def confirm_split_paths(split: str) -> List[Path]:
    names = load_confirm_manifest()[split]
    root = coco_train_dir()
    paths = [root / n for n in names]
    missing = [p for p in paths if not p.is_file()]
    if missing:
        # try fetch missing
        ensure_confirm_images()
        missing = [p for p in paths if not p.is_file()]
        if missing:
            raise FileNotFoundError(f"confirm {split} missing {missing[:3]}")
    return paths


def main() -> None:
    m = write_confirm_manifest()
    print({k: len(v) for k, v in m.items()})
    print(confirm_manifest_path())


if __name__ == "__main__":
    main()
