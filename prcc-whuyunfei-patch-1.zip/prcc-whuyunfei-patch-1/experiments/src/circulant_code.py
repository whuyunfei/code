"""RETRACTED full-circulant square-matrix candidate (counterexample harness).

For n=2^ell and odd weight w, the circulant H is invertible over GF(2),
so ker H = {0} and "sample from ker H + noise" collapses to Bern(eta).
Kept for regression tests and historical experiment scripts.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

import numpy as np

from .block_circulant import full_circulant, gf2_rank  # noqa: F401 — re-export helpers


def cyclic_shift(x: np.ndarray, k: int) -> np.ndarray:
    k = int(k) % len(x)
    if k == 0:
        return x.copy()
    return np.concatenate([x[-k:], x[:-k]])


@dataclass
class PRCCKey:
    H: np.ndarray  # n x n over GF(2), full circulant
    h: np.ndarray  # generator
    tau: int
    eta: float


def keygen(
    n: int,
    w: int,
    tau: int,
    eta: float = 0.0,
    rng: np.random.Generator | None = None,
    **_ignored,
) -> PRCCKey:
    """KeyGen for the retracted full-circulant construction."""
    rng = rng or np.random.default_rng()
    if not (1 <= w <= n):
        raise ValueError("invalid w")
    h = np.zeros(n, dtype=np.uint8)
    h[rng.choice(n, size=w, replace=False)] = 1
    H = full_circulant(h)
    return PRCCKey(H=H, h=h, tau=tau, eta=eta)


def syndrome(H: np.ndarray, c: np.ndarray) -> np.ndarray:
    return (H @ c.astype(np.uint8)) % 2


def detect(key: PRCCKey, c: np.ndarray) -> bool:
    return int(syndrome(key.H, c).sum()) <= key.tau


def encode(
    key: PRCCKey,
    rng: np.random.Generator | None = None,
    max_flips: int = 50_000,
    restarts: int = 8,
) -> np.ndarray:
    """Heuristic sampler (known inadequate when ker H is trivial)."""
    rng = rng or np.random.default_rng()
    n = key.H.shape[1]
    target = max(0, key.tau // 2)
    best_c = None
    best_wt = n + 1

    for _ in range(restarts):
        c = rng.integers(0, 2, size=n, dtype=np.uint8)

        def wt(c_: np.ndarray) -> int:
            return int(syndrome(key.H, c_).sum())

        cur = wt(c)
        for _flip in range(max_flips // restarts):
            if cur <= target:
                break
            i = int(rng.integers(0, n))
            c[i] ^= 1
            new = wt(c)
            if new <= cur:
                cur = new
            else:
                c[i] ^= 1
        if cur < best_wt:
            best_wt = cur
            best_c = c.copy()

    assert best_c is not None
    c = best_c
    if key.eta > 0:
        noise = rng.random(n) < key.eta
        c = np.bitwise_xor(c, noise.astype(np.uint8))
    return c


def bsc(c: np.ndarray, p: float, rng: np.random.Generator | None = None) -> np.ndarray:
    rng = rng or np.random.default_rng()
    flips = rng.random(len(c)) < p
    return np.bitwise_xor(c, flips.astype(np.uint8))


def verify_shift_invariance(key: PRCCKey, c: np.ndarray, ks: List[int] | None = None) -> Tuple[bool, list[int]]:
    base = int(syndrome(key.H, c).sum())
    if ks is None:
        ks = list(range(len(c)))
    wts = []
    ok = True
    for k in ks:
        w = int(syndrome(key.H, cyclic_shift(c, int(k))).sum())
        wts.append(w)
        if w != base:
            ok = False
    return ok, wts


def is_full_rank(key: PRCCKey) -> bool:
    return gf2_rank(key.H) == key.H.shape[0]
