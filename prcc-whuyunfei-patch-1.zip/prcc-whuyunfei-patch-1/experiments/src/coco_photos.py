"""COCO 2017 val splits, fixed by sorted filename.

Tune 400, calibrate 1,000, independent negatives 3,000, positives the rest.
A rotated or JPEG copy stays in the same split as its source file.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

import numpy as np

SPLIT_SLICES = {
    "tune": (0, 400),
    "calib": (400, 1400),
    "test_neg": (1400, 4400),
    "test_pos": (4400, 5000),
}


def coco_dir() -> Path:
    return Path(__file__).resolve().parents[1] / "data" / "coco" / "val2017"


def manifest_path() -> Path:
    return Path(__file__).resolve().parents[1] / "data" / "coco" / "splits.json"


def all_paths() -> List[Path]:
    root = coco_dir()
    if not root.is_dir():
        raise FileNotFoundError(f"missing {root}. Run: python -m src.bootstrap_coco")
    paths = sorted(p for p in root.iterdir() if p.suffix.lower() in {".jpg", ".jpeg"})
    if len(paths) < 5000:
        raise FileNotFoundError(f"need >= 5000 COCO val images, found {len(paths)}")
    return paths


def write_manifest() -> Dict[str, List[str]]:
    paths = all_paths()
    manifest = {name: [paths[i].name for i in range(*span)] for name, span in SPLIT_SLICES.items()}
    manifest_path().write_text(json.dumps(manifest))
    return manifest


def load_manifest() -> Dict[str, List[str]]:
    path = manifest_path()
    if not path.is_file():
        return write_manifest()
    return json.loads(path.read_text())


def split_paths(split: str) -> List[Path]:
    names = load_manifest()[split]
    root = coco_dir()
    paths = [root / name for name in names]
    missing = [p for p in paths if not p.is_file()]
    if missing:
        raise FileNotFoundError(f"{split} missing {missing[:3]}")
    return paths


def load_image(path: Path, size: int) -> np.ndarray:
    from PIL import Image

    im = Image.open(path).convert("RGB").resize((size, size), Image.BILINEAR)
    return np.asarray(im).astype(np.float64)


def load_split(split: str, size: int, limit: int | None = None) -> List[np.ndarray]:
    paths = split_paths(split)
    if limit is not None:
        paths = paths[:limit]
    return [load_image(p, size) for p in paths]
