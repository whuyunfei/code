"""Arbitrary-angle and multi-key check on frozen lattice configs.

Previous three-metric pass used a fixed rotation of 180/m (on the L-grid).
This bench freezes step / (m,w,eta,L), recalibrates an integer threshold per key,
then reports:

1. TPR under θ ~ Unif[0,360) + JPEG70 (blind residual search)
2. TPR vs residual δ ∈ [0, Δ), including search-grid midpoints
3. Unmarked FPR with no attack and with rot+JPEG70 (θ random or fixed residual)

Paired images and shared θ / encode seeds across candidates so L/η/w diffs
are not confounded by different keys or different attacks.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np

from . import block_circulant as bc
from .coco_photos import load_image, split_paths
from .fast_radial import make_layout
from .integer_threshold import clopper_pearson, clopper_upper, largest_integer_threshold
from .lattice_carrier import embed_lattice
from .lattice_detect import scores_over_angles_lattice
from .residual_search import shared_grids
from .spatial_multiring import apply_attack, psnr


B = 4
GUARD = 0.15
FPR_ALPHA = 1e-2
TPR_TARGET = 0.90
JPEG_Q = 70

# Frozen steps from figures/three_metrics.json
STEPS = {
    32: {"size": 256, "step": 0.19499893188476564},
    64: {"size": 256, "step": 0.19745071411132814},
}

# Few candidates: priority L=8 lattice cells (incl. one that barely missed attacked-FPR)
DEFAULT_CANDIDATES = [
    {"m": 32, "w": 1, "eta": 0.0, "L": 8},
    {"m": 64, "w": 1, "eta": 0.0, "L": 8},
    {"m": 32, "w": 1, "eta": 0.01, "L": 8},
    {"m": 64, "w": 3, "eta": 0.0, "L": 8},
]


def _make_key(m: int, w: int, eta: float, rng: np.random.Generator):
    tau = bc.suggest_tau(m, B * w, eta if eta > 0 else 0.03, 0.05)
    return bc.keygen(m, B, w, tau, eta, rng)


def residual_probe_deltas(m: int, L: int) -> List[dict]:
    """Search-grid points, midpoints, half-step (180/m), and extremes."""
    Delta = 360.0 / m
    step = Delta / L
    out = []
    seen = set()

    def add(delta: float, tag: str):
        d = float(delta % Delta)
        key = round(d, 8)
        if key in seen:
            return
        seen.add(key)
        out.append({"delta": d, "tag": tag})

    for i in range(L):
        add(i * step, "grid")
        add((i + 0.5) * step, "mid")
    add(180.0 / m, "half_step")
    add(0.0, "zero")
    add(Delta * 0.5, "half_sector")
    return sorted(out, key=lambda r: r["delta"])


def calibrate_threshold(
    key: bc.BlockCirculantKey,
    layout,
    step: float,
    L: int,
    paths: Sequence[Path],
    size: int,
) -> Tuple[int | None, List[float]]:
    deltas, _ = shared_grids(key.m, L)
    scores = []
    for path in paths:
        img = load_image(path, size)
        scores.append(scores_over_angles_lattice(key, img, layout, deltas, step).best)
    return largest_integer_threshold(scores, FPR_ALPHA), scores


def fpr_eval(
    key: bc.BlockCirculantKey,
    layout,
    step: float,
    L: int,
    thr: int,
    paths: Sequence[Path],
    size: int,
    kind: str,
    angles: Sequence[float] | None,
) -> dict:
    deltas, _ = shared_grids(key.m, L)
    hits = 0
    n = 0
    for i, path in enumerate(paths):
        img = load_image(path, size)
        if kind == "none":
            attacked = img
        elif kind == "rot_jpeg_fixed":
            ang = float(angles[i % len(angles)]) if angles else 180.0 / key.m
            attacked = apply_attack(img, "rot_jpeg", ang, JPEG_Q, size)
        elif kind == "rot_jpeg_random":
            ang = float(angles[i])
            attacked = apply_attack(img, "rot_jpeg", ang, JPEG_Q, size)
        else:
            raise ValueError(kind)
        sc = scores_over_angles_lattice(key, attacked, layout, deltas, step).best
        hits += int(np.isfinite(sc) and sc <= thr)
        n += 1
    lo, hi = clopper_pearson(hits, n)
    return {
        "k": hits,
        "n": n,
        "fpr": hits / n if n else float("nan"),
        "cp_lo": lo,
        "cp_hi": hi,
        "cp_upper": clopper_upper(hits, n),
    }


def tpr_arbitrary(
    key: bc.BlockCirculantKey,
    layout,
    step: float,
    L: int,
    thr: int,
    eta: float,
    paths: Sequence[Path],
    size: int,
    angles: Sequence[float],
    encode_seeds: Sequence[int],
) -> dict:
    deltas, _ = shared_grids(key.m, L)
    hits = 0
    psnrs = []
    n = len(paths)
    for i, path in enumerate(paths):
        img = load_image(path, size)
        erng = np.random.default_rng(int(encode_seeds[i]))
        c = bc.encode(key, rng=erng, add_noise=(eta > 0)).reshape(B, key.m)
        marked = embed_lattice(img, layout, c, step)
        psnrs.append(psnr(img, marked))
        attacked = apply_attack(marked, "rot_jpeg", float(angles[i]), JPEG_Q, size)
        sc = scores_over_angles_lattice(key, attacked, layout, deltas, step).best
        hits += int(np.isfinite(sc) and sc <= thr)
    lo, hi = clopper_pearson(hits, n)
    return {
        "k": hits,
        "n": n,
        "tpr": hits / n if n else float("nan"),
        "cp_lo": lo,
        "cp_hi": hi,
        "psnr_median": float(np.median(psnrs)),
        "psnr_p10": float(np.percentile(psnrs, 10)),
    }


def tpr_vs_delta(
    key: bc.BlockCirculantKey,
    layout,
    step: float,
    L: int,
    thr: int,
    eta: float,
    paths: Sequence[Path],
    size: int,
    encode_seeds: Sequence[int],
    probes: Sequence[dict],
) -> List[dict]:
    deltas_search, _ = shared_grids(key.m, L)
    # Embed once per image; only the attack residual changes.
    marked_list = []
    for i, path in enumerate(paths):
        img = load_image(path, size)
        erng = np.random.default_rng(int(encode_seeds[i]))
        c = bc.encode(key, rng=erng, add_noise=(eta > 0)).reshape(B, key.m)
        marked_list.append(embed_lattice(img, layout, c, step))
    n = len(marked_list)
    rows = []
    for probe in probes:
        delta = float(probe["delta"])
        hits = 0
        for marked in marked_list:
            attacked = apply_attack(marked, "rot_jpeg", delta, JPEG_Q, size)
            sc = scores_over_angles_lattice(key, attacked, layout, deltas_search, step).best
            hits += int(np.isfinite(sc) and sc <= thr)
        lo, hi = clopper_pearson(hits, n)
        rows.append(
            {
                "delta": delta,
                "tag": probe["tag"],
                "k": hits,
                "n": n,
                "tpr": hits / n if n else float("nan"),
                "cp_lo": lo,
                "cp_hi": hi,
            }
        )
        print(
            f"  delta={delta:.4f} ({probe['tag']}) TPR={hits/n:.3f} [{lo:.3f},{hi:.3f}]",
            flush=True,
        )
    return rows


def run_key(
    cand: dict,
    key_id: int,
    key_seed: int,
    pos_paths: Sequence[Path],
    neg_paths: Sequence[Path],
    calib_paths: Sequence[Path],
    angles_pos: Sequence[float],
    angles_neg: Sequence[float],
    encode_seeds: Sequence[int],
    encode_seeds_delta: Sequence[int],
    delta_paths: Sequence[Path],
) -> dict:
    m, w, eta, L = int(cand["m"]), int(cand["w"]), float(cand["eta"]), int(cand["L"])
    size = int(STEPS[m]["size"])
    step = float(STEPS[m]["step"])
    layout = make_layout(size, m, B, GUARD, 0.0)
    key = _make_key(m, w, eta, np.random.default_rng(key_seed))
    thr, calib_scores = calibrate_threshold(key, layout, step, L, calib_paths, size)
    row: Dict = {
        "m": m,
        "w": w,
        "eta": eta,
        "L": L,
        "size": size,
        "step": step,
        "key_id": key_id,
        "key_seed": key_seed,
        "threshold": thr,
        "mass0_calib": float(np.mean(np.asarray(calib_scores) == 0)),
    }
    if thr is None:
        row["failed"] = "no integer threshold on calibration"
        row["passed_arbitrary"] = False
        print(f"key={key_id} m={m} w={w} eta={eta} L={L} NO THRESHOLD", flush=True)
        return row

    print(f"key={key_id} m={m} w={w} eta={eta} L={L} thr={thr} — FPR", flush=True)
    row["fpr_none"] = fpr_eval(key, layout, step, L, thr, neg_paths, size, "none", None)
    row["fpr_rot_jpeg_random"] = fpr_eval(
        key, layout, step, L, thr, neg_paths, size, "rot_jpeg_random", angles_neg
    )

    print(f"key={key_id} m={m} w={w} eta={eta} L={L} thr={thr} — arbitrary θ TPR", flush=True)
    row["tpr_arbitrary"] = tpr_arbitrary(
        key, layout, step, L, thr, eta, pos_paths, size, angles_pos, encode_seeds
    )

    probes = residual_probe_deltas(m, L)
    print(f"key={key_id} m={m} w={w} eta={eta} L={L} thr={thr} — δ curve", flush=True)
    row["tpr_vs_delta"] = tpr_vs_delta(
        key, layout, step, L, thr, eta, delta_paths, size, encode_seeds_delta, probes
    )

    arb = row["tpr_arbitrary"]
    fpr_n = row["fpr_none"]
    fpr_a = row["fpr_rot_jpeg_random"]
    mid_tprs = [r["tpr"] for r in row["tpr_vs_delta"] if r["tag"] == "mid"]
    row["passed_arbitrary"] = bool(
        arb["tpr"] >= TPR_TARGET
        and fpr_n["cp_upper"] <= FPR_ALPHA
        and arb["psnr_median"] >= 34.0
    )
    row["passed_attacked_fpr"] = bool(fpr_a["cp_upper"] <= FPR_ALPHA)
    row["min_midpoint_tpr"] = float(min(mid_tprs)) if mid_tprs else float("nan")
    print(
        f"key={key_id} m={m} w={w} eta={eta} L={L} "
        f"TPR_arb={arb['tpr']:.3f} [{arb['cp_lo']:.3f},{arb['cp_hi']:.3f}] "
        f"FPR_u={fpr_n['cp_upper']:.4f} FPR_att_u={fpr_a['cp_upper']:.4f} "
        f"min_mid_TPR={row['min_midpoint_tpr']:.3f} "
        f"pass_arb={row['passed_arbitrary']} pass_attFPR={row['passed_attacked_fpr']}",
        flush=True,
    )
    return row


def _plot_delta_curves(results: List[dict], out_path: Path) -> None:
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return
    # One panel per (m,w,eta,L); lines = keys
    groups: Dict[Tuple, List[dict]] = {}
    for r in results:
        if "tpr_vs_delta" not in r:
            continue
        key = (r["m"], r["w"], r["eta"], r["L"])
        groups.setdefault(key, []).append(r)
    if not groups:
        return
    n = len(groups)
    fig, axes = plt.subplots(1, n, figsize=(4.2 * n, 3.6), squeeze=False)
    for ax, ((m, w, eta, L), rows) in zip(axes[0], groups.items()):
        Delta = 360.0 / m
        for r in rows:
            xs = [p["delta"] for p in r["tpr_vs_delta"]]
            ys = [p["tpr"] for p in r["tpr_vs_delta"]]
            ax.plot(xs, ys, marker="o", ms=3, label=f"key{r['key_id']}")
            mids = [p for p in r["tpr_vs_delta"] if p["tag"] == "mid"]
            ax.scatter(
                [p["delta"] for p in mids],
                [p["tpr"] for p in mids],
                c="C3",
                s=28,
                zorder=3,
            )
        ax.axhline(TPR_TARGET, color="gray", ls="--", lw=0.8)
        ax.set_xlim(0, Delta)
        ax.set_ylim(0, 1.02)
        ax.set_xlabel(f"δ (deg), Δ={Delta:.3f}")
        ax.set_ylabel("TPR")
        ax.set_title(f"m={m} w={w} η={eta} L={L}")
        ax.legend(fontsize=7)
    fig.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=140)
    plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--n-keys", type=int, default=3)
    ap.add_argument("--n-pos", type=int, default=400)
    ap.add_argument("--n-neg", type=int, default=2000)
    ap.add_argument("--n-calib", type=int, default=1000)
    ap.add_argument("--n-delta", type=int, default=200)
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()

    master = np.random.default_rng(args.seed)
    pos_all = split_paths("test_pos")
    neg_all = split_paths("test_neg")
    calib_all = split_paths("calib")
    pos_paths = pos_all[: args.n_pos]
    neg_paths = neg_all[: args.n_neg]
    calib_paths = calib_all[: args.n_calib]
    delta_paths = pos_all[: args.n_delta]

    # Shared attack / encode randomness across candidates (paired)
    angles_pos = master.uniform(0.0, 360.0, size=len(pos_paths))
    angles_neg = master.uniform(0.0, 360.0, size=len(neg_paths))
    encode_seeds = master.integers(0, 2**31 - 1, size=len(pos_paths))
    encode_seeds_delta = master.integers(0, 2**31 - 1, size=len(delta_paths))
    key_seeds = [int(master.integers(0, 2**31 - 1)) for _ in range(args.n_keys)]

    results = []
    for cand in DEFAULT_CANDIDATES:
        for kid, ks in enumerate(key_seeds):
            # Key seed depends on (m,w,eta) only — not L — so denser-search
            # comparisons share one key across L values.
            derived = (ks ^ (cand["m"] * 10007 + cand["w"] * 1009 + int(cand["eta"] * 1e6))) & 0x7FFFFFFF
            results.append(
                run_key(
                    cand,
                    kid,
                    derived,
                    pos_paths,
                    neg_paths,
                    calib_paths,
                    angles_pos,
                    angles_neg,
                    encode_seeds,
                    encode_seeds_delta,
                    delta_paths,
                )
            )

    # Aggregate per candidate across keys
    summary_rows = []
    for cand in DEFAULT_CANDIDATES:
        subset = [
            r
            for r in results
            if r["m"] == cand["m"]
            and r["w"] == cand["w"]
            and r["eta"] == cand["eta"]
            and r["L"] == cand["L"]
            and r.get("threshold") is not None
        ]
        if not subset:
            summary_rows.append({**cand, "n_keys_ok": 0, "all_keys_pass_arbitrary": False})
            continue
        tprs = [r["tpr_arbitrary"]["tpr"] for r in subset]
        mid_mins = [r["min_midpoint_tpr"] for r in subset]
        summary_rows.append(
            {
                **cand,
                "n_keys_ok": len(subset),
                "tpr_arbitrary_mean": float(np.mean(tprs)),
                "tpr_arbitrary_min": float(np.min(tprs)),
                "min_midpoint_tpr_min": float(np.min(mid_mins)),
                "all_keys_pass_arbitrary": all(r["passed_arbitrary"] for r in subset),
                "all_keys_pass_attacked_fpr": all(r["passed_attacked_fpr"] for r in subset),
                "fpr_none_upper_max": float(max(r["fpr_none"]["cp_upper"] for r in subset)),
                "fpr_att_upper_max": float(max(r["fpr_rot_jpeg_random"]["cp_upper"] for r in subset)),
            }
        )

    passed = [s for s in summary_rows if s.get("all_keys_pass_arbitrary")]
    if passed and all(s.get("min_midpoint_tpr_min", 0) >= TPR_TARGET for s in passed):
        decision = (
            f"{len(passed)}/{len(summary_rows)} candidates pass arbitrary-θ TPR "
            f"and midpoint δ TPR ≥ {TPR_TARGET} on all {args.n_keys} keys."
        )
    elif passed:
        decision = (
            f"{len(passed)}/{len(summary_rows)} candidates pass arbitrary-θ on all keys, "
            f"but at least one midpoint δ TPR dips below {TPR_TARGET}."
        )
    else:
        decision = "No candidate passed arbitrary-θ TPR ≥ 90% with FPR upper ≤ 1% on all keys."

    out = {
        "note": (
            "Prior three-metric bench used fixed rotation 180/m on the L-grid. "
            "This bench uses θ~Unif[0,360)+JPEG70 and a residual-δ TPR curve."
        ),
        "criteria": {
            "tpr_arbitrary": TPR_TARGET,
            "fpr_upper": FPR_ALPHA,
            "jpeg": JPEG_Q,
            "n_keys": args.n_keys,
            "paired": True,
        },
        "steps": STEPS,
        "candidates": DEFAULT_CANDIDATES,
        "per_key": results,
        "summary": summary_rows,
        "decision": decision,
    }

    if args.out:
        out_path = Path(args.out)
        if not out_path.is_absolute():
            out_path = Path(__file__).resolve().parents[1] / out_path
    else:
        out_path = Path(__file__).resolve().parents[2] / "figures" / "arbitrary_angle.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2))
    _plot_delta_curves(results, out_path.with_suffix(".png"))
    print(decision, flush=True)
    print(f"wrote {out_path}", flush=True)


if __name__ == "__main__":
    main()
