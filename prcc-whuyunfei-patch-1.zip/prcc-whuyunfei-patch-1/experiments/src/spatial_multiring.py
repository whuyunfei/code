"""Multi-ring spatial embedding.

Independent bits on b non-overlapping annuli; full angular freedom (no
conjugate duplication).

Modes
-----
mean : sector mean relative to the ring mean (host low-frequency remains).
radial : difference of two adjacent radial bands inside the sector.
qim : minimum push of that radial coefficient into a signed margin.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple

import numpy as np
from scipy.ndimage import rotate as nd_rotate


@dataclass
class MultiRingLayout:
    size: int
    annuli: List[Tuple[float, float]]
    m: int
    guard_frac: float = 0.15
    strength: float = 0.05
    # "mean" | "radial" | "qim" | "checker"
    mode: str = "mean"

    @property
    def b(self) -> int:
        return len(self.annuli)

    @property
    def n_bits(self) -> int:
        return self.b * self.m


def default_annuli(size: int, b: int) -> List[Tuple[float, float]]:
    r_max = size * 0.45
    r_min = size * 0.18
    width = (r_max - r_min) / b
    gap = width * 0.15
    out = []
    for j in range(b):
        a0 = r_min + j * width
        a1 = a0 + width - gap
        out.append((a0, a1))
    return out


def make_bits(layout: MultiRingLayout, rng: np.random.Generator) -> np.ndarray:
    return rng.integers(0, 2, size=(layout.b, layout.m), dtype=np.uint8)


def _polar_grids(size: int):
    yy, xx = np.mgrid[0:size, 0:size]
    cy = cx = (size - 1) / 2.0
    y = yy - cy
    x = xx - cx
    rad = np.sqrt(x * x + y * y)
    ang = (np.arctan2(y, x) + 2.0 * np.pi) % (2.0 * np.pi)
    return rad, ang, y, x


def _sector_mask(ang: np.ndarray, t: int, m: int, guard_frac: float) -> np.ndarray:
    bin_w = 2.0 * np.pi / m
    usable = (1.0 - guard_frac) * bin_w
    a0 = t * bin_w + 0.5 * guard_frac * bin_w
    a1 = a0 + usable
    if a1 <= 2.0 * np.pi:
        return (ang >= a0) & (ang < a1)
    return ((ang >= a0) & (ang < 2.0 * np.pi)) | (ang < (a1 - 2.0 * np.pi))


def _checker_template(y: np.ndarray, x: np.ndarray, scale: float = 3.0) -> np.ndarray:
    return np.sign(np.sin(scale * x) * np.sin(scale * y) + 1e-12)


def _bands(rad: np.ndarray, ang: np.ndarray, r0: float, r1: float, t: int, m: int, guard: float):
    ring = (rad >= r0) & (rad <= r1)
    sect = ring & _sector_mask(ang, t, m, guard)
    mid = 0.5 * (r0 + r1)
    inner = sect & (rad < mid)
    outer = sect & (rad >= mid)
    return ring, sect, inner, outer


def _radial_coeff(g: np.ndarray, inner: np.ndarray, outer: np.ndarray) -> float:
    if not np.any(inner) or not np.any(outer):
        return 0.0
    return float(g[outer].mean() - g[inner].mean())


def _push_diff(out: np.ndarray, inner: np.ndarray, outer: np.ndarray, delta: float) -> None:
    """Minimum-MSE change with outer_mean - inner_mean increased by ``delta``."""
    if delta == 0.0:
        return
    ni = int(np.count_nonzero(inner))
    no = int(np.count_nonzero(outer))
    if ni == 0 or no == 0:
        return
    # n_i di^2 + n_o do^2 minimized subject to do - di = delta.
    di = -no / (ni + no) * delta
    do = ni / (ni + no) * delta
    out[inner] += di
    out[outer] += do


def embed_weak(image: np.ndarray, layout: MultiRingLayout, bits: np.ndarray) -> np.ndarray:
    img = image.astype(np.float64).copy()
    gray = img.mean(axis=2) if img.ndim == 3 else img
    scale = 255.0 if gray.max() > 1.5 else 1.0
    g = gray / scale
    rad, ang, yy, xx = _polar_grids(layout.size)
    tmpl = _checker_template(yy, xx) if layout.mode == "checker" else None
    out = g.copy()
    bits = np.asarray(bits, dtype=np.uint8).reshape(layout.b, layout.m)
    for j, (r0, r1) in enumerate(layout.annuli):
        for t in range(layout.m):
            ring, sect, inner, outer = _bands(rad, ang, r0, r1, t, layout.m, layout.guard_frac)
            sign = 1.0 if bits[j, t] == 1 else -1.0
            if layout.mode == "checker":
                if not np.any(sect):
                    continue
                tloc = tmpl[sect] - tmpl[sect].mean()
                out[sect] = out[sect] + sign * layout.strength * tloc
            elif layout.mode == "mean":
                if not np.any(sect):
                    continue
                out[sect] = out[sect] + sign * layout.strength
            elif layout.mode == "radial":
                _push_diff(out, inner, outer, sign * layout.strength)
            elif layout.mode == "qim":
                coeff = _radial_coeff(out, inner, outer)
                target = sign * layout.strength
                if sign > 0.0 and coeff >= target:
                    delta = 0.0
                elif sign < 0.0 and coeff <= target:
                    delta = 0.0
                else:
                    delta = target - coeff
                _push_diff(out, inner, outer, delta)
            else:
                raise ValueError(f"unknown embed mode {layout.mode}")
    out = np.clip(out, 0.0, 1.0)
    if image.ndim == 3:
        delta = out - g
        res = np.clip(img / scale + delta[:, :, None], 0.0, 1.0)
        return res * scale
    return out * scale


def extract_soft(
    image: np.ndarray,
    layout: MultiRingLayout,
    angle_offset_deg: float = 0.0,
) -> np.ndarray:
    gray = image.mean(axis=2) if image.ndim == 3 else image
    scale = 255.0 if gray.max() > 1.5 else 1.0
    g = gray / scale
    rad, ang, yy, xx = _polar_grids(layout.size)
    ang = (ang + np.deg2rad(angle_offset_deg)) % (2.0 * np.pi)
    tmpl = _checker_template(yy, xx) if layout.mode == "checker" else None
    soft = np.zeros((layout.b, layout.m), dtype=np.float64)
    for j, (r0, r1) in enumerate(layout.annuli):
        for t in range(layout.m):
            ring, sect, inner, outer = _bands(rad, ang, r0, r1, t, layout.m, layout.guard_frac)
            if layout.mode == "checker":
                if not np.any(sect):
                    continue
                tloc = tmpl[sect] - tmpl[sect].mean()
                v = g[sect] - g[sect].mean()
                denom = (np.linalg.norm(tloc) * np.linalg.norm(v)) + 1e-12
                soft[j, t] = float(np.dot(tloc, v) / denom)
            elif layout.mode == "mean":
                if not np.any(sect) or not np.any(ring):
                    continue
                soft[j, t] = float(g[sect].mean() - g[ring].mean())
            elif layout.mode in ("radial", "qim"):
                soft[j, t] = _radial_coeff(g, inner, outer)
            else:
                raise ValueError(f"unknown embed mode {layout.mode}")
    return soft

def extract_bits(
    image: np.ndarray,
    layout: MultiRingLayout,
    angle_offset_deg: float = 0.0,
) -> np.ndarray:
    return (extract_soft(image, layout, angle_offset_deg) >= 0).astype(np.uint8)


def rotate_pad(image: np.ndarray, angle_deg: float) -> np.ndarray:
    return nd_rotate(image, angle=angle_deg, reshape=True, order=1, mode="constant", cval=0.0)


def rotate_keep_center(image: np.ndarray, angle_deg: float) -> np.ndarray:
    """Rotate on a fixed canvas about the pixel-grid center ``((n-1)/2, (n-1)/2)``.

    Unlike ``rotate_pad`` + crop, this does not expand then re-crop, so the
    content center stays at ``(127.5, 127.5)`` for ``n=256``.
    """
    return nd_rotate(image, angle=angle_deg, reshape=False, order=1, mode="constant", cval=0.0)


def expanded_rotate_shape(size: int, angle_deg: float) -> tuple[int, int]:
    """Output ``(h, w)`` of ``rotate_pad`` without building a full image."""
    dummy = np.zeros((size, size), dtype=np.float32)
    rot = nd_rotate(dummy, angle=angle_deg, reshape=True, order=0, mode="constant", cval=0.0)
    return int(rot.shape[0]), int(rot.shape[1])


def content_center_after_rot_crop(size: int, angle_deg: float) -> tuple[float, float]:
    """Where the original grid center lands after ``rotate_pad`` + center crop.

    Even expanded side → center stays ``(size-1)/2``; odd → shifts by +0.5.
    """
    h, w = expanded_rotate_shape(size, angle_deg)
    cy0 = cx0 = (size - 1) / 2.0
    cy = cy0 if (h % 2 == 0) else cy0 + 0.5
    cx = cx0 if (w % 2 == 0) else cx0 + 0.5
    return float(cy), float(cx)


def center_crop_or_pad(arr: np.ndarray, size: int) -> np.ndarray:
    if arr.ndim == 2:
        out = np.zeros((size, size), dtype=arr.dtype)
    else:
        out = np.zeros((size, size, arr.shape[2]), dtype=arr.dtype)
    h, w = arr.shape[:2]
    ys = max(0, (size - h) // 2)
    xs = max(0, (size - w) // 2)
    ye = ys + min(h, size)
    xe = xs + min(w, size)
    sy = max(0, (h - size) // 2)
    sx = max(0, (w - size) // 2)
    out[ys:ye, xs:xe] = arr[sy : sy + (ye - ys), sx : sx + (xe - xs)]
    return out


def psnr(ref: np.ndarray, dist: np.ndarray) -> float:
    scale = 255.0 if ref.max() > 1.5 else 1.0
    a = ref.astype(np.float64) / scale
    b = dist.astype(np.float64) / scale
    mse = float(np.mean((a - b) ** 2))
    if mse <= 1e-12:
        return 99.0
    return 10.0 * np.log10(1.0 / mse)


def ssim_simple(ref: np.ndarray, dist: np.ndarray) -> float:
    scale = 255.0 if ref.max() > 1.5 else 1.0
    x = ref.astype(np.float64)
    y = dist.astype(np.float64)
    if x.ndim == 3:
        x = x.mean(axis=2)
        y = y.mean(axis=2)
    x = x / scale
    y = y / scale
    c1, c2 = 0.01**2, 0.03**2
    mu_x, mu_y = x.mean(), y.mean()
    sig_x, sig_y = x.var(), y.var()
    sig_xy = float(np.mean((x - mu_x) * (y - mu_y)))
    return float(
        ((2 * mu_x * mu_y + c1) * (2 * sig_xy + c2))
        / ((mu_x**2 + mu_y**2 + c1) * (sig_x + sig_y + c2) + 1e-12)
    )


def ber(ref_bits: np.ndarray, got: np.ndarray) -> float:
    return float(np.mean(ref_bits != got))


def soft_mean_agree(ref_bits: np.ndarray, soft: np.ndarray) -> float:
    signs = 2 * ref_bits.astype(np.float64) - 1
    return float(np.mean(signs * soft))


def _unit_scale(image: np.ndarray) -> bool:
    """True when values are in about [0, 1] rather than [0, 255]."""
    return float(np.max(image)) <= 1.5


def to_uint8(image: np.ndarray) -> np.ndarray:
    arr = image.astype(np.float64)
    if _unit_scale(image):
        arr = arr * 255.0
    return np.clip(np.rint(arr), 0, 255).astype(np.uint8)


def from_uint8(arr: np.ndarray, like: np.ndarray) -> np.ndarray:
    out = arr.astype(np.float64)
    if _unit_scale(like):
        return out / 255.0
    return out


def jpeg_compress(image: np.ndarray, quality: int, rng: np.random.Generator | None = None) -> np.ndarray:
    """JPEG round-trip. ``rng`` is unused; compression failure is not replaced by noise."""
    del rng
    from PIL import Image
    import io

    arr = to_uint8(image)
    pil = Image.fromarray(arr, mode="L" if arr.ndim == 2 else "RGB")
    buf = io.BytesIO()
    pil.save(buf, format="JPEG", quality=int(quality))
    buf.seek(0)
    out = np.asarray(Image.open(buf))
    if out.ndim == 2 and image.ndim == 3:
        out = np.stack([out, out, out], axis=2)
    return from_uint8(out, image)


def apply_attack(
    image: np.ndarray,
    kind: str,
    angle_deg: float = 0.0,
    quality: int = 70,
    size: int | None = None,
) -> np.ndarray:
    size = int(size if size is not None else image.shape[0])
    if kind == "none":
        out = image
    elif kind == "rot":
        out = center_crop_or_pad(rotate_pad(image, angle_deg), size)
    elif kind == "rot_keep":
        out = rotate_keep_center(image, angle_deg)
    elif kind == "jpeg":
        out = jpeg_compress(image, quality)
    elif kind == "rot_jpeg":
        rot = center_crop_or_pad(rotate_pad(image, angle_deg), size)
        out = jpeg_compress(rot, quality)
    elif kind == "rot_jpeg_keep":
        out = jpeg_compress(rotate_keep_center(image, angle_deg), quality)
    else:
        raise ValueError(kind)
    if out.shape[0] != size:
        out = center_crop_or_pad(out, size)
    return out


def load_images(folder: Path, size: int, limit: int = 20) -> List[np.ndarray]:
    folder = Path(folder)
    if not folder.is_dir():
        raise FileNotFoundError(f"image folder missing: {folder}")
    paths = sorted(
        [p for p in folder.iterdir() if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".bmp"}]
    )
    if len(paths) < limit:
        raise FileNotFoundError(
            f"need >= {limit} images in {folder}, found {len(paths)}. Run: python -m src.bootstrap_images"
        )
    from PIL import Image

    imgs = []
    for p in paths[:limit]:
        im = Image.open(p).convert("RGB").resize((size, size), Image.BILINEAR)
        imgs.append(np.asarray(im).astype(np.float64))
    return imgs


def bits_to_codeword(bits: np.ndarray) -> np.ndarray:
    """Flatten (b,m) bits to length-bm vector (ring-major)."""
    return bits.reshape(-1).astype(np.uint8)
