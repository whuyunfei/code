"""Corrected four-condition eval on Kodak splits.

Conditions: none, rotation 22.5 deg, JPEG70, rotation+JPEG70.
Threshold from the calibration split only (unmarked, full residual search
with constant-block candidates removed). Test split is not used to pick it.
Unmarked test images go through the same attacks.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from . import block_circulant as bc
from .kodak_photos import load_split
from .residual_search import passes_lower, search_deltas, shared_grids
from .spatial_multiring import (
    MultiRingLayout,
    apply_attack,
    default_annuli,
    embed_weak,
    jpeg_compress,
    psnr,
)


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n <= 0:
        return float("nan"), float("nan")
    p = k / n
    den = 1.0 + z * z / n
    center = (p + z * z / (2 * n)) / den
    half = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return float(max(0.0, center - half)), float(min(1.0, center + half))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", type=int, default=256)
    ap.add_argument("--m", type=int, default=8)
    ap.add_argument("--b", type=int, default=4)
    ap.add_argument("--L", type=int, default=4)
    ap.add_argument("--strength", type=float, default=0.05)
    ap.add_argument("--guard", type=float, default=0.15)
    ap.add_argument("--eta", type=float, default=0.03)
    ap.add_argument("--w", type=int, default=1)
    ap.add_argument("--angle", type=float, default=22.5)
    ap.add_argument("--target-fpr", type=float, default=0.05)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", type=str, default="../figures/reeval.csv")
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    calib = load_split("calib", args.size)
    test = load_split("test", args.size)
    layout = MultiRingLayout(
        args.size, default_annuli(args.size, args.b), args.m, args.guard, args.strength, mode="mean"
    )
    tau = bc.suggest_tau(args.m, args.b * args.w, args.eta, 0.20)
    key = bc.keygen(args.m, args.b, args.w, tau, args.eta, rng)
    deltas, _angles = shared_grids(args.m, args.L)

    # Sanity: JPEG must not flatten a real photo.
    sample = jpeg_compress(test[0], 70)
    jpeg_span = (float(sample.min()), float(sample.max()))

    neg_scores = []
    for img in calib:
        r = search_deltas(key, img, layout, deltas, constant_reject=True)
        neg_scores.append(r.best_score)
    thr = float(np.quantile(neg_scores, args.target_fpr))

    attacks = ("none", "rot", "jpeg", "rot_jpeg")
    rows = []
    for kind in attacks:
        hit = 0
        false = 0
        psnrs = []
        for img in test:
            c = bc.encode(key, rng=rng)
            marked = embed_weak(img, layout, c.reshape(args.b, args.m))
            attacked = apply_attack(marked, kind, args.angle, 70, args.size)
            psnrs.append(psnr(img, attacked if kind != "none" else marked))
            r = search_deltas(key, attacked, layout, deltas, constant_reject=True)
            hit += int(passes_lower(r, thr))
            plain = apply_attack(img, kind, args.angle, 70, args.size)
            r0 = search_deltas(key, plain, layout, deltas, constant_reject=True)
            false += int(passes_lower(r0, thr))
        n = len(test)
        tpr_lo, tpr_hi = wilson(hit, n)
        fpr_lo, fpr_hi = wilson(false, n)
        row = {
            "attack": kind,
            "angle": args.angle if kind in ("rot", "rot_jpeg") else 0.0,
            "tpr": hit / n,
            "tpr_lo": tpr_lo,
            "tpr_hi": tpr_hi,
            "fpr_attacked_unmarked": false / n,
            "fpr_lo": fpr_lo,
            "fpr_hi": fpr_hi,
            "hits": hit,
            "false": false,
            "n": n,
            "thr": thr,
            "psnr_mean": float(np.mean(psnrs)),
            "jpeg_out_min": jpeg_span[0],
            "jpeg_out_max": jpeg_span[1],
        }
        rows.append(row)
        print(
            f"{kind:8} TPR={row['tpr']:.2f} [{tpr_lo:.2f},{tpr_hi:.2f}] "
            f"FPR={row['fpr_attacked_unmarked']:.2f} [{fpr_lo:.2f},{fpr_hi:.2f}] "
            f"PSNR={row['psnr_mean']:.1f}"
        )

    out = Path(args.out)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wri.writeheader()
        wri.writerows(rows)
    summary = {
        "csv": str(out),
        "note": "Previous JPEG70 TPR=0 is void: jpeg_compress scaled 0-255 images by 255 again.",
        "threshold": "quantile of calibration unmarked scores; test split not used",
        "detector": "shared residual grid, constant-block candidates excluded",
        "target_fpr": args.target_fpr,
        "n_test": len(test),
        "fpr_resolution": 1.0 / len(test),
        "jpeg_sample_minmax": jpeg_span,
        "not_1e-3": "n=8 cannot support an FPR of 1e-3",
    }
    out.with_suffix(".json").write_text(json.dumps(summary, indent=2))
    print(f"wrote {out}")
    print(f"jpeg sample range {jpeg_span}")


if __name__ == "__main__":
    main()
