"""Experiment 1: pure-code diagnosis without images in the detector loop.

Honest classes: noiseless coset, encode noise, encode noise + measured correlated
channel errors, encode noise + matched-BER BSC. Null: min score over L uniform
strings. Thresholds are the largest integer with empirical FPR <= 1e-2.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from . import block_circulant as bc
from .coco_photos import load_split
from .fast_radial import make_layout, push_to_margin, radial_soft
from .integer_threshold import hist_counts, largest_integer_threshold
from .security_probes import probe_multi_sample


TARGET_ACCEPT = 0.90
FPR_ALPHA = 1e-2
N_KEYS = 5
N_HONEST = 400
N_NULL = 2000


def _min_uniform(key: bc.BlockCirculantKey, rng: np.random.Generator, L: int) -> float:
    best = float("inf")
    n = key.b * key.m
    for _ in range(L):
        y = rng.integers(0, 2, size=n, dtype=np.uint8)
        best = min(best, float(bc.detect_score(key, y)))
    return best


def _collect_error_patterns(
    m: int,
    b: int,
    w: int,
    eta: float,
    n_patterns: int,
    rng: np.random.Generator,
    images: list,
) -> tuple[list[np.ndarray], float]:
    """Known-angle extract XOR codeword, after push-to-margin at ~35 dB strength."""
    size = int(images[0].shape[0])
    strength = 0.03 if m <= 16 else 0.02
    layout = make_layout(size, m, b, 0.15, strength)
    tau = bc.suggest_tau(m, b * w, eta if eta > 0 else 0.03, 0.05)
    key = bc.keygen(m, b, w, tau, eta if eta > 0 else 0.03, rng)
    patterns = []
    bers = []
    for i in range(n_patterns):
        img = images[i % len(images)]
        c = bc.encode(key, rng=rng, add_noise=True).reshape(b, m)
        marked = push_to_margin(img, layout, c)
        hat = (radial_soft(marked, layout, 0.0) >= 0).astype(np.uint8)
        err = (hat ^ c).reshape(-1)
        patterns.append(err)
        bers.append(float(err.mean()))
    return patterns, float(np.mean(bers))


def _eval_cell(m, b, w, eta, L, rng, images) -> dict:
    patterns, mean_ber = _collect_error_patterns(m, b, w, max(eta, 0.03), min(80, len(images)), rng, images)
    expected = m * bc.q_bsc(eta, b * w) if eta > 0 else 0.0
    per_key = []
    for _k in range(N_KEYS):
        tau = bc.suggest_tau(m, b * w, eta if eta > 0 else 0.03, 0.05)
        key = bc.keygen(m, b, w, tau, eta, rng)
        null = [_min_uniform(key, rng, L) for _ in range(N_NULL)]
        thr = largest_integer_threshold(null, FPR_ALPHA)
        noiseless = []
        noisy = []
        channel = []
        bsc = []
        for i in range(N_HONEST):
            c0 = bc.encode(key, rng=rng, add_noise=False)
            noiseless.append(bc.detect_score(key, c0))
            c = c0 if eta == 0 else bc.encode(key, rng=rng, add_noise=True)
            noisy.append(bc.detect_score(key, c))
            err = patterns[i % len(patterns)]
            channel.append(bc.detect_score(key, np.bitwise_xor(c, err)))
            e_bsc = (rng.random(len(c)) < mean_ber).astype(np.uint8)
            bsc.append(bc.detect_score(key, np.bitwise_xor(c, e_bsc)))

        def accept(scores):
            if thr is None:
                return 0.0
            return float(np.mean(np.asarray(scores) <= thr))

        row = {
            "threshold": thr,
            "fpr_emp": float(np.mean(np.asarray(null) <= thr)) if thr is not None else float("nan"),
            "accept_noiseless": accept(noiseless),
            "accept_encode_noise": accept(noisy),
            "accept_channel": accept(channel),
            "accept_bsc": accept(bsc),
            "hist_noiseless": hist_counts(noiseless, m),
            "hist_encode_noise": hist_counts(noisy, m),
            "hist_channel": hist_counts(channel, m),
            "hist_null": hist_counts(null, m),
            "mean_score_encode": float(np.mean(noisy)),
            "mean_score_channel": float(np.mean(channel)),
        }
        if row["accept_encode_noise"] >= TARGET_ACCEPT and (eta < 0.03 or w == 1):
            row["multi_sample"] = probe_multi_sample(key, rng, n_train=20, n_test=20)
        per_key.append(row)

    def avg(field):
        vals = [k[field] for k in per_key if k[field] is not None and np.isfinite(k[field])]
        return float(np.mean(vals)) if vals else float("nan")

    thr_none = sum(1 for k in per_key if k["threshold"] is None)
    summary = {
        "m": m,
        "w": w,
        "eta": eta,
        "b": b,
        "L": L,
        "W": b * w,
        "expected_score_encode_only": expected,
        "measured_channel_ber": mean_ber,
        "n_keys": N_KEYS,
        "keys_without_threshold": thr_none,
        "accept_noiseless": avg("accept_noiseless"),
        "accept_encode_noise": avg("accept_encode_noise"),
        "accept_channel": avg("accept_channel"),
        "accept_bsc": avg("accept_bsc"),
        "mean_score_encode": avg("mean_score_encode"),
        "mean_score_channel": avg("mean_score_channel"),
        "near_target_encode": bool(avg("accept_encode_noise") >= TARGET_ACCEPT),
        "near_target_channel": bool(avg("accept_channel") >= TARGET_ACCEPT),
        "per_key": per_key,
        "note_eta0": "eta=0 and reduced noise locate loss only; not security parameters",
    }
    print(
        f"m={m} w={w} eta={eta:.2f} E[sc]={expected:.2f} "
        f"acc_enc={summary['accept_encode_noise']:.2f} "
        f"acc_ch={summary['accept_channel']:.2f} "
        f"acc_bsc={summary['accept_bsc']:.2f} ber={mean_ber:.3f}"
    )
    return summary


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", type=int, default=256)
    ap.add_argument("--b", type=int, default=4)
    ap.add_argument("--L", type=int, default=4)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", type=str, default="../figures/pure_code.json")
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    images = load_split("tune", args.size, limit=80)
    rows = []
    for m in (8, 16, 32):
        for w in (1, 3):
            for eta in (0.0, 0.01, 0.03):
                rows.append(_eval_cell(m, args.b, w, eta, args.L, rng, images))
    any_ok = any(r["near_target_encode"] for r in rows if r["eta"] >= 0.03 and r["w"] == 3)
    any_ok_reduced = any(r["near_target_encode"] for r in rows)
    summary = {
        "target_accept": TARGET_ACCEPT,
        "fpr_alpha": FPR_ALPHA,
        "continue_to_two_row": True,  # experiment 2 always runs as the structural fix
        "pure_code_meets_target_at_eta003_w3": any_ok,
        "pure_code_meets_target_any": any_ok_reduced,
        "decision": (
            "At least one pure-code cell reaches 90% under the FPR budget; still run two-row H to raise check count without shrinking sectors."
            if any_ok
            else "No w=3, eta=0.03 cell reaches 90% under the FPR budget. Change the code (two-row H); pause image detection for this single-row H."
        ),
        "rows": rows,
        "usenix_note": "Lowering eta or w for detection is not a security claim; see USENIX Security 2026 analysis of practical LDPC-PRC.",
    }
    out = Path(args.out)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(summary, indent=2))
    print(summary["decision"])
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
