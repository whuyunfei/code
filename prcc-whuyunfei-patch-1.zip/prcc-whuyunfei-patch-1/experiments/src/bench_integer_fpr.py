"""Experiment 3: most permissive integer threshold, then an independent test.

Runs only for cells that passed the tune-split screen. The same frozen threshold
is used for clean and attacked images.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import shift as nd_shift

from . import block_circulant as bc
from .coco_photos import load_image, split_paths
from .fast_radial import make_layout, push_to_margin
from .integer_threshold import clopper_pearson, clopper_upper, largest_integer_threshold
from .residual_search import shared_grids
from .search_scores import scores_over_angles
from .spatial_multiring import apply_attack, center_crop_or_pad, rotate_pad


SCREEN_FPR = 1e-2
SCREEN_TPR = 0.90


def _best(key, image, layout, deltas) -> float:
    return scores_over_angles(key, image, layout, deltas).best


def _attack(image, kind: str, angle: float, size: int) -> np.ndarray:
    if kind == "offset":
        shifted = nd_shift(
            image,
            shift=(3.0, 3.0, 0) if image.ndim == 3 else (3.0, 3.0),
            order=1,
            mode="constant",
        )
        return center_crop_or_pad(rotate_pad(shifted, angle), size)
    return apply_attack(image, kind, angle, 70, size)


def _rates(hits_per_image: list[float]) -> dict:
    """Image is the unit. An image counts when at least half its encodings pass."""
    detected = np.asarray(hits_per_image) >= 0.5
    k = int(detected.sum())
    n = len(detected)
    lo, hi = clopper_pearson(k, n)
    return {"k": k, "n": n, "rate": k / n if n else float("nan"), "cp_lo": lo, "cp_hi": hi}


def _one_attack(key, paths_neg, paths_pos, layout, deltas, thr, kind, angle, size, b, n_enc, rng):
    neg_hits = []
    for path in paths_neg:
        img = _attack(load_image(path, size), kind, angle, size)
        neg_hits.append(_best(key, img, layout, deltas) <= thr)
    k = int(np.sum(neg_hits))
    n = len(neg_hits)
    lo, hi = clopper_pearson(k, n)
    per_image = []
    enc_hits = 0
    enc_n = 0
    for path in paths_pos:
        img = load_image(path, size)
        flags = []
        for _ in range(n_enc):
            code = bc.encode(key, rng=rng).reshape(b, layout.m)
            marked = push_to_margin(img, layout, code)
            attacked = _attack(marked, kind, angle, size)
            ok = _best(key, attacked, layout, deltas) <= thr
            flags.append(ok)
            enc_hits += int(ok)
            enc_n += 1
        per_image.append(float(np.mean(flags)))
    pos = _rates(per_image)
    pos["encoding_rate"] = enc_hits / enc_n if enc_n else float("nan")
    return {
        "fpr_k": k,
        "fpr_n": n,
        "fpr": k / n if n else float("nan"),
        "fpr_cp_lo": lo,
        "fpr_cp_hi": hi,
        "fpr_cp_upper": clopper_upper(k, n),
        "tpr": pos,
    }


def eval_cell(spec: dict, n_enc: int, rng: np.random.Generator) -> dict:
    m, w, size = int(spec["m"]), int(spec["w"]), int(spec["size"])
    b, L, eta, guard = 4, 4, 0.03, 0.15
    strength = float(spec["strength"])
    layout = make_layout(size, m, b, guard, strength)
    tau = bc.suggest_tau(m, b * w, eta, 0.05)
    key = bc.keygen(m, b, w, tau, eta, rng)
    deltas, _ = shared_grids(m, L)
    angle = 180.0 / m  # one half-step
    calib_scores = []
    for path in split_paths("calib"):
        img = load_image(path, size)
        calib_scores.append(_best(key, img, layout, deltas))
    thr = largest_integer_threshold(calib_scores, SCREEN_FPR)
    row = {
        "m": m,
        "w": w,
        "size": size,
        "strength": strength,
        "n_bits": b * m,
        "n_checks": m,
        "n_calib": len(calib_scores),
        "angle_deg": angle,
        "threshold": thr,
        "attacks": {},
    }
    if thr is None:
        row["failed"] = "no integer threshold meets empirical FPR <= 1e-2 on the calibration split"
        print(f"m={m} w={w} no feasible threshold")
        return row

    neg_paths = split_paths("test_neg")
    pos_paths = split_paths("test_pos")
    for kind in ("none", "rot", "jpeg", "rot_jpeg"):
        stats = _one_attack(key, neg_paths, pos_paths, layout, deltas, thr, kind, angle, size, b, n_enc, rng)
        row["attacks"][kind] = stats
        print(
            f"m={m} w={w} {kind:8} FPR={stats['fpr_k']}/{stats['fpr_n']} "
            f"upper={stats['fpr_cp_upper']:.4f} TPR={stats['tpr']['rate']:.3f}"
        )
    clean_upper = row["attacks"]["none"]["fpr_cp_upper"]
    tpr_rj = row["attacks"]["rot_jpeg"]["tpr"]["rate"]
    row["passed_screen"] = bool(clean_upper <= SCREEN_FPR and tpr_rj >= SCREEN_TPR)
    if row["passed_screen"]:
        stats = _one_attack(key, neg_paths, pos_paths, layout, deltas, thr, "offset", angle, size, b, n_enc, rng)
        row["attacks"]["offset"] = stats
        print(
            f"m={m} w={w} offset   FPR={stats['fpr_k']}/{stats['fpr_n']} "
            f"upper={stats['fpr_cp_upper']:.4f} TPR={stats['tpr']['rate']:.3f}"
        )
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scan", type=str, default="../figures/capacity_scan.json")
    ap.add_argument("--encodings", type=int, default=2)
    ap.add_argument("--seed", type=int, default=2)
    ap.add_argument("--out", type=str, default="../figures/integer_fpr.json")
    args = ap.parse_args()
    scan_path = Path(args.scan)
    if not scan_path.is_absolute():
        scan_path = Path(__file__).resolve().parents[1] / args.scan
    scan = json.loads(scan_path.read_text())
    out = Path(args.out)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    if not scan.get("continue"):
        payload = {
            "skipped": True,
            "reason": "capacity scan did not produce a w=3 cell inside the budget with usable BER and unmarked mass at 0 below 1e-2",
        }
        out.write_text(json.dumps(payload, indent=2))
        print(json.dumps(payload))
        return

    rng = np.random.default_rng(args.seed)
    rows = [eval_cell(spec, args.encodings, rng) for spec in scan["candidates"]]
    passed = [
        {"m": r["m"], "w": r["w"], "size": r["size"], "strength": r["strength"], "threshold": r.get("threshold")}
        for r in rows
        if r.get("passed_screen")
    ]
    payload = {
        "skipped": False,
        "screen": {"fpr_upper": SCREEN_FPR, "rot_jpeg_tpr": SCREEN_TPR},
        "rows": rows,
        "passed_screen": passed,
        "challenge_1e-3": "not started; requires about 10,000 fresh negatives after this screen",
    }
    out.write_text(json.dumps(payload, indent=2))
    print(f"passed={passed}")
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
