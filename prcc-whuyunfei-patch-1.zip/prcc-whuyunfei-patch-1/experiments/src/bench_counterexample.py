"""Reproduce full-circulant trivial-kernel counterexample."""

from __future__ import annotations

import numpy as np

from .block_circulant import circulant_invertible, gf2_rank
from .circulant_code import encode, keygen


def main() -> None:
    rng = np.random.default_rng(1)
    n, w, tau = 256, 7, 30
    key = keygen(n=n, w=w, tau=tau, eta=0.0, rng=rng)
    rank = gf2_rank(key.H)
    print(f"n={n} w={w} tau={tau}")
    print(f"rank(H)={rank} full_rank={rank == n} unit_generator={circulant_invertible(key.h)}")
    print(f"ker_dim={n - rank}")
    for i in range(3):
        c = encode(key, rng=rng, max_flips=30_000, restarts=6)
        wt = int(((key.H @ c) % 2).sum())
        print(f"greedy trial {i}: syndrome_wt={wt}  meets_tau={wt <= tau}")


if __name__ == "__main__":
    main()
