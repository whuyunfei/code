"""Blind residual search on two-coset lattice hard bits."""

from __future__ import annotations

from typing import Sequence

import numpy as np

from .block_circulant import BlockCirculantKey, detect_score
from .lattice_carrier import extract_lattice
from .search_scores import AngleScores, score_bits
from .spatial_multiring import MultiRingLayout


def scores_over_angles_lattice(
    key: BlockCirculantKey,
    image: np.ndarray,
    layout: MultiRingLayout,
    angles: Sequence[float],
    step: float,
    constant_reject: bool = True,
    centers: Sequence[tuple[float, float]] | None = None,
) -> AngleScores:
    """Min syndrome over residual angles; optionally over extract centers too."""
    center_list: Sequence[tuple[float, float] | None]
    if centers is None:
        center_list = [None]
    else:
        center_list = list(centers)
    per = []
    best = float("inf")
    n_valid = 0
    n_rejected = 0
    bits_at_best = None
    for center in center_list:
        for ang in angles:
            y, _soft = extract_lattice(image, layout, float(ang), step, center=center)
            y = y.reshape(-1)
            sc = score_bits(key, y, constant_reject)
            per.append(sc)
            if sc is None:
                n_rejected += 1
                continue
            n_valid += 1
            if sc < best:
                best = float(sc)
                bits_at_best = y
    if n_valid == 0:
        best = float("inf")
    return AngleScores(per, best, n_valid, n_rejected, bits_at_best)


def known_angle_ber(
    image: np.ndarray,
    layout: MultiRingLayout,
    bits: np.ndarray,
    step: float,
    angle_offset_deg: float,
    center: tuple[float, float] | None = None,
) -> float:
    hat, _ = extract_lattice(image, layout, angle_offset_deg, step, center=center)
    return float(np.mean(hat.reshape(-1) != np.asarray(bits).reshape(-1)))


def known_angle_score(
    key: BlockCirculantKey,
    image: np.ndarray,
    layout: MultiRingLayout,
    step: float,
    angle_offset_deg: float,
    constant_reject: bool = True,
    center: tuple[float, float] | None = None,
) -> float | None:
    """Syndrome score at a single extract angle (no residual search)."""
    y, _ = extract_lattice(image, layout, float(angle_offset_deg), step, center=center)
    sc = score_bits(key, y.reshape(-1), constant_reject)
    return float(sc) if sc is not None else None


def codeword_score(key: BlockCirculantKey, bits: np.ndarray) -> int:
    return detect_score(key, np.asarray(bits, dtype=np.uint8).reshape(-1))
