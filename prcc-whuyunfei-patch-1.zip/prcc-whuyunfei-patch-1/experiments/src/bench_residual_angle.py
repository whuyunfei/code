"""Phase 3: residual-angle search curves on multi-ring images."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from . import block_circulant as bc
from .residual_search import (
    search_full_angle,
    search_residual,
    verify_integer_absorption,
)
from .security_probes import detect_with_constant_reject
from .spatial_multiring import (
    MultiRingLayout,
    center_crop_or_pad,
    default_annuli,
    embed_weak,
    extract_bits,
    load_images,
    rotate_pad,
)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--images", type=str, default="data/images")
    ap.add_argument("--size", type=int, default=256)
    ap.add_argument("--n-images", type=int, default=12)
    ap.add_argument("--m", type=int, default=8)
    ap.add_argument("--b", type=int, default=4)
    ap.add_argument("--w", type=int, default=1)
    ap.add_argument("--eta", type=float, default=0.03)
    ap.add_argument("--strength", type=float, default=0.05)
    ap.add_argument("--guard", type=float, default=0.15)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", type=str, default="../figures/residual_angle.csv")
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    img_dir = Path(__file__).resolve().parents[1] / args.images
    images = load_images(img_dir, args.size, limit=args.n_images)

    m, b = args.m, args.b
    layout = MultiRingLayout(
        size=args.size,
        annuli=default_annuli(args.size, b),
        m=m,
        guard_frac=args.guard,
        strength=args.strength,
        mode="mean",
    )
    tau = bc.suggest_tau(m, b * args.w, args.eta, 0.20)
    key = bc.keygen(m, b, args.w, tau, args.eta, rng)

    # Synthetic absorption check
    c0 = bc.encode(key, rng=rng, add_noise=False)
    abs_ok = verify_integer_absorption(key, c0, m)
    print(f"integer_absorption_ok={abs_ok} tau={tau}")

    Ls = [1, 2, 4, 8, 16]
    # Random angles and half-bin
    test_angles = [0.5 * (360.0 / m), 15.0, 37.0, 90.0, 123.4]
    rows = []

    known_rate = {a: 0.0 for a in test_angles}
    # Known-angle upper bound
    n_trials = min(len(images), args.n_images)
    for a in test_angles:
        ok = 0
        for img in images[:n_trials]:
            c = bc.encode(key, rng=rng)
            bits = c.reshape(b, m)
            marked = embed_weak(img, layout, bits)
            rot = marked if abs(a) < 1e-12 else center_crop_or_pad(rotate_pad(marked, a), args.size)
            got = extract_bits(rot, layout, angle_offset_deg=a).reshape(-1)
            ok += int(detect_with_constant_reject(key, got))
        known_rate[a] = ok / n_trials
        print(f"known_angle ang={a:.1f} det={known_rate[a]:.3f}")

    for L in Ls:
        for use_soft in (False, True):
            for a in test_angles:
                ok_res = ok_full = 0
                score_match = 0
                for img in images[:n_trials]:
                    c = bc.encode(key, rng=rng)
                    bits = c.reshape(b, m)
                    marked = embed_weak(img, layout, bits)
                    rot = center_crop_or_pad(rotate_pad(marked, a), args.size)
                    # Blind residual search
                    r = search_residual(key, rot, layout, L, use_soft=use_soft)
                    ok_res += int(r.accepted)
                    # Diagnostic full search with same density per bin
                    f = search_full_angle(key, rot, layout, L_per_bin=L, use_soft=use_soft)
                    ok_full += int(f.accepted)
                    # Residual vs full best score agreement (tolerance)
                    if abs(r.best_score - f.best_score) <= 1e-6 + (0 if use_soft else 0):
                        score_match += 1
                    elif (not use_soft) and int(r.best_score) == int(f.best_score):
                        score_match += 1
                row = {
                    "L": L,
                    "soft": int(use_soft),
                    "angle": a,
                    "det_residual": ok_res / n_trials,
                    "det_full": ok_full / n_trials,
                    "det_known": known_rate[a],
                    "score_match_frac": score_match / n_trials,
                    "n": n_trials,
                }
                rows.append(row)
                print(
                    f"L={L} soft={use_soft} ang={a:.1f} "
                    f"res={row['det_residual']:.2f} full={row['det_full']:.2f} "
                    f"known={row['det_known']:.2f} match={row['score_match_frac']:.2f}"
                )

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wri.writeheader()
        wri.writerows(rows)

    # Continue if some L<=8 residual hard reaches >= 0.9 * known on half-bin
    half = 0.5 * (360.0 / m)
    cont = False
    best_L = None
    for L in Ls:
        if L > 8:
            continue
        sub = [r for r in rows if r["L"] == L and r["soft"] == 0 and abs(r["angle"] - half) < 1e-6]
        if not sub:
            continue
        r0 = sub[0]
        if r0["det_known"] > 0 and r0["det_residual"] >= 0.9 * r0["det_known"]:
            cont = True
            best_L = L
            break
        if r0["det_residual"] >= 0.7 and r0["det_known"] >= 0.7:
            cont = True
            best_L = L
            break

    summary = {
        "integer_absorption_ok": abs_ok,
        "best_L": best_L,
        "continue": cont,
        "csv": str(out),
        "layout": {"m": m, "b": b, "strength": args.strength, "guard": args.guard},
    }
    out.with_suffix(".json").write_text(json.dumps(summary, indent=2))
    print(f"wrote {out}")
    print(f"gate continue={cont} best_L={best_L}")


if __name__ == "__main__":
    main()
