"""Experiment 2: two-row block-circulant H at fixed sector count m."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from .block_circulant import q_bsc
from .integer_threshold import hist_counts, largest_integer_threshold
from .security_probes import fit_min_xor_relation, relation_score
from .two_row_h import detect_score, encode, keygen_two_row, score_invariant_under_Tk


FPR_ALPHA = 1e-2
TARGET = 0.90
N_KEYS = 5
N_HONEST = 400
N_NULL = 2000


def _min_uniform(key, rng, L: int) -> float:
    best = float("inf")
    n = key.b * key.m
    for _ in range(L):
        y = rng.integers(0, 2, size=n, dtype=np.uint8)
        best = min(best, float(detect_score(key, y)))
    return best


def _probe_two_row(key, rng):
    train = [encode(key, rng=rng) for _ in range(20)]
    test = [encode(key, rng=rng) for _ in range(20)]
    rel = fit_min_xor_relation(train, key.m)
    score_same = relation_score(test, key.m, rel)
    w = int(key.generators[0][0].sum())
    try:
        key2 = keygen_two_row(key.m, key.b, w, key.eta, rng)
    except Exception:
        key2 = key
    fresh = [encode(key2, rng=rng) for _ in range(20)]
    uni = [rng.integers(0, 2, size=key.b * key.m, dtype=np.uint8) for _ in range(20)]
    return {
        "score_same_key": score_same,
        "score_fresh_key": relation_score(fresh, key.m, rel),
        "score_uniform": relation_score(uni, key.m, rel),
        "gap_vs_uniform": float(relation_score(uni, key.m, rel) - score_same),
        "gap_vs_fresh": float(relation_score(fresh, key.m, rel) - score_same),
    }


def eval_cell(m, b, w, eta, L, rng) -> dict:
    keygen_ok = 0
    tries = 0
    per_key = []
    while keygen_ok < N_KEYS and tries < N_KEYS * 30:
        tries += 1
        try:
            key = keygen_two_row(m, b, w, eta, rng)
        except RuntimeError:
            continue
        keygen_ok += 1
        c0 = encode(key, rng=rng, add_noise=False)
        inv = score_invariant_under_Tk(key, c0)
        null = [_min_uniform(key, rng, L) for _ in range(N_NULL)]
        thr = largest_integer_threshold(null, FPR_ALPHA)
        noiseless = [detect_score(key, encode(key, rng=rng, add_noise=False)) for _ in range(N_HONEST)]
        if eta > 0:
            noisy = [detect_score(key, encode(key, rng=rng, add_noise=True)) for _ in range(N_HONEST)]
        else:
            noisy = list(noiseless)

        def acc(sc):
            return float(np.mean(np.asarray(sc) <= thr)) if thr is not None else 0.0

        item = {
            "rank": key.rank,
            "kernel_dim": key.kernel_dim,
            "invariant": inv,
            "threshold": thr,
            "accept_noiseless": acc(noiseless),
            "accept_encode_noise": acc(noisy),
            "mean_score_encode": float(np.mean(noisy)),
            "hist_encode": hist_counts(noisy, key.n_rows * m),
            "hist_null": hist_counts(null, key.n_rows * m),
        }
        if item["accept_encode_noise"] >= TARGET:
            item["multi_sample"] = _probe_two_row(key, rng)
        per_key.append(item)

    # Row 0 weight b*w; row 1 bumps the last block by 1 when w is odd (even parity).
    w1 = b * w
    w2 = b * w + (1 if w % 2 == 1 else 0)
    expected = m * q_bsc(eta, w1) + m * q_bsc(eta, w2) if eta > 0 else 0.0

    def avg(field):
        vals = [k[field] for k in per_key if k.get(field) is not None and np.isfinite(k[field])]
        return float(np.mean(vals)) if vals else float("nan")

    row = {
        "m": m,
        "w": w,
        "eta": eta,
        "b": b,
        "L": L,
        "n_checks": 2 * m,
        "n_bits": b * m,
        "expected_score_encode_only": expected,
        "keygen_successes": keygen_ok,
        "keygen_attempts": tries,
        "accept_noiseless": avg("accept_noiseless"),
        "accept_encode_noise": avg("accept_encode_noise"),
        "mean_score_encode": avg("mean_score_encode"),
        "mean_kernel_dim": avg("kernel_dim"),
        "all_invariant": all(k["invariant"] for k in per_key) if per_key else False,
        "near_target": bool(avg("accept_encode_noise") >= TARGET) if per_key else False,
        "per_key": per_key,
    }
    print(
        f"two-row m={m} w={w} eta={eta:.2f} keys={keygen_ok}/{tries} "
        f"E[sc]={expected:.2f} acc={row['accept_encode_noise']:.2f} ker={row['mean_kernel_dim']:.1f}"
    )
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--b", type=int, default=4)
    ap.add_argument("--L", type=int, default=4)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", type=str, default="../figures/two_row.json")
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    rows = []
    for m in (8, 16):
        for w in (1, 3):
            for eta in (0.0, 0.01, 0.03):
                rows.append(eval_cell(m, args.b, w, eta, args.L, rng))
    winners = [r for r in rows if r["near_target"] and r["w"] == 3 and r["eta"] >= 0.01]
    summary = {
        "target": TARGET,
        "fpr_alpha": FPR_ALPHA,
        "winners": [
            {"m": r["m"], "w": r["w"], "eta": r["eta"], "accept": r["accept_encode_noise"]} for r in winners
        ],
        "decision": (
            "Two-row H reaches the pure-code accept target at fixed sector count for at least one (m,w,eta)."
            if winners
            else "Two-row H did not reach 90% accept under the FPR budget for w=3 with eta>0. Large sectors alone do not buy enough usable checks under this noise."
        ),
        "rows": rows,
    }
    out = Path(args.out)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(summary, indent=2))
    print(summary["decision"])
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
