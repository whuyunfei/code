"""Lock configuration C as the formal three-metric baseline.

Frozen: m=64, w=1, η=0, step≈0.197, L=8, blind centers {(127.5,127.5),(128,128)}
→ 16 extract candidates. Pad+crop rot+JPEG70 attack (original geometry).

1) Per key: calibrate on unmarked + random-rot+JPEG calib negatives; pick the
   largest integer threshold with both calib FPRs ≤ 0.5% and tune TPR ≥ 90%.
2) Freeze and evaluate on full holdout (3000 neg / ~600 pos). Test is judgment
   only — retune only on calibration.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from . import block_circulant as bc
from .coco_photos import load_image, split_paths
from .fast_radial import make_layout
from .integer_threshold import clopper_pearson, clopper_upper
from .lattice_carrier import embed_lattice
from .lattice_detect import scores_over_angles_lattice
from .residual_search import shared_grids
from .spatial_multiring import apply_attack, content_center_after_rot_crop, expanded_rotate_shape, psnr


M, W, ETA, B = 64, 1, 0.0, 4
GUARD = 0.15
SIZE = 256
STEP = 0.19745071411132814
L = 8
FPR_TEST = 1e-2
FPR_CALIB_TARGET = 5e-3  # leave margin for test CP upper
TPR_TARGET = 0.90
JPEG_Q = 70
DELTA = 360.0 / M
MAX_FALSE_ACCEPTS_3000 = 20  # Clopper–Pearson upper ≤ 1% requires k ≤ 20
DEFAULT_CENTER = ((SIZE - 1) / 2.0, (SIZE - 1) / 2.0)
ALT_CENTER = (DEFAULT_CENTER[0] + 0.5, DEFAULT_CENTER[1] + 0.5)
BLIND_CENTERS = (DEFAULT_CENTER, ALT_CENTER)


def _make_key(rng: np.random.Generator) -> bc.BlockCirculantKey:
    tau = bc.suggest_tau(M, B * W, 0.03, 0.05)
    return bc.keygen(M, B, W, tau, ETA, rng)


def _min_score(key, img, layout) -> float:
    deltas, _ = shared_grids(M, L)
    return scores_over_angles_lattice(
        key, img, layout, deltas, STEP, centers=BLIND_CENTERS
    ).best


def _probes() -> List[dict]:
    bin_w = DELTA / L
    out, seen = [], set()

    def add(delta: float, tag: str):
        d = float(delta % DELTA)
        k = round(d, 10)
        if k in seen:
            return
        seen.add(k)
        out.append({"delta": d, "tag": tag})

    for i in range(L):
        add(i * bin_w, "grid")
        add((i + 0.5) * bin_w, "mid")
    add(0.37 * bin_w, "off")
    add(0.73 * bin_w, "off")
    return sorted(out, key=lambda r: r["delta"])


def collect_neg_scores(
    key, layout, paths: Sequence[Path], angles: Sequence[float] | None, kind: str
) -> Tuple[List[float], float]:
    scores = []
    t0 = time.perf_counter()
    for i, path in enumerate(paths):
        img = load_image(path, SIZE)
        if kind == "none":
            attacked = img
        else:
            attacked = apply_attack(img, "rot_jpeg", float(angles[i]), JPEG_Q, SIZE)
        scores.append(_min_score(key, attacked, layout))
    return scores, time.perf_counter() - t0


def empiric_fpr(scores: Sequence[float], thr: int) -> float:
    s = np.asarray(scores, dtype=np.float64)
    return float(np.mean(np.isfinite(s) & (s <= thr)))


def pick_threshold(
    scores_none: Sequence[float],
    scores_att: Sequence[float],
    tune_pos_scores: Sequence[float],
    candidates: Sequence[int] | None = None,
) -> dict:
    """Largest t with both calib FPRs ≤ 0.5% and tune TPR ≥ 90%."""
    finite = [x for x in list(scores_none) + list(scores_att) if np.isfinite(x)]
    tmax = int(max(finite)) if finite else 0
    if candidates is None:
        # Prefer inspecting 19..16 then scan down; still pick largest feasible.
        candidates = list(range(tmax, -1, -1))
    rows = []
    for t in sorted(set(candidates), reverse=True):
        fn = empiric_fpr(scores_none, t)
        fa = empiric_fpr(scores_att, t)
        tpr = empiric_fpr(tune_pos_scores, t)  # pos scores are mins; accept if <= t
        within = fn <= FPR_CALIB_TARGET + 1e-15 and fa <= FPR_CALIB_TARGET + 1e-15
        tpr_ok = tpr >= TPR_TARGET
        # Leave margin: do not sit exactly on the 0.5% calib cap.
        has_margin = max(fn, fa) < FPR_CALIB_TARGET - 1e-15
        ok = within and tpr_ok and has_margin
        rows.append(
            {
                "t": t,
                "fpr_none": fn,
                "fpr_att": fa,
                "tpr_tune": tpr,
                "within_cap": within and tpr_ok,
                "ok": ok,
            }
        )
    for t in (19, 18, 17, 16):
        if not any(r["t"] == t for r in rows):
            fn = empiric_fpr(scores_none, t)
            fa = empiric_fpr(scores_att, t)
            tpr = empiric_fpr(tune_pos_scores, t)
            within = fn <= FPR_CALIB_TARGET + 1e-15 and fa <= FPR_CALIB_TARGET + 1e-15
            tpr_ok = tpr >= TPR_TARGET
            has_margin = max(fn, fa) < FPR_CALIB_TARGET - 1e-15
            rows.append(
                {
                    "t": t,
                    "fpr_none": fn,
                    "fpr_att": fa,
                    "tpr_tune": tpr,
                    "within_cap": within and tpr_ok,
                    "ok": within and tpr_ok and has_margin,
                }
            )
    rows = sorted(rows, key=lambda r: -r["t"])
    chosen = next((r["t"] for r in rows if r["ok"]), None)
    if chosen is None:
        # Fallback: largest within cap even without strict margin
        chosen = next((r["t"] for r in rows if r.get("within_cap")), None)
    return {"threshold": chosen, "grid": rows, "calib_fpr_target": FPR_CALIB_TARGET}


def fpr_holdout(key, layout, thr, paths, angles, kind: str) -> dict:
    hits = 0
    t0 = time.perf_counter()
    for i, path in enumerate(paths):
        img = load_image(path, SIZE)
        if kind == "none":
            attacked = img
        else:
            attacked = apply_attack(img, "rot_jpeg", float(angles[i]), JPEG_Q, SIZE)
        sc = _min_score(key, attacked, layout)
        hits += int(np.isfinite(sc) and sc <= thr)
    elapsed = time.perf_counter() - t0
    n = len(paths)
    lo, hi = clopper_pearson(hits, n)
    return {
        "k": hits,
        "n": n,
        "fpr": hits / n,
        "cp_lo": lo,
        "cp_hi": hi,
        "cp_upper": clopper_upper(hits, n),
        "pass_upper": clopper_upper(hits, n) <= FPR_TEST,
        "pass_k20": hits <= MAX_FALSE_ACCEPTS_3000,
        "seconds": elapsed,
        "sec_per_image": elapsed / n,
    }


def tpr_random(
    key, layout, thr, marked_list, angles
) -> dict:
    hits = 0
    t0 = time.perf_counter()
    for marked, ang in zip(marked_list, angles):
        attacked = apply_attack(marked, "rot_jpeg", float(ang), JPEG_Q, SIZE)
        sc = _min_score(key, attacked, layout)
        hits += int(np.isfinite(sc) and sc <= thr)
    elapsed = time.perf_counter() - t0
    n = len(marked_list)
    lo, hi = clopper_pearson(hits, n)
    return {
        "k": hits,
        "n": n,
        "tpr": hits / n,
        "cp_lo": lo,
        "cp_hi": hi,
        "pass": hits / n >= TPR_TARGET,
        "seconds": elapsed,
        "sec_per_image": elapsed / n,
    }


def _probes_for_k(probes: Sequence[dict], k: int) -> List[dict]:
    if k == 0:
        return list(probes)
    # Other integer steps: all mids + every 2nd grid + offs
    out = [p for p in probes if p["tag"] in ("mid", "off")]
    grids = [p for p in probes if p["tag"] == "grid"]
    out.extend(grids[::2])
    seen, uniq = set(), []
    for p in out:
        key = round(p["delta"], 10)
        if key in seen:
            continue
        seen.add(key)
        uniq.append(p)
    return sorted(uniq, key=lambda r: r["delta"])


def delta_curve(key, layout, thr, marked_list, probes, ks: Sequence[int]) -> List[dict]:
    rows = []
    for k in ks:
        for probe in _probes_for_k(probes, k):
            delta = float(probe["delta"])
            theta = (k * DELTA + delta) % 360.0
            h, w = expanded_rotate_shape(SIZE, theta)
            odd = bool((h % 2) or (w % 2))
            true_c = content_center_after_rot_crop(SIZE, theta)
            hits = 0
            t0 = time.perf_counter()
            for marked in marked_list:
                attacked = apply_attack(marked, "rot_jpeg", theta, JPEG_Q, SIZE)
                sc = _min_score(key, attacked, layout)
                hits += int(np.isfinite(sc) and sc <= thr)
            elapsed = time.perf_counter() - t0
            n = len(marked_list)
            lo, hi = clopper_pearson(hits, n)
            rows.append(
                {
                    "k": int(k),
                    "delta": delta,
                    "theta": theta,
                    "tag": probe["tag"],
                    "expand_odd": odd,
                    "true_center": list(true_c),
                    "tpr": hits / n,
                    "cp_lo": lo,
                    "cp_hi": hi,
                    "seconds": elapsed,
                    "sec_per_image": elapsed / n,
                }
            )
            print(
                f"  k={k} δ={delta:.4f} ({probe['tag']}) odd={odd} "
                f"TPR={hits/n:.3f} ({elapsed/n*1000:.1f} ms/img)",
                flush=True,
            )
    return rows


def run_key(
    key_id: int,
    key_seed: int,
    calib_paths,
    tune_paths,
    neg_paths,
    pos_paths,
    delta_paths,
    angles_calib,
    angles_tune_att,
    angles_neg,
    angles_pos,
    encode_seeds_tune,
    encode_seeds_pos,
    encode_seeds_delta,
    ks: Sequence[int],
) -> dict:
    print(f"\n######## key {key_id} seed={key_seed} ########", flush=True)
    key = _make_key(np.random.default_rng(key_seed))
    layout = make_layout(SIZE, M, B, GUARD, 0.0)

    print("calib scores: unmarked + rot_jpeg…", flush=True)
    scores_none, t_none = collect_neg_scores(key, layout, calib_paths, None, "none")
    scores_att, t_att = collect_neg_scores(key, layout, calib_paths, angles_calib, "rot_jpeg")

    # Tune positives for threshold selection (not holdout)
    print("tune positive scores…", flush=True)
    tune_pos_scores = []
    psnrs_tune = []
    for path, seed, ang in zip(tune_paths, encode_seeds_tune, angles_tune_att):
        img = load_image(path, SIZE)
        c = bc.encode(key, rng=np.random.default_rng(int(seed)), add_noise=False).reshape(B, M)
        marked = embed_lattice(img, layout, c, STEP)
        psnrs_tune.append(psnr(img, marked))
        attacked = apply_attack(marked, "rot_jpeg", float(ang), JPEG_Q, SIZE)
        tune_pos_scores.append(_min_score(key, attacked, layout))

    pick = pick_threshold(scores_none, scores_att, tune_pos_scores)
    thr = pick["threshold"]
    print(
        f"threshold grid (target calib FPR≤{FPR_CALIB_TARGET}):",
        flush=True,
    )
    for r in pick["grid"]:
        if r["t"] in (19, 18, 17, 16) or r["ok"] or (thr is not None and r["t"] == thr):
            print(
                f"  t={r['t']}: FPR_none={r['fpr_none']:.4f} FPR_att={r['fpr_att']:.4f} "
                f"TPR_tune={r['tpr_tune']:.3f} ok={r['ok']}",
                flush=True,
            )
    row: Dict = {
        "key_id": key_id,
        "key_seed": key_seed,
        "calibration": pick,
        "calib_timing": {
            "sec_none": t_none,
            "sec_att": t_att,
            "sec_per_image_16cand": (t_none + t_att) / (2 * len(calib_paths)),
        },
        "psnr_tune_median": float(np.median(psnrs_tune)),
    }
    if thr is None:
        row["failed"] = "no threshold meets calib FPR≤0.5% and tune TPR≥90%"
        row["passed"] = False
        print("NO THRESHOLD", flush=True)
        return row

    print(f"frozen thr={thr}; holdout…", flush=True)
    fpr_none = fpr_holdout(key, layout, thr, neg_paths, angles_neg, "none")
    fpr_att = fpr_holdout(key, layout, thr, neg_paths, angles_neg, "rot_jpeg")
    print(
        f"FPR none {fpr_none['k']}/{fpr_none['n']} upper={fpr_none['cp_upper']:.4f}; "
        f"att {fpr_att['k']}/{fpr_att['n']} upper={fpr_att['cp_upper']:.4f}",
        flush=True,
    )

    marked_pos, psnrs_pos = [], []
    for path, seed in zip(pos_paths, encode_seeds_pos):
        img = load_image(path, SIZE)
        c = bc.encode(key, rng=np.random.default_rng(int(seed)), add_noise=False).reshape(B, M)
        mk = embed_lattice(img, layout, c, STEP)
        marked_pos.append(mk)
        psnrs_pos.append(psnr(img, mk))
    tpr = tpr_random(key, layout, thr, marked_pos, angles_pos)
    print(
        f"TPR randomθ {tpr['k']}/{tpr['n']}={tpr['tpr']:.3f} "
        f"[{tpr['cp_lo']:.3f},{tpr['cp_hi']:.3f}] "
        f"({tpr['sec_per_image']*1000:.1f} ms/img)",
        flush=True,
    )

    marked_delta = []
    for path, seed in zip(delta_paths, encode_seeds_delta):
        img = load_image(path, SIZE)
        c = bc.encode(key, rng=np.random.default_rng(int(seed)), add_noise=False).reshape(B, M)
        marked_delta.append(embed_lattice(img, layout, c, STEP))
    print("δ / valley curve…", flush=True)
    curve = delta_curve(key, layout, thr, marked_delta, _probes(), ks)
    mids = [r for r in curve if r["tag"] == "mid"]
    grids = [r for r in curve if r["tag"] == "grid"]
    odds = [r for r in curve if r["expand_odd"]]
    evens = [r for r in curve if not r["expand_odd"]]

    row.update(
        {
            "threshold": thr,
            "fpr_none": fpr_none,
            "fpr_rot_jpeg": fpr_att,
            "tpr_random": tpr,
            "psnr_median": float(np.median(psnrs_pos)),
            "psnr_p10": float(np.percentile(psnrs_pos, 10)),
            "psnr_p90": float(np.percentile(psnrs_pos, 90)),
            "curve": curve,
            "curve_summary": {
                "mid_min": float(min(r["tpr"] for r in mids)) if mids else None,
                "grid_min": float(min(r["tpr"] for r in grids)) if grids else None,
                "all_min": float(min(r["tpr"] for r in curve)) if curve else None,
                "odd_mean": float(np.mean([r["tpr"] for r in odds])) if odds else None,
                "even_mean": float(np.mean([r["tpr"] for r in evens])) if evens else None,
                "ms_per_image_mean": float(np.mean([r["sec_per_image"] for r in curve])) * 1000,
            },
        }
    )
    row["passed"] = bool(
        fpr_none["pass_upper"]
        and fpr_att["pass_upper"]
        and tpr["pass"]
        and row["psnr_median"] >= 34.0
        and (row["curve_summary"]["mid_min"] or 0) >= TPR_TARGET
    )
    print(
        f"key={key_id} thr={thr} pass={row['passed']} "
        f"PSNR={row['psnr_median']:.1f} mid_min={row['curve_summary']['mid_min']}",
        flush=True,
    )
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=4)
    ap.add_argument("--n-keys", type=int, default=3)
    ap.add_argument("--ks", type=str, default="0,1,7,31")
    ap.add_argument("--n-delta", type=int, default=150)
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()
    ks = [int(x) for x in args.ks.split(",") if x.strip() != ""]

    master = np.random.default_rng(args.seed)
    calib_paths = split_paths("calib")  # 1000
    tune_paths = split_paths("tune")  # 400
    neg_paths = split_paths("test_neg")  # 3000
    pos_paths = split_paths("test_pos")  # ~600
    delta_paths = split_paths("test_pos")[: args.n_delta]

    angles_calib = master.uniform(0.0, 360.0, size=len(calib_paths))
    angles_tune = master.uniform(0.0, 360.0, size=len(tune_paths))
    angles_neg = master.uniform(0.0, 360.0, size=len(neg_paths))
    angles_pos = master.uniform(0.0, 360.0, size=len(pos_paths))
    encode_tune = master.integers(0, 2**31 - 1, size=len(tune_paths))
    encode_pos = master.integers(0, 2**31 - 1, size=len(pos_paths))
    encode_delta = master.integers(0, 2**31 - 1, size=len(delta_paths))
    key_seeds = [int(master.integers(0, 2**31 - 1)) for _ in range(args.n_keys)]

    results = []
    for kid, ks_seed in enumerate(key_seeds):
        results.append(
            run_key(
                kid,
                ks_seed,
                calib_paths,
                tune_paths,
                neg_paths,
                pos_paths,
                delta_paths,
                angles_calib,
                angles_tune,
                angles_neg,
                angles_pos,
                encode_tune,
                encode_pos,
                encode_delta,
                ks,
            )
        )

    passed = [r for r in results if r.get("passed")]
    if len(passed) == len(results) and results:
        decision = (
            f"All {len(results)} keys pass formal C baseline: "
            f"PSNR~35 dB, both FPR CP-uppers ≤1%, random-θ TPR≥90%, mid valley ≥90%."
        )
    elif passed:
        decision = (
            f"{len(passed)}/{len(results)} keys pass; failing keys need calib retune only."
        )
    else:
        # diagnose
        reasons = []
        for r in results:
            if r.get("threshold") is None:
                reasons.append(f"key{r['key_id']}:no_thr")
                continue
            bits = []
            if not r["fpr_none"]["pass_upper"]:
                bits.append(f"FPR_none_u={r['fpr_none']['cp_upper']:.4f}(k={r['fpr_none']['k']})")
            if not r["fpr_rot_jpeg"]["pass_upper"]:
                bits.append(f"FPR_att_u={r['fpr_rot_jpeg']['cp_upper']:.4f}(k={r['fpr_rot_jpeg']['k']})")
            if not r["tpr_random"]["pass"]:
                bits.append(f"TPR={r['tpr_random']['tpr']:.3f}")
            if (r.get("curve_summary") or {}).get("mid_min", 1) < TPR_TARGET:
                bits.append(f"mid={r['curve_summary']['mid_min']}")
            reasons.append(f"key{r['key_id']} thr={r['threshold']}: " + ",".join(bits))
        decision = "No key fully passes. " + " | ".join(reasons)

    out = {
        "config": {
            "name": "C",
            "m": M,
            "w": W,
            "eta": ETA,
            "step": STEP,
            "size": SIZE,
            "L": L,
            "centers": [list(DEFAULT_CENTER), list(ALT_CENTER)],
            "n_candidates": 16,
            "attack": "rot_jpeg pad+crop",
            "calib_fpr_target": FPR_CALIB_TARGET,
            "test_fpr_upper": FPR_TEST,
            "max_false_accepts_3000": MAX_FALSE_ACCEPTS_3000,
        },
        "per_key": results,
        "n_passed": len(passed),
        "decision": decision,
    }
    if args.out:
        out_path = Path(args.out)
        if not out_path.is_absolute():
            out_path = Path(__file__).resolve().parents[1] / out_path
    else:
        out_path = Path(__file__).resolve().parents[2] / "figures" / "baseline_C.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2))
    print(decision, flush=True)
    print(f"wrote {out_path}", flush=True)


if __name__ == "__main__":
    main()
