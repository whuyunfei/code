"""Experiment 1: integer syndrome histograms and a discrete ROC at m=8.

Uses only the COCO tune split. Uniform bits, unmarked photos, photos with
random payload bits, and the correct versus a wrong key on codeword embeds.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from . import block_circulant as bc
from .coco_photos import load_split
from .fast_radial import make_layout, push_to_margin, sector_pixel_counts
from .integer_threshold import discrete_roc, hist_counts
from .margin_fit import fit_strength
from .residual_search import shared_grids
from .search_scores import scores_over_angles, uniform_min_scores
from .spatial_multiring import psnr


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", type=int, default=256)
    ap.add_argument("--m", type=int, default=8)
    ap.add_argument("--b", type=int, default=4)
    ap.add_argument("--L", type=int, default=4)
    ap.add_argument("--w", type=int, default=1)
    ap.add_argument("--eta", type=float, default=0.03)
    ap.add_argument("--guard", type=float, default=0.15)
    ap.add_argument("--target-psnr", type=float, default=35.0)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", type=str, default="../figures/score_hist.json")
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    images = load_split("tune", args.size)
    m, b, L = args.m, args.b, args.L
    fit_bits = [rng.integers(0, 2, size=(b, m), dtype=np.uint8) for _ in images]
    strength, fit_psnr, note = fit_strength(images, fit_bits, m, b, args.guard, args.target_psnr)
    layout = make_layout(args.size, m, b, args.guard, strength)
    counts = sector_pixel_counts(layout)
    tau = bc.suggest_tau(m, b * args.w, args.eta, 0.05)
    key = bc.keygen(m, b, args.w, tau, args.eta, rng)
    wrong = bc.keygen(m, b, args.w, tau, args.eta, np.random.default_rng(args.seed + 99))
    deltas, _ = shared_grids(m, L)

    classes = {
        "unmarked": [],
        "random_embed": [],
        "correct_key": [],
        "wrong_key": [],
    }
    rejected = {name: 0 for name in classes}
    psnrs = []
    rows = []
    for i, img in enumerate(images):
        unmarked = scores_over_angles(key, img, layout, deltas)
        classes["unmarked"].append(unmarked.best)
        rejected["unmarked"] += unmarked.n_rejected
        for j, sc in enumerate(unmarked.per_angle):
            rows.append({"class": "unmarked", "image": i, "angle_index": j, "score": "" if sc is None else sc, "best": unmarked.best, "n_valid": unmarked.n_valid})

        bits = rng.integers(0, 2, size=(b, m), dtype=np.uint8)
        rand_img = push_to_margin(img, layout, bits)
        rand = scores_over_angles(key, rand_img, layout, deltas)
        classes["random_embed"].append(rand.best)
        rejected["random_embed"] += rand.n_rejected

        code = bc.encode(key, rng=rng).reshape(b, m)
        marked = push_to_margin(img, layout, code)
        psnrs.append(psnr(img, marked))
        good = scores_over_angles(key, marked, layout, deltas)
        bad = scores_over_angles(wrong, marked, layout, deltas)
        classes["correct_key"].append(good.best)
        classes["wrong_key"].append(bad.best)
        rejected["correct_key"] += good.n_rejected
        rejected["wrong_key"] += bad.n_rejected
        for j, sc in enumerate(good.per_angle):
            rows.append({"class": "correct_key", "image": i, "angle_index": j, "score": "" if sc is None else sc, "best": good.best, "n_valid": good.n_valid})
        if (i + 1) % 50 == 0:
            print(f"scored {i+1}/{len(images)}")

    uniform = uniform_min_scores(key, rng, len(images), L)
    classes["uniform"] = uniform
    mass0 = float(np.mean(np.asarray(classes["unmarked"]) == 0))
    roc = []
    for t in range(0, m + 1):
        row = {"t": t, "tpr_correct": float(np.mean(np.asarray(classes["correct_key"]) <= t))}
        for name in ("unmarked", "uniform", "random_embed", "wrong_key"):
            row[f"fpr_{name}"] = float(np.mean(np.asarray(classes[name]) <= t))
        roc.append(row)

    summary = {
        "m": m,
        "b": b,
        "L": L,
        "w": args.w,
        "eta": args.eta,
        "n_tune": len(images),
        "strength": strength,
        "fit_note": note,
        "fit_psnr_median": fit_psnr,
        "embed_psnr_median": float(np.median(psnrs)),
        "embed_psnr_p10": float(np.percentile(psnrs, 10)),
        "pixels_per_sector_median": float(np.median(counts)),
        "empty_sector_fraction": float(np.mean(counts == 0)),
        "mass_at_0_unmarked": mass0,
        "m8_threshold_impossible": bool(mass0 > 1e-2),
        "rejected_candidates": rejected,
        "hist_min": {name: hist_counts(vals, m) for name, vals in classes.items()},
        "roc": roc,
        "exit": (
            "m=8 has no usable threshold: unmarked min-score 0 exceeds 1e-2. Do not tune the threshold; increase the number of checks."
            if mass0 > 1e-2
            else "m=8 unmarked mass at 0 is within 1e-2 on this tune split."
        ),
    }
    # discrete_roc kept as the correct-vs-unmarked view
    summary["roc_unmarked"] = discrete_roc(classes["correct_key"], classes["unmarked"], m)

    out = Path(args.out)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(summary, indent=2))
    csv_path = out.with_name("score_hist_roc.csv")
    with csv_path.open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=list(roc[0].keys()))
        wri.writeheader()
        wri.writerows(roc)
    detail = out.with_name("score_hist_angles.csv")
    with detail.open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wri.writeheader()
        wri.writerows(rows)
    print(f"mass_at_0_unmarked={mass0:.4f} impossible={summary['m8_threshold_impossible']}")
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
