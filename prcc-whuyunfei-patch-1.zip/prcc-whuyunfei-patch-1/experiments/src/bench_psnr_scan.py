"""Round 1: PSNR–TPR–FPR curve on locked detector C by varying lattice step."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from .baseline_c_common import (
    BASELINE_KEY_SEEDS,
    SIZE,
    calibrate_and_eval,
    fit_step_for_psnr,
    make_key,
    make_layout_c,
)
from .coco_photos import load_split, split_paths


TARGETS = [
    {"target_psnr": 35.0, "init_step": 0.197},
    {"target_psnr": 36.0, "init_step": 0.176},
    {"target_psnr": 38.0, "init_step": 0.140},
    {"target_psnr": 40.0, "init_step": 0.111},
]


def _plot(rows, out_png: Path) -> None:
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return
    xs = [r["psnr_median"] for r in rows if r.get("threshold") is not None]
    tpr = [r["tpr_random"]["tpr"] for r in rows if r.get("threshold") is not None]
    mid = [r["curve_summary"]["mid_min"] for r in rows if r.get("threshold") is not None]
    fu = [r["fpr_none"]["cp_upper"] for r in rows if r.get("threshold") is not None]
    fa = [r["fpr_rot_jpeg"]["cp_upper"] for r in rows if r.get("threshold") is not None]
    fig, ax1 = plt.subplots(figsize=(6.2, 4.0))
    ax1.plot(xs, tpr, "o-", label="TPR random θ")
    ax1.plot(xs, mid, "s--", label="TPR mid min")
    ax1.axhline(0.9, color="gray", ls=":", lw=0.8)
    ax1.set_xlabel("median PSNR (dB)")
    ax1.set_ylabel("TPR")
    ax1.set_ylim(0, 1.02)
    ax2 = ax1.twinx()
    ax2.plot(xs, fu, "^-", color="C2", label="FPR none upper")
    ax2.plot(xs, fa, "v-", color="C3", label="FPR att upper")
    ax2.axhline(0.01, color="C3", ls=":", lw=0.8)
    ax2.set_ylabel("FPR 95% upper")
    ax2.set_ylim(0, max(0.05, max(fu + fa + [0.01]) * 1.2))
    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, fontsize=8, loc="best")
    ax1.set_title("Detector C: PSNR scan")
    fig.tight_layout()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_png, dpi=140)
    plt.close(fig)


def eval_step(step, target, key, layout, shared, n_delta) -> dict:
    print(f"\n=== target≈{target} step={step:.5f} ===", flush=True)
    row = calibrate_and_eval(
        key,
        layout,
        step,
        shared["calib"],
        shared["tune"],
        shared["neg"],
        shared["pos"],
        shared["delta"],
        shared["angles_calib"],
        shared["angles_tune"],
        shared["angles_neg"],
        shared["angles_pos"],
        shared["encode_tune"],
        shared["encode_pos"],
        shared["encode_delta"],
        n_delta=n_delta,
    )
    row["target_psnr"] = target
    print(
        f"thr={row.get('threshold')} PSNR={row.get('psnr_median')} "
        f"TPR={row.get('tpr_random', {}).get('tpr')} "
        f"mid={row.get('curve_summary', {}).get('mid_min')} "
        f"FPRu={row.get('fpr_none', {}).get('cp_upper')} "
        f"FPRatt={row.get('fpr_rot_jpeg', {}).get('cp_upper')} "
        f"pass={row.get('passed')}",
        flush=True,
    )
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=10)
    ap.add_argument("--key-seed", type=int, default=BASELINE_KEY_SEEDS[0])
    ap.add_argument("--n-delta", type=int, default=80)
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    tune_imgs = load_split("tune", SIZE, limit=60)
    fits = []
    for t in TARGETS:
        info = fit_step_for_psnr(tune_imgs, t["target_psnr"], t["init_step"], rng)
        fits.append(info)
        print(
            f"fit target={t['target_psnr']} step={info['step']:.5f} "
            f"PSNR={info['psnr_median']:.2f}",
            flush=True,
        )

    calib = split_paths("calib")
    tune = split_paths("tune")
    neg = split_paths("test_neg")
    pos = split_paths("test_pos")
    delta = split_paths("test_pos")[: args.n_delta]
    shared = {
        "calib": calib,
        "tune": tune,
        "neg": neg,
        "pos": pos,
        "delta": delta,
        "angles_calib": rng.uniform(0, 360, len(calib)),
        "angles_tune": rng.uniform(0, 360, len(tune)),
        "angles_neg": rng.uniform(0, 360, len(neg)),
        "angles_pos": rng.uniform(0, 360, len(pos)),
        "encode_tune": rng.integers(0, 2**31 - 1, len(tune)),
        "encode_pos": rng.integers(0, 2**31 - 1, len(pos)),
        "encode_delta": rng.integers(0, 2**31 - 1, len(delta)),
    }
    key = make_key(np.random.default_rng(args.key_seed))
    layout = make_layout_c()

    rows = []
    for info in fits:
        rows.append(eval_step(info["step"], info["target_psnr"], key, layout, shared, args.n_delta))

    # Boundary refine: between highest pass and lowest fail
    ordered = sorted(rows, key=lambda r: r.get("psnr_median") or 0)
    highest_pass = None
    lowest_fail = None
    for r in ordered:
        if r.get("passed"):
            highest_pass = r
        elif highest_pass is not None and lowest_fail is None:
            lowest_fail = r
            break
    # Also: if some high PSNR pass and lower fail (non-monotone), take max passing PSNR
    passing = [r for r in rows if r.get("passed")]
    failing = [r for r in rows if r.get("threshold") is not None and not r.get("passed")]
    if passing:
        highest_pass = max(passing, key=lambda r: r["psnr_median"])
    if failing and highest_pass is not None:
        above = [r for r in failing if r["psnr_median"] > highest_pass["psnr_median"]]
        if above:
            lowest_fail = min(above, key=lambda r: r["psnr_median"])

    refine_rows = []
    if highest_pass is not None and lowest_fail is not None:
        lo_p = highest_pass["psnr_median"]
        hi_p = lowest_fail["psnr_median"]
        extras = []
        mid = 0.5 * (lo_p + hi_p)
        extras.append(round(mid * 2) / 2)  # nearest 0.5
        if hi_p - lo_p >= 1.5:
            extras.append(round(lo_p + 1.0, 1))
        extras = sorted({e for e in extras if lo_p + 0.3 < e < hi_p - 0.2})
        for tgt in extras:
            # interpolate init step from neighbors
            s0, s1 = highest_pass["step"], lowest_fail["step"]
            p0, p1 = lo_p, hi_p
            init = s0 + (s1 - s0) * (tgt - p0) / max(p1 - p0, 1e-6)
            info = fit_step_for_psnr(tune_imgs, tgt, init, rng)
            print(f"refine fit target={tgt} step={info['step']:.5f} PSNR={info['psnr_median']:.2f}", flush=True)
            rr = eval_step(info["step"], tgt, key, layout, shared, args.n_delta)
            refine_rows.append(rr)
            rows.append(rr)

    all_pass = [r for r in rows if r.get("passed")]
    baseline35 = min(
        (r for r in rows if abs((r.get("target_psnr") or 0) - 35) < 0.6),
        key=lambda r: abs(r.get("psnr_median", 99) - 35),
        default=None,
    )
    best = max(all_pass, key=lambda r: r["psnr_median"]) if all_pass else None
    if best is None:
        decision = "No PSNR level passed the three-metric gate under detector C."
    else:
        decision = (
            f"Highest passing median PSNR={best['psnr_median']:.2f} dB "
            f"(target≈{best.get('target_psnr')}, step={best['step']:.5f}, thr={best['threshold']}). "
            f"Keep 35 dB baseline + this candidate."
        )

    out = {
        "fits": fits,
        "rows": [
            {
                k: v
                for k, v in r.items()
                if k != "curve"  # keep summary; drop bulky points in top-level copy? keep in file
            }
            for r in rows
        ],
        "refine": [r.get("target_psnr") for r in refine_rows],
        "baseline_35": None
        if baseline35 is None
        else {
            "step": baseline35["step"],
            "threshold": baseline35.get("threshold"),
            "psnr_median": baseline35.get("psnr_median"),
            "passed": baseline35.get("passed"),
        },
        "best_pass": None
        if best is None
        else {
            "step": best["step"],
            "threshold": best["threshold"],
            "psnr_median": best["psnr_median"],
            "target_psnr": best.get("target_psnr"),
            "tpr_random": best["tpr_random"]["tpr"],
            "mid_min": best["curve_summary"]["mid_min"],
            "fpr_none_upper": best["fpr_none"]["cp_upper"],
            "fpr_att_upper": best["fpr_rot_jpeg"]["cp_upper"],
        },
        "decision": decision,
        "key_seed": args.key_seed,
    }
    # Store full rows including curve
    out["rows"] = rows

    out_path = Path(args.out) if args.out else Path(__file__).resolve().parents[2] / "figures" / "psnr_scan.json"
    if args.out and not out_path.is_absolute():
        out_path = Path(__file__).resolve().parents[1] / args.out
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2))
    _plot(rows, out_path.with_suffix(".png"))
    print(decision, flush=True)
    print(f"wrote {out_path}", flush=True)


if __name__ == "__main__":
    main()
