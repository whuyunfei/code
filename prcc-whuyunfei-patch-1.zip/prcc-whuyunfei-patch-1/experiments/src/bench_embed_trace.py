"""Experiment 5: keyless radial-coefficient distinction and a same-key relation.

Only the configuration adopted by the independent-test screen. The embed is a
push of each radial coefficient onto ±gamma, not a quantization lattice.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.stats import ks_2samp

from . import block_circulant as bc
from .coco_photos import load_split
from .fast_radial import make_layout, push_to_margin, radial_soft
from .security_probes import fit_min_xor_relation, probe_multi_sample, relation_score
from .spatial_multiring import jpeg_compress


def _features(soft: np.ndarray, gamma: float) -> np.ndarray:
    a = np.abs(soft).ravel()
    band = 0.25 * max(gamma, 1e-6)
    pile = float(np.mean(np.abs(a - gamma) <= band))
    return np.array([float(a.mean()), float(a.std()), pile], dtype=np.float64)


def _auc(pos: np.ndarray, neg: np.ndarray) -> float:
    """Mann-Whitney AUC. Scores: higher means more watermark-like."""
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    correct = 0.0
    for p in pos:
        correct += np.sum(p > neg) + 0.5 * np.sum(p == neg)
    return float(correct / (len(pos) * len(neg)))


def _project(train_pos, train_neg, test_pos, test_neg):
    mp = train_pos.mean(axis=0)
    mn = train_neg.mean(axis=0)
    direction = mp - mn
    norm = np.linalg.norm(direction) + 1e-12
    direction = direction / norm
    return test_pos @ direction, test_neg @ direction


def main() -> None:
    fpr_path = Path(__file__).resolve().parents[1] / ".." / "figures" / "integer_fpr.json"
    # parents[1] of this file is experiments/; figures live in the repo root.
    fpr_path = Path(__file__).resolve().parents[2] / "figures" / "integer_fpr.json"
    prev = json.loads(fpr_path.read_text()) if fpr_path.is_file() else {"skipped": True}
    out = Path(__file__).resolve().parents[2] / "figures" / "embed_trace.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    passed = prev.get("passed_screen") or []
    if prev.get("skipped") or not passed:
        payload = {
            "skipped": True,
            "reason": "no adopted (m, w, eta); keyless trace is not reported as a property of a deployed scheme",
        }
        out.write_text(json.dumps(payload, indent=2))
        print(json.dumps(payload))
        return

    # Adopt the passing cell with the highest rotation+JPEG image-level TPR.
    rows = [r for r in prev["rows"] if r.get("passed_screen")]
    adopted_row = max(rows, key=lambda r: r["attacks"]["rot_jpeg"]["tpr"]["rate"])
    spec = next(p for p in passed if p["m"] == adopted_row["m"] and p["w"] == adopted_row["w"] and p["size"] == adopted_row["size"])
    m, w, size = int(spec["m"]), int(spec["w"]), int(spec["size"])
    strength = float(spec["strength"])
    b, eta, guard = 4, 0.03, 0.15
    rng = np.random.default_rng(4)
    layout = make_layout(size, m, b, guard, strength)
    tau = bc.suggest_tau(m, b * w, eta, 0.05)
    key = bc.keygen(m, b, w, tau, eta, rng)

    def pack(images, jpeg: bool):
        pos, neg, coeffs_pos, coeffs_neg = [], [], [], []
        for img in images:
            code = bc.encode(key, rng=rng).reshape(b, m)
            marked = push_to_margin(img, layout, code)
            plain = img
            if jpeg:
                marked = jpeg_compress(marked, 70)
                plain = jpeg_compress(img, 70)
            sp = radial_soft(marked, layout, 0.0)
            sn = radial_soft(plain, layout, 0.0)
            pos.append(_features(sp, strength))
            neg.append(_features(sn, strength))
            coeffs_pos.append(sp.ravel())
            coeffs_neg.append(sn.ravel())
        return np.stack(pos), np.stack(neg), np.concatenate(coeffs_pos), np.concatenate(coeffs_neg)

    train_imgs = load_split("calib", size, limit=80)
    test_imgs = load_split("test_pos", size, limit=80)
    tr_p, tr_n, _, _ = pack(train_imgs, jpeg=False)
    te_p, te_n, pool_p, pool_n = pack(test_imgs, jpeg=False)
    proj_p, proj_n = _project(tr_p, tr_n, te_p, te_n)
    auc_clean = _auc(proj_p, proj_n)
    ks_clean = ks_2samp(pool_p, pool_n)
    tr_pj, tr_nj, _, _ = pack(train_imgs, jpeg=True)
    te_pj, te_nj, pool_pj, pool_nj = pack(test_imgs, jpeg=True)
    auc_jpeg = _auc(*_project(tr_pj, tr_nj, te_pj, te_nj))
    ks_jpeg = ks_2samp(pool_pj, pool_nj)

    algebraic = probe_multi_sample(key, rng, n_train=20, n_test=20)
    extracted = []
    for img in train_imgs:
        code = bc.encode(key, rng=rng).reshape(b, m)
        marked = push_to_margin(img, layout, code)
        y = (radial_soft(marked, layout, 0.0) >= 0).astype(np.uint8).reshape(-1)
        extracted.append(y)
    rel = fit_min_xor_relation(extracted[:40], m)
    # train_imgs is 80; split 40/40 but fit used first 40 of a list of 80.
    same = relation_score(extracted[40:], m, rel)
    fresh_key = bc.keygen(m, b, w, tau, eta, rng)
    fresh = []
    for img in test_imgs[:20]:
        code = bc.encode(fresh_key, rng=rng).reshape(b, m)
        marked = push_to_margin(img, layout, code)
        fresh.append((radial_soft(marked, layout, 0.0) >= 0).astype(np.uint8).reshape(-1))
    uni = [rng.integers(0, 2, size=b * m, dtype=np.uint8) for _ in range(20)]
    image_relation = {
        "score_same_key": same,
        "score_fresh_key": relation_score(fresh, m, rel),
        "score_uniform": relation_score(uni, m, rel),
    }
    image_relation["gap_vs_uniform"] = image_relation["score_uniform"] - image_relation["score_same_key"]
    distinguished = bool(auc_clean >= 0.70 or auc_jpeg >= 0.70)
    payload = {
        "skipped": False,
        "description": "Each radial coefficient is pushed to ±gamma. This is not lattice QIM.",
        "adopted": {"m": m, "w": w, "eta": eta, "size": size, "strength": strength},
        "auc_clean": auc_clean,
        "auc_jpeg70": auc_jpeg,
        "ks_clean_D": float(ks_clean.statistic),
        "ks_clean_p": float(ks_clean.pvalue),
        "ks_jpeg_D": float(ks_jpeg.statistic),
        "keyless_distinguished": distinguished,
        "algebraic_multi_sample": algebraic,
        "extracted_multi_sample": image_relation,
        "stealth": (
            "Keyless image-level features separate watermarked from unmarked images. "
            "Even if detection meets the false-positive target, this is a robust watermark whose undetectability is not established."
            if distinguished
            else "The image-level linear score did not clearly separate watermarked from unmarked images on this split."
        ),
    }
    out.write_text(json.dumps(payload, indent=2))
    print(json.dumps({k: payload[k] for k in ("auc_clean", "auc_jpeg70", "keyless_distinguished", "stealth")}, indent=2))


if __name__ == "__main__":
    main()
