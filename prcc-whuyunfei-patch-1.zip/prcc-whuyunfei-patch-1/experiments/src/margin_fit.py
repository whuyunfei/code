"""Choose the push-to-margin gamma so the median embed PSNR is near a target."""

from __future__ import annotations

from typing import Sequence

import numpy as np

from .fast_radial import make_layout, push_to_margin
from .spatial_multiring import psnr


def median_psnr(images: Sequence[np.ndarray], bits: Sequence[np.ndarray], m: int, b: int, guard: float, strength: float) -> float:
    size = int(images[0].shape[0])
    layout = make_layout(size, m, b, guard, strength)
    vals = [psnr(im, push_to_margin(im, layout, bt)) for im, bt in zip(images, bits)]
    return float(np.median(vals))


def fit_strength(
    images: Sequence[np.ndarray],
    bits: Sequence[np.ndarray],
    m: int,
    b: int,
    guard: float,
    target: float = 35.0,
) -> tuple[float, float, str]:
    """Return (strength, median_psnr, note).

    The sign-flip floor is a separate measurement. This search only moves gamma
    so the median PSNR lands on the budget. It does not relax the budget.
    """
    p_hi = median_psnr(images, bits, m, b, guard, 1e-4)
    if p_hi < target - 0.5:
        return 1e-4, p_hi, "floor_already_below_budget"
    p_lo = median_psnr(images, bits, m, b, guard, 0.8)
    if p_lo > target + 0.5:
        return 0.8, p_lo, "cannot_spend_budget"
    lo, hi = 1e-4, 0.8
    for _ in range(14):
        mid = 0.5 * (lo + hi)
        if median_psnr(images, bits, m, b, guard, mid) > target:
            lo = mid
        else:
            hi = mid
    strength = 0.5 * (lo + hi)
    got = median_psnr(images, bits, m, b, guard, strength)
    return strength, got, "ok"
