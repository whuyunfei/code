"""Zero-bit sparse-syndrome PRC + ring-OR detection under T_k.

This is a definition-aligned baseline, not a reproduction of Christ–Gunn
belief-propagation decoding. Encoder: systematic sample from ker H_PRC
(plus optional Bern(eta)); detector OR over simultaneous ring shifts.
"""

from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter
from typing import List, Tuple

import numpy as np

from .block_circulant import gf2_rank, simultaneous_shift


def _gf2_nullspace_basis(H: np.ndarray) -> np.ndarray:
    """Return columns spanning ker(H) over GF(2)."""
    r, n = H.shape
    M = H.astype(np.uint8).copy()
    # Row-reduce; track column permutation via pivot positions.
    pivots: List[int] = []
    row = 0
    for col in range(n):
        pivot = None
        for i in range(row, r):
            if M[i, col]:
                pivot = i
                break
        if pivot is None:
            continue
        if pivot != row:
            M[[row, pivot]] = M[[pivot, row]]
        for i in range(r):
            if i != row and M[i, col]:
                M[i] ^= M[row]
        pivots.append(col)
        row += 1
        if row == r:
            break
    pivot_set = set(pivots)
    free = [j for j in range(n) if j not in pivot_set]
    basis = []
    # Express pivot vars in terms of free vars from reduced form.
    # Rebuild map: for each pivot column, the row gives coefficients.
    for f in free:
        v = np.zeros(n, dtype=np.uint8)
        v[f] = 1
        for prow, pcol in enumerate(pivots):
            # M[prow, :] has 1 at pcol and possibly free columns
            if M[prow, f]:
                v[pcol] = 1
        basis.append(v)
    if not basis:
        return np.zeros((n, 0), dtype=np.uint8)
    return np.stack(basis, axis=1)


@dataclass
class SparsePRCKey:
    H: np.ndarray  # r x n
    tau: int
    eta: float
    m: int  # angular length for T_k
    b: int
    null_basis: np.ndarray  # n x k


def keygen(
    m: int,
    b: int,
    r: int,
    w: int,
    tau: int,
    eta: float = 0.05,
    rng: np.random.Generator | None = None,
) -> SparsePRCKey:
    """Sample a secret sparse r x (b*m) parity-check matrix of row weight w."""
    rng = rng or np.random.default_rng()
    n = b * m
    if not (1 <= w <= n):
        raise ValueError("invalid w")
    if r >= n:
        raise ValueError("need r < n for nontrivial kernel")
    H = np.zeros((r, n), dtype=np.uint8)
    for i in range(r):
        H[i, rng.choice(n, size=w, replace=False)] = 1
    # Ensure full row rank by resampling rows if needed (lightweight).
    tries = 0
    while gf2_rank(H) < r and tries < 50:
        for i in range(r):
            H[i] = 0
            H[i, rng.choice(n, size=w, replace=False)] = 1
        tries += 1
    if gf2_rank(H) < r:
        raise RuntimeError("failed to sample full-row-rank sparse H")
    basis = _gf2_nullspace_basis(H)
    return SparsePRCKey(H=H, tau=tau, eta=eta, m=m, b=b, null_basis=basis)


def syndrome(key: SparsePRCKey, y: np.ndarray) -> np.ndarray:
    return (key.H @ y.astype(np.uint8)) % 2


def detect_aligned(key: SparsePRCKey, y: np.ndarray) -> bool:
    return int(syndrome(key, y).sum()) <= key.tau


def detect_ring_or(key: SparsePRCKey, y: np.ndarray) -> bool:
    for k in range(key.m):
        if detect_aligned(key, simultaneous_shift(y, key.m, k)):
            return True
    return False


def encode(key: SparsePRCKey, rng: np.random.Generator | None = None) -> np.ndarray:
    rng = rng or np.random.default_rng()
    k = key.null_basis.shape[1]
    if k == 0:
        c = np.zeros(key.H.shape[1], dtype=np.uint8)
    else:
        u = rng.integers(0, 2, size=k, dtype=np.uint8)
        c = (key.null_basis @ u) % 2
    if key.eta > 0:
        noise = rng.random(len(c)) < key.eta
        c = np.bitwise_xor(c, noise.astype(np.uint8))
    return c


def timed_detect_ring_or(key: SparsePRCKey, y: np.ndarray) -> Tuple[bool, float]:
    t0 = perf_counter()
    ok = detect_ring_or(key, y)
    return ok, perf_counter() - t0


def uniform_fpr_bound(base_eps: float, m: int) -> float:
    return min(1.0, m * base_eps)
