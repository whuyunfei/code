"""Carriers that keep integer-rotation correspondence without forcing a sign flip.

- margin: push coefficient to ±gamma (failed baseline).
- lattice: two interleaved quantization cosets; bit chooses the coset, coeff moves
  to the nearest reconstruction point. Does not require changing absolute sign.
- smooth: overlapping soft radial bands; same lattice rule on the soft coefficient.
"""

from __future__ import annotations

from functools import lru_cache

import numpy as np

from .fast_radial import _apply_deltas, _gray01, _sector_index, make_layout, radial_soft
from .spatial_multiring import MultiRingLayout, _polar_grids


@lru_cache(maxsize=8)
def _cached_polar(size: int):
    rad, ang, _y, _x = _polar_grids(size)
    return rad, ang


def lattice_step(m: int) -> float:
    """Default lattice spacing in unit-gray radial difference units."""
    # Slightly larger for finer sectors: host coeff variance grows as sectors shrink.
    return 0.04 if m <= 16 else 0.05


def nearest_lattice(coeff: np.ndarray, bits: np.ndarray, step: float) -> np.ndarray:
    """Two cosets: even multiples of step/2 for bit 0, odd for bit 1.

    Reconstruction points: ..., -1.5 s, -0.5 s, 0.5 s, 1.5 s, ... for bit 1
    and ..., -2 s, -s, 0, s, 2 s, ... for bit 0, with s = step.
    Equivalently: targets = (2k + bit) * (step/2) for integer k.
    """
    c = np.asarray(coeff, dtype=np.float64)
    b = np.asarray(bits, dtype=np.float64)
    half = 0.5 * step
    # Map to the coset: subtract bit*half, quantize to step, add bit*half.
    shifted = c - b * half
    k = np.round(shifted / step)
    return k * step + b * half


def embed_margin(image: np.ndarray, layout: MultiRingLayout, bits: np.ndarray) -> np.ndarray:
    from .fast_radial import push_to_margin

    return push_to_margin(image, layout, bits)


def embed_lattice(image: np.ndarray, layout: MultiRingLayout, bits: np.ndarray, step: float | None = None) -> np.ndarray:
    step = lattice_step(layout.m) if step is None else step
    g, scale, img = _gray01(image)
    coeff = radial_soft(image, layout, 0.0)
    bits = np.asarray(bits, dtype=np.uint8).reshape(layout.b, layout.m)
    target = nearest_lattice(coeff, bits, step)
    delta = target - coeff
    out = np.clip(_apply_deltas(g, layout, delta), 0.0, 1.0)
    if image.ndim == 3:
        res = np.clip(img / scale + (out - g)[:, :, None], 0.0, 1.0)
        return res * scale
    return out * scale


def extract_lattice(
    image: np.ndarray,
    layout: MultiRingLayout,
    angle_offset_deg: float = 0.0,
    step: float | None = None,
    center: tuple[float, float] | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Return (hard bits, signed distance to the decision boundary)."""
    step = lattice_step(layout.m) if step is None else step
    coeff = radial_soft(image, layout, angle_offset_deg, center=center)
    # Decision: which coset is closer.
    # Distance to even coset vs odd coset.
    half = 0.5 * step
    # Fold into [0, step)
    r = np.mod(coeff, step)
    # Even coset representatives at 0; odd at half. Midpoints at step/4 and 3step/4.
    dist_even = np.minimum(r, step - r)
    dist_odd = np.abs(r - half)
    bits = (dist_odd < dist_even).astype(np.uint8)
    # Margin: positive if closer to chosen/correct coset — use odd-vs-even signed
    soft = dist_even - dist_odd  # >0 prefers bit 1
    return bits, soft


def smooth_radial_soft(image: np.ndarray, layout: MultiRingLayout, angle_offset_deg: float = 0.0) -> np.ndarray:
    """Overlapping raised-cosine radial bands inside each annulus."""
    g, _scale, _img = _gray01(image)
    rad, ang = _cached_polar(layout.size)
    sector, usable = _sector_index(ang, layout.m, angle_offset_deg, layout.guard_frac)
    soft = np.zeros((layout.b, layout.m), dtype=np.float64)
    flat = g.ravel()
    sec = sector.ravel()
    for j, (r0, r1) in enumerate(layout.annuli):
        mid = 0.5 * (r0 + r1)
        width = max(r1 - r0, 1e-6)
        # Overlap: full annulus with soft weights tipping outer vs inner.
        ring = (usable & (rad >= r0 - 0.15 * width) & (rad <= r1 + 0.15 * width)).ravel()
        if not np.any(ring):
            continue
        # Raised-cosine tip from -1 (inner) to +1 (outer)
        t = (rad.ravel()[ring] - mid) / (0.5 * width)
        w = np.clip(t, -1.5, 1.5)
        w = np.sin(0.5 * np.pi * np.clip(w / 1.5, -1, 1))
        sj = sec[ring]
        # Weighted mean of w * gray per sector, normalized by mean |w|
        num = np.bincount(sj, weights=flat[ring] * w, minlength=layout.m)
        den = np.bincount(sj, weights=np.abs(w), minlength=layout.m).astype(np.float64)
        with np.errstate(divide="ignore", invalid="ignore"):
            soft[j] = np.divide(num, den + 1e-12, out=np.zeros(layout.m), where=den > 1e-12)
    return soft


def embed_smooth_lattice(image: np.ndarray, layout: MultiRingLayout, bits: np.ndarray, step: float | None = None) -> np.ndarray:
    """Lattice rule on the smooth coefficient; pixel push still uses hard radial bands."""
    step = lattice_step(layout.m) if step is None else step
    g, scale, img = _gray01(image)
    # Use hard bands to apply deltas (same geometry as integer rotation), but choose
    # targets from the smooth coefficient so JPEG/cropping softens the decision.
    hard = radial_soft(image, layout, 0.0)
    smooth = smooth_radial_soft(image, layout, 0.0)
    bits = np.asarray(bits, dtype=np.uint8).reshape(layout.b, layout.m)
    target = nearest_lattice(smooth, bits, step)
    # Move the hard coefficient by the same delta the soft coeff needs.
    delta = target - hard
    out = np.clip(_apply_deltas(g, layout, delta), 0.0, 1.0)
    if image.ndim == 3:
        res = np.clip(img / scale + (out - g)[:, :, None], 0.0, 1.0)
        return res * scale
    return out * scale


def extract_smooth_lattice(image: np.ndarray, layout: MultiRingLayout, angle_offset_deg: float = 0.0, step: float | None = None):
    step = lattice_step(layout.m) if step is None else step
    coeff = smooth_radial_soft(image, layout, angle_offset_deg)
    half = 0.5 * step
    r = np.mod(coeff, step)
    dist_even = np.minimum(r, step - r)
    dist_odd = np.abs(r - half)
    bits = (dist_odd < dist_even).astype(np.uint8)
    soft = dist_even - dist_odd
    return bits, soft
