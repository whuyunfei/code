"""Experiment 4: blind residual search at angles the grid may miss.

Only configs that passed the independent-test screen. PRCC and extract-once PRC
each get their own threshold from the calibration split, under the same FPR budget.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from time import perf_counter

import numpy as np

from . import block_circulant as bc
from .block_circulant import simultaneous_shift
from .coco_photos import load_image, split_paths
from .fast_radial import make_layout, push_to_margin, radial_soft
from .integer_threshold import clopper_pearson, largest_integer_threshold, most_permissive_upper
from .prc_watermark_adapter import KeyGen, PRCWatermarkKey, available as prc_available, encode_bits, score_from_bits
from .residual_search import hard_score, shared_grids
from .search_scores import scores_over_angles
from .spatial_multiring import apply_attack


def _rotation_sign(layout, rng) -> int:
    bits = rng.integers(0, 2, size=(layout.b, layout.m), dtype=np.uint8)
    img = np.full((layout.size, layout.size, 3), 140.0)
    marked = push_to_margin(img, layout, bits)
    attacked = apply_attack(marked, "rot", 22.5, size=layout.size)
    best_s, best_b = 1, 1.0
    for sign in (1, -1):
        soft = radial_soft(attacked, layout, sign * 22.5)
        ber = float(np.mean((soft >= 0).astype(np.uint8) != bits))
        if ber < best_b:
            best_s, best_b = sign, ber
    if best_b > 0.2:
        raise SystemExit(f"rotation alignment BER {best_b:.2f}")
    return best_s


def _angles(m: int, L: int, rng: np.random.Generator) -> dict:
    delta = 360.0 / m
    step = delta / L
    return {
        "random": float(rng.uniform(0.0, 360.0)),
        "near_integer": 2.0,
        "near_half": delta / 2.0 + 2.0,
        "mid_grid": step / 2.0,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fpr-json", type=str, default="../figures/integer_fpr.json")
    ap.add_argument("--n-pos", type=int, default=200)
    ap.add_argument("--n-neg", type=int, default=400)
    ap.add_argument("--encodings", type=int, default=2)
    ap.add_argument("--seed", type=int, default=3)
    ap.add_argument("--out", type=str, default="../figures/blind_angles.json")
    args = ap.parse_args()
    src = Path(args.fpr_json)
    if not src.is_absolute():
        src = Path(__file__).resolve().parents[1] / args.fpr_json
    prev = json.loads(src.read_text())
    out = Path(args.out)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    passed = prev.get("passed_screen") or []
    if prev.get("skipped") or not passed:
        payload = {"skipped": True, "reason": "no configuration met the independent FPR and TPR screen"}
        out.write_text(json.dumps(payload, indent=2))
        print(json.dumps(payload))
        return
    if not prc_available():
        raise SystemExit("galois required")

    rng = np.random.default_rng(args.seed)
    rows = []
    attacks = ("none", "rot", "jpeg", "rot_jpeg")
    for spec in passed:
        m, w, size = int(spec["m"]), int(spec["w"]), int(spec["size"])
        b, eta, guard = 4, 0.03, 0.15
        strength = float(spec["strength"])
        layout = make_layout(size, m, b, guard, strength)
        tau = bc.suggest_tau(m, b * w, eta, 0.05)
        key = bc.keygen(m, b, w, tau, eta, rng)
        wrong = bc.keygen(m, b, w, tau, eta, np.random.default_rng(args.seed + 17))
        n = m * b
        enc, dec = KeyGen(n, message_length=max(4, n // 8), false_positive_rate=1e-2, t=3, noise_rate=0.05, g=8, r=max(8, n // 3))
        prc_key = PRCWatermarkKey(enc, dec, n, 1e-2)
        sign = _rotation_sign(layout, rng)
        shift_sign = 1
        pos_paths = split_paths("test_pos")[: args.n_pos]
        neg_paths = split_paths("test_neg")[: args.n_neg]
        calib_paths = split_paths("calib")
        cell = {"m": m, "w": w, "size": size, "strength": strength, "rotation_sign": sign, "by_L": []}
        for L in (2, 4, 8):
            deltas, _ = shared_grids(m, L)
            calib = [_best_block(key, load_image(p, size), layout, deltas) for p in calib_paths]
            thr = largest_integer_threshold(calib, 1e-2)
            prc_calib = []
            for p in calib_paths:
                sc, _e, _c = _prc_reuse(prc_key, load_image(p, size), layout, deltas, shift_sign)
                prc_calib.append(sc)
            thr_prc = most_permissive_upper(prc_calib, 1e-2)
            entry = {"L": L, "threshold": thr, "thr_prc": thr_prc, "angles": {}}
            if thr is None:
                entry["failed"] = "no integer threshold at this L"
                cell["by_L"].append(entry)
                print(f"m={m} L={L} no threshold")
                continue
            for name in ("random", "near_integer", "near_half", "mid_grid"):
                per_attack = {}
                for kind in attacks:
                    # Known-angle BER and blind / wrong-key / unmarked under one threshold.
                    blind_hit = []
                    known_ber = []
                    wrong_hit = []
                    for path in pos_paths:
                        flags = []
                        bers = []
                        wrong_flags = []
                        base = load_image(path, size)
                        for _rep in range(args.encodings):
                            ang = _angles(m, L, rng)[name]
                            code = bc.encode(key, rng=rng).reshape(b, m)
                            marked = push_to_margin(base, layout, code)
                            attacked = apply_attack(marked, kind, ang, 70, size)
                            true_off = 0.0 if kind in ("none", "jpeg") else sign * ang
                            soft = radial_soft(attacked, layout, true_off)
                            bers.append(float(np.mean((soft >= 0).astype(np.uint8) != code)))
                            flags.append(_best_block(key, attacked, layout, deltas) <= thr)
                            wrong_flags.append(_best_block(wrong, attacked, layout, deltas) <= thr)
                        blind_hit.append(float(np.mean(flags)) >= 0.5)
                        known_ber.append(float(np.mean(bers)))
                        wrong_hit.append(float(np.mean(wrong_flags)) >= 0.5)
                    neg_flags = []
                    for path in neg_paths:
                        ang = _angles(m, L, rng)["random"] if name == "random" else _angles(m, L, rng)[name]
                        img = apply_attack(load_image(path, size), kind, ang, 70, size)
                        neg_flags.append(_best_block(key, img, layout, deltas) <= thr)
                    k = int(np.sum(neg_flags))
                    lo, hi = clopper_pearson(k, len(neg_flags))
                    kb = int(np.sum(blind_hit))
                    per_attack[kind] = {
                        "known_ber_mean": float(np.mean(known_ber)),
                        "blind_tpr": kb / len(blind_hit),
                        "blind_cp": clopper_pearson(kb, len(blind_hit)),
                        "wrong_key_rate": float(np.mean(wrong_hit)),
                        "fpr": k / len(neg_flags),
                        "fpr_cp": [lo, hi],
                    }
                entry["angles"][name] = per_attack
                gap = per_attack["rot_jpeg"]["known_ber_mean"]
                tpr = per_attack["rot_jpeg"]["blind_tpr"]
                if gap <= 0.1 and tpr < 0.5:
                    diagnosis = "sync_or_search"
                elif gap > 0.1 and tpr < 0.5:
                    diagnosis = "channel_or_capacity"
                else:
                    diagnosis = "blind_tracks_channel"
                entry["angles"][name]["rot_jpeg_diagnosis"] = diagnosis
                print(f"m={m} L={L} {name} rot_jpeg BER={gap:.3f} blindTPR={tpr:.2f} {diagnosis}")
            # PRC comparison at this L, mid-grid and random, rot+jpeg and clean.
            if thr_prc is not None:
                prc_rows = {}
                for kind in ("none", "rot_jpeg"):
                    hits = []
                    times_ext = []
                    times_code = []
                    block_ext = []
                    block_code = []
                    for path in pos_paths:
                        ang = 180.0 / m if kind == "rot_jpeg" else 0.0
                        bits = encode_bits(prc_key).reshape(b, m)
                        marked = push_to_margin(load_image(path, size), layout, bits)
                        attacked = apply_attack(marked, kind, ang, 70, size)
                        sc, ext_ms, code_ms = _prc_reuse(prc_key, attacked, layout, deltas, shift_sign)
                        hits.append(sc >= thr_prc)
                        times_ext.append(ext_ms)
                        times_code.append(code_ms)
                        te, tc = _block_times(key, attacked, layout, deltas)
                        block_ext.append(te)
                        block_code.append(tc)
                    prc_rows[kind] = {
                        "tpr_prc": float(np.mean(hits)),
                        "prc_extract_ms": float(np.median(times_ext)),
                        "prc_code_ms": float(np.median(times_code)),
                        "prcc_extract_ms": float(np.median(block_ext)),
                        "prcc_code_ms": float(np.median(block_code)),
                        "code_evals_prcc": L,
                        "code_evals_prc": m * L,
                    }
                entry["prc"] = prc_rows
            cell["by_L"].append(entry)
        rows.append(cell)
    payload = {"skipped": False, "n_pos": args.n_pos, "n_neg": args.n_neg, "rows": rows}
    out.write_text(json.dumps(payload, indent=2))
    print(f"wrote {out}")


def _best_block(key, image, layout, deltas) -> float:
    return scores_over_angles(key, image, layout, deltas).best


def _prc_reuse(prc_key, image, layout, deltas, sign: int):
    t_ext = 0.0
    t_code = 0.0
    best = -1e18
    for d in deltas:
        t0 = perf_counter()
        bits = (radial_soft(image, layout, float(d)) >= 0).astype(np.uint8).reshape(-1)
        t_ext += perf_counter() - t0
        for k in range(layout.m):
            y = simultaneous_shift(bits, layout.m, sign * k)
            t1 = perf_counter()
            sc = score_from_bits(prc_key, y)
            t_code += perf_counter() - t1
            if sc > best:
                best = sc
    return best, 1e3 * t_ext, 1e3 * t_code


def _block_times(key, image, layout, deltas):
    te = tc = 0.0
    for d in deltas:
        t0 = perf_counter()
        y = (radial_soft(image, layout, float(d)) >= 0).astype(np.uint8).reshape(-1)
        te += perf_counter() - t0
        t1 = perf_counter()
        hard_score(key, y)
        tc += perf_counter() - t1
    return 1e3 * te, 1e3 * tc


if __name__ == "__main__":
    main()
