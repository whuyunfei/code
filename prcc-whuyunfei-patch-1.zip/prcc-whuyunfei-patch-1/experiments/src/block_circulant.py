"""Block-circulant PRCC under simultaneous ring shifts T_k.

H = [A_1 | ... | A_b] with m x m circulant blocks. Then H T_k = R_k H.
Encode into the coset H c = 1 (all-ones), then Bern(eta) noise.
Detect: wt(H y + 1) <= tau.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence, Tuple

import numpy as np


def cyclic_shift(x: np.ndarray, k: int) -> np.ndarray:
    k = int(k) % len(x)
    if k == 0:
        return x.copy()
    return np.concatenate([x[-k:], x[:-k]])


def full_circulant(h: np.ndarray) -> np.ndarray:
    m = len(h)
    return np.stack([cyclic_shift(h, i) for i in range(m)], axis=0)


def simultaneous_shift(c: np.ndarray, m: int, k: int) -> np.ndarray:
    """Apply T_k = diag(R_k, ..., R_k) to a length-(b*m) codeword."""
    n = len(c)
    if n % m != 0:
        raise ValueError("length must be multiple of m")
    b = n // m
    blocks = [cyclic_shift(c[j * m : (j + 1) * m], k) for j in range(b)]
    return np.concatenate(blocks)


def poly_from_bits(h: np.ndarray) -> np.ndarray:
    """Return GF(2) polynomial coefficients low-degree first (length m)."""
    return h.astype(np.uint8).copy()


def gf2_poly_mod(a: np.ndarray, mod: np.ndarray) -> np.ndarray:
    """Reduce polynomial a mod mod over GF(2). Both low-degree first."""
    a = np.trim_zeros(a.astype(np.uint8), "b")
    mod = np.trim_zeros(mod.astype(np.uint8), "b")
    if len(mod) == 0:
        raise ValueError("zero modulus")
    deg_m = len(mod) - 1
    a = list(a)
    while len(a) - 1 >= deg_m:
        if a[-1] == 0:
            a.pop()
            continue
        shift = len(a) - 1 - deg_m
        for i, bit in enumerate(mod):
            if bit:
                idx = i + shift
                if idx >= len(a):
                    a.extend([0] * (idx + 1 - len(a)))
                a[idx] ^= 1
        while a and a[-1] == 0:
            a.pop()
    return np.array(a, dtype=np.uint8)


def gf2_poly_gcd(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    a = np.trim_zeros(a.astype(np.uint8), "b")
    b = np.trim_zeros(b.astype(np.uint8), "b")
    while len(b) > 0:
        _, r = gf2_poly_divmod(a, b)
        a, b = b, r
    return a if len(a) else np.array([0], dtype=np.uint8)


def gf2_poly_divmod(a: np.ndarray, b: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    a = list(np.trim_zeros(a.astype(np.uint8), "b"))
    b = list(np.trim_zeros(b.astype(np.uint8), "b"))
    if not b:
        raise ZeroDivisionError("poly division by zero")
    deg_b = len(b) - 1
    q = [0] * max(1, len(a) - deg_b)
    while len(a) - 1 >= deg_b and a:
        if a[-1] == 0:
            a.pop()
            continue
        shift = len(a) - 1 - deg_b
        if shift >= len(q):
            q.extend([0] * (shift + 1 - len(q)))
        q[shift] ^= 1
        for i, bit in enumerate(b):
            if bit:
                a[i + shift] ^= 1
        while a and a[-1] == 0:
            a.pop()
    return np.array(q, dtype=np.uint8), np.array(a, dtype=np.uint8)


def x_m_minus_1(m: int) -> np.ndarray:
    """X^m - 1 = X^m + 1 over GF(2)."""
    p = np.zeros(m + 1, dtype=np.uint8)
    p[0] = 1
    p[m] = 1
    return p


def circulant_invertible(h: np.ndarray) -> bool:
    """h generates an invertible circulant iff gcd(h(X), X^m-1) = 1."""
    m = len(h)
    g = gf2_poly_gcd(poly_from_bits(h), x_m_minus_1(m))
    g = np.trim_zeros(g, "b")
    return len(g) == 1 and int(g[0]) == 1


def gf2_circulant_solve(A: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Solve A x = b over GF(2) for square A via Gaussian elimination."""
    m = A.shape[0]
    M = np.concatenate([A.astype(np.uint8), b.astype(np.uint8).reshape(m, 1)], axis=1)
    row = 0
    pivots = [-1] * m
    for col in range(m):
        pivot = None
        for r in range(row, m):
            if M[r, col]:
                pivot = r
                break
        if pivot is None:
            continue
        if pivot != row:
            M[[row, pivot]] = M[[pivot, row]]
        for r in range(m):
            if r != row and M[r, col]:
                M[r] ^= M[row]
        pivots[col] = row
        row += 1
        if row == m:
            break
    if row < m:
        raise np.linalg.LinAlgError("singular matrix over GF(2)")
    x = np.zeros(m, dtype=np.uint8)
    for col in range(m):
        r = pivots[col]
        if r >= 0:
            x[col] = M[r, m]
    return x


def gf2_rank(A: np.ndarray) -> int:
    M = A.astype(np.uint8).copy()
    rows, cols = M.shape
    r = 0
    for c in range(cols):
        pivot = None
        for i in range(r, rows):
            if M[i, c]:
                pivot = i
                break
        if pivot is None:
            continue
        if pivot != r:
            M[[r, pivot]] = M[[pivot, r]]
        for i in range(rows):
            if i != r and M[i, c]:
                M[i] ^= M[r]
        r += 1
        if r == rows:
            break
    return r


def gf2_solve_affine(H: np.ndarray, target: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """Uniform sample from {x : H x = target} over GF(2), or raise if empty."""
    H = H.astype(np.uint8)
    target = np.asarray(target, dtype=np.uint8).reshape(-1)
    rows, cols = H.shape
    M = np.concatenate([H.copy(), target.reshape(rows, 1)], axis=1)
    r = 0
    pivots = [-1] * cols
    for c in range(cols):
        pivot = None
        for i in range(r, rows):
            if M[i, c]:
                pivot = i
                break
        if pivot is None:
            continue
        if pivot != r:
            M[[r, pivot]] = M[[pivot, r]]
        for i in range(rows):
            if i != r and M[i, c]:
                M[i] ^= M[r]
        pivots[c] = r
        r += 1
        if r == rows:
            break
    for i in range(r, rows):
        if M[i, cols]:
            raise np.linalg.LinAlgError("target not in column space")
    free = [c for c in range(cols) if pivots[c] < 0]
    x = np.zeros(cols, dtype=np.uint8)
    for c in free:
        x[c] = int(rng.integers(0, 2))
    for c in range(cols - 1, -1, -1):
        pr = pivots[c]
        if pr < 0:
            continue
        s = int(M[pr, cols])
        for j in range(c + 1, cols):
            if M[pr, j]:
                s ^= int(x[j])
        x[c] = s
    return x


def q_bsc(p: float, w: int) -> float:
    """P[parity of w BSC_p bits is 1]."""
    return 0.5 * (1.0 - (1.0 - 2.0 * p) ** w)


def compose_flip_rate(eta: float, p: float) -> float:
    return eta * (1.0 - p) + (1.0 - eta) * p


@dataclass
class BlockCirculantKey:
    generators: List[np.ndarray]  # b generators of length m
    H: np.ndarray  # m x (b*m)
    m: int
    b: int
    tau: int
    eta: float
    row_weight: int  # W = sum w_j


def keygen(
    m: int,
    b: int,
    weights: Sequence[int] | int,
    tau: int,
    eta: float = 0.05,
    rng: np.random.Generator | None = None,
    max_tries: int = 200,
) -> BlockCirculantKey:
    rng = rng or np.random.default_rng()
    if b < 2:
        raise ValueError("need b >= 2 rings")
    if isinstance(weights, int):
        weights = [weights] * b
    if len(weights) != b:
        raise ValueError("weights length must equal b")
    for w in weights:
        if not (1 <= w <= m):
            raise ValueError(f"invalid weight {w}")

    for _ in range(max_tries):
        gens: List[np.ndarray] = []
        for w in weights:
            h = np.zeros(m, dtype=np.uint8)
            h[rng.choice(m, size=w, replace=False)] = 1
            gens.append(h)
        if not circulant_invertible(gens[-1]):
            continue
        blocks = [full_circulant(h) for h in gens]
        H = np.concatenate(blocks, axis=1)
        if gf2_rank(H) != m:
            continue
        return BlockCirculantKey(
            generators=gens,
            H=H,
            m=m,
            b=b,
            tau=tau,
            eta=eta,
            row_weight=int(sum(weights)),
        )
    raise RuntimeError("failed to sample invertible A_b / full-rank H")


def syndrome(key: BlockCirculantKey, y: np.ndarray) -> np.ndarray:
    return (key.H @ y.astype(np.uint8)) % 2


def detect_score(key: BlockCirculantKey, y: np.ndarray) -> int:
    ones = np.ones(key.m, dtype=np.uint8)
    return int(np.sum(syndrome(key, y) ^ ones))


def detect(key: BlockCirculantKey, y: np.ndarray) -> bool:
    return detect_score(key, y) <= key.tau


def encode(
    key: BlockCirculantKey,
    rng: np.random.Generator | None = None,
    add_noise: bool | None = None,
) -> np.ndarray:
    """Uniform sample from {c : H c = 1}, optionally xor Bern(eta)."""
    rng = rng or np.random.default_rng()
    m, b = key.m, key.b
    free = [rng.integers(0, 2, size=m, dtype=np.uint8) for _ in range(b - 1)]
    target = np.ones(m, dtype=np.uint8)
    for j, c_j in enumerate(free):
        target ^= (key.H[:, j * m : (j + 1) * m] @ c_j) % 2
    A_b = key.H[:, (b - 1) * m : b * m]
    c_b = gf2_circulant_solve(A_b, target)
    c = np.concatenate(free + [c_b])
    use_noise = key.eta > 0 if add_noise is None else add_noise
    if use_noise and key.eta > 0:
        noise = rng.random(key.b * key.m) < key.eta
        c = np.bitwise_xor(c, noise.astype(np.uint8))
    return c


def bsc(c: np.ndarray, p: float, rng: np.random.Generator | None = None) -> np.ndarray:
    rng = rng or np.random.default_rng()
    flips = rng.random(len(c)) < p
    return np.bitwise_xor(c, flips.astype(np.uint8))


def kernel_dimension(key: BlockCirculantKey) -> int:
    return key.b * key.m - gf2_rank(key.H)


def verify_shift_invariance(
    key: BlockCirculantKey, c: np.ndarray, ks: List[int] | None = None
) -> Tuple[bool, list[int]]:
    base = detect_score(key, c)
    if ks is None:
        ks = list(range(key.m))
    scores = []
    ok = True
    for k in ks:
        s = detect_score(key, simultaneous_shift(c, key.m, int(k)))
        scores.append(s)
        if s != base:
            ok = False
    return ok, scores


def evaluation_at_one(bits: np.ndarray) -> int:
    """Polynomial evaluation at X=1 over GF(2) = parity of bits."""
    return int(bits.sum() % 2)


def eta_zero_distinguisher(c: np.ndarray, m: int, b: int, generators: Sequence[np.ndarray]) -> bool:
    """Return True if the X=1 evaluations are consistent with noiseless coset encoding.

    Summing coordinates: sum(H c) = sum_j h_j(1) c^{(j)}(1).
    Target H c = 1 implies sum(H c) = m mod 2.
    For odd-weight (unit-at-1) generators, this is sum_j c^{(j)}(1) == (m mod 2).
    Uniform blocks match with probability 1/2.
    """
    lhs = 0
    for j in range(b):
        hj1 = evaluation_at_one(np.asarray(generators[j]))
        cj1 = evaluation_at_one(c[j * m : (j + 1) * m])
        lhs ^= hj1 & cj1
    return lhs == (m % 2)


def expected_syndrome_weight(key: BlockCirculantKey, p_channel: float) -> float:
    p_eff = compose_flip_rate(key.eta, p_channel)
    return key.m * q_bsc(p_eff, key.row_weight)


def suggest_tau(m: int, row_weight: int, eta: float, p_channel: float, margin: float = 0.08) -> int:
    """Pick tau above expected BSC score and below m/2 by a fractional margin."""
    p_eff = compose_flip_rate(eta, p_channel)
    exp = m * q_bsc(p_eff, row_weight)
    lo = int(np.ceil(exp + margin * m))
    hi = int(np.floor(m / 2 - margin * m))
    if lo > hi:
        return max(0, min(m, int(round(0.5 * (exp + m / 2)))))
    return lo
