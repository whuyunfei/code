"""Shared protocol for locked detector C (2-center × L=8 lattice + block-circulant)."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from . import block_circulant as bc
from .coco_photos import load_image
from .fast_radial import make_layout
from .integer_threshold import clopper_pearson, clopper_upper
from .lattice_carrier import embed_lattice
from .lattice_detect import scores_over_angles_lattice
from .residual_search import shared_grids
from .spatial_multiring import apply_attack, expanded_rotate_shape, psnr


M, W, ETA, B = 64, 1, 0.0, 4
GUARD = 0.15
SIZE = 256
L = 8
FPR_TEST = 1e-2
FPR_CALIB_TARGET = 5e-3
TPR_TARGET = 0.90
JPEG_Q_DEFAULT = 70
DELTA = 360.0 / M
DEFAULT_CENTER = ((SIZE - 1) / 2.0, (SIZE - 1) / 2.0)
ALT_CENTER = (DEFAULT_CENTER[0] + 0.5, DEFAULT_CENTER[1] + 0.5)
BLIND_CENTERS = (DEFAULT_CENTER, ALT_CENTER)

# Seeds from formal baseline_C run (figures/baseline_C.json)
BASELINE_KEY_SEEDS = [539553329, 2018912383, 1380592023]
EXTRA_KEY_SEEDS = [900001001, 900001002]  # pre-generated for confirm round


def make_key(rng: np.random.Generator) -> bc.BlockCirculantKey:
    tau = bc.suggest_tau(M, B * W, 0.03, 0.05)
    return bc.keygen(M, B, W, tau, ETA, rng)


def make_layout_c():
    return make_layout(SIZE, M, B, GUARD, 0.0)


def min_score(key, img, layout, step: float) -> float:
    deltas, _ = shared_grids(M, L)
    return scores_over_angles_lattice(
        key, img, layout, deltas, step, centers=BLIND_CENTERS
    ).best


def empiric_rate(scores: Sequence[float], thr: int) -> float:
    s = np.asarray(scores, dtype=np.float64)
    return float(np.mean(np.isfinite(s) & (s <= thr)))


def pick_threshold(
    scores_none: Sequence[float],
    scores_att: Sequence[float],
    tune_pos_scores: Sequence[float],
) -> dict:
    finite = [x for x in list(scores_none) + list(scores_att) if np.isfinite(x)]
    tmax = int(max(finite)) if finite else 0
    rows = []
    for t in range(tmax, -1, -1):
        fn = empiric_rate(scores_none, t)
        fa = empiric_rate(scores_att, t)
        tpr = empiric_rate(tune_pos_scores, t)
        within = fn <= FPR_CALIB_TARGET + 1e-15 and fa <= FPR_CALIB_TARGET + 1e-15
        tpr_ok = tpr >= TPR_TARGET
        has_margin = max(fn, fa) < FPR_CALIB_TARGET - 1e-15
        rows.append(
            {
                "t": t,
                "fpr_none": fn,
                "fpr_att": fa,
                "tpr_tune": tpr,
                "within_cap": within and tpr_ok,
                "ok": within and tpr_ok and has_margin,
            }
        )
    chosen = next((r["t"] for r in rows if r["ok"]), None)
    if chosen is None:
        chosen = next((r["t"] for r in rows if r.get("within_cap")), None)
    return {"threshold": chosen, "grid": rows, "calib_fpr_target": FPR_CALIB_TARGET}


def collect_scores(
    key,
    layout,
    step: float,
    paths: Sequence[Path],
    angles: Sequence[float] | None,
    kind: str,
    jpeg_q: int = JPEG_Q_DEFAULT,
    shift_xy: Tuple[float, float] = (0.0, 0.0),
) -> List[float]:
    scores = []
    for i, path in enumerate(paths):
        img = load_image(path, SIZE)
        if kind == "none":
            attacked = img
        else:
            ang = float(angles[i]) if angles is not None else 0.0
            attacked = apply_attack(img, "rot_jpeg", ang, jpeg_q, SIZE)
            if shift_xy != (0.0, 0.0):
                attacked = _shift_image(attacked, shift_xy[0], shift_xy[1])
        scores.append(min_score(key, attacked, layout, step))
    return scores


def _shift_image(image: np.ndarray, dx: float, dy: float) -> np.ndarray:
    """Translate by (dx, dy) pixels with zero fill; subpixel via ndimage."""
    from scipy.ndimage import shift as nd_shift

    if dx == 0.0 and dy == 0.0:
        return image
    # ndimage shift: (y, x, ...)
    return nd_shift(image, shift=(dy, dx, 0) if image.ndim == 3 else (dy, dx), order=1, mode="constant", cval=0.0)


def fit_step_for_psnr(
    images: Sequence[np.ndarray],
    target_psnr: float,
    init_step: float,
    rng: np.random.Generator,
    n: int = 40,
    tol: float = 0.3,
) -> dict:
    layout = make_layout_c()

    def med(step: float) -> float:
        vals = []
        for im in images[:n]:
            bits = rng.integers(0, 2, size=(B, M), dtype=np.uint8)
            vals.append(psnr(im, embed_lattice(im, layout, bits, step)))
        return float(np.median(vals))

    step = float(init_step)
    # Bracket: larger step → lower PSNR
    lo, hi = max(0.01, step * 0.25), min(1.0, step * 4.0)
    p_lo, p_hi = med(lo), med(hi)
    # Want med(step) ≈ target. If lo (small step) has high PSNR...
    # small step → high PSNR, large step → low PSNR
    if p_hi > target_psnr + tol:
        # even largest step still too high PSNR — need larger step
        hi = min(1.5, hi * 2)
        p_hi = med(hi)
    if p_lo < target_psnr - tol:
        lo = max(0.005, lo * 0.5)
        p_lo = med(lo)
    for _ in range(18):
        mid = 0.5 * (lo + hi)
        pm = med(mid)
        if abs(pm - target_psnr) <= tol:
            step = mid
            break
        if pm > target_psnr:
            lo = mid  # need more distortion → larger step
        else:
            hi = mid
        step = mid
    return {"target_psnr": target_psnr, "step": float(step), "psnr_median": med(step), "init_step": init_step}


def embed_paths(key, layout, step, paths, seeds) -> Tuple[List[np.ndarray], List[float]]:
    marked, psnrs = [], []
    for path, seed in zip(paths, seeds):
        img = load_image(path, SIZE)
        c = bc.encode(key, rng=np.random.default_rng(int(seed)), add_noise=False).reshape(B, M)
        mk = embed_lattice(img, layout, c, step)
        marked.append(mk)
        psnrs.append(psnr(img, mk))
    return marked, psnrs


def fpr_on(
    key,
    layout,
    step: float,
    thr: int,
    paths: Sequence[Path],
    angles: Sequence[float] | None,
    kind: str,
    jpeg_q: int = JPEG_Q_DEFAULT,
    shift_xy: Tuple[float, float] = (0.0, 0.0),
) -> dict:
    hits = 0
    t0 = time.perf_counter()
    for i, path in enumerate(paths):
        img = load_image(path, SIZE)
        if kind == "none":
            attacked = img
        else:
            ang = float(angles[i]) if angles is not None else 0.0
            attacked = apply_attack(img, "rot_jpeg", ang, jpeg_q, SIZE)
            if shift_xy != (0.0, 0.0):
                attacked = _shift_image(attacked, shift_xy[0], shift_xy[1])
        sc = min_score(key, attacked, layout, step)
        hits += int(np.isfinite(sc) and sc <= thr)
    elapsed = time.perf_counter() - t0
    n = len(paths)
    lo, hi = clopper_pearson(hits, n)
    return {
        "k": hits,
        "n": n,
        "fpr": hits / n,
        "cp_lo": lo,
        "cp_hi": hi,
        "cp_upper": clopper_upper(hits, n),
        "pass_upper": clopper_upper(hits, n) <= FPR_TEST,
        "seconds": elapsed,
        "sec_per_image": elapsed / max(n, 1),
    }


def tpr_on(
    key,
    layout,
    step: float,
    thr: int,
    marked_list: Sequence[np.ndarray],
    angles: Sequence[float],
    jpeg_q: int = JPEG_Q_DEFAULT,
    shift_xy: Tuple[float, float] = (0.0, 0.0),
) -> dict:
    hits = 0
    t0 = time.perf_counter()
    for marked, ang in zip(marked_list, angles):
        attacked = apply_attack(marked, "rot_jpeg", float(ang), jpeg_q, SIZE)
        if shift_xy != (0.0, 0.0):
            attacked = _shift_image(attacked, shift_xy[0], shift_xy[1])
        sc = min_score(key, attacked, layout, step)
        hits += int(np.isfinite(sc) and sc <= thr)
    elapsed = time.perf_counter() - t0
    n = len(marked_list)
    lo, hi = clopper_pearson(hits, n)
    return {
        "k": hits,
        "n": n,
        "tpr": hits / n if n else float("nan"),
        "cp_lo": lo,
        "cp_hi": hi,
        "pass": (hits / n >= TPR_TARGET) if n else False,
        "seconds": elapsed,
        "sec_per_image": elapsed / max(n, 1),
    }


def residual_probes() -> List[dict]:
    bin_w = DELTA / L
    out, seen = [], set()

    def add(delta: float, tag: str):
        d = float(delta % DELTA)
        k = round(d, 10)
        if k in seen:
            return
        seen.add(k)
        out.append({"delta": d, "tag": tag})

    for i in range(L):
        add(i * bin_w, "grid")
        add((i + 0.5) * bin_w, "mid")
    add(0.37 * bin_w, "off")
    add(0.73 * bin_w, "off")
    return sorted(out, key=lambda r: r["delta"])


def delta_min_tpr(
    key,
    layout,
    step: float,
    thr: int,
    marked_list: Sequence[np.ndarray],
    jpeg_q: int = JPEG_Q_DEFAULT,
    k_only: Sequence[int] = (0,),
) -> dict:
    probes = residual_probes()
    rows = []
    for k in k_only:
        use = probes if k == 0 else [p for p in probes if p["tag"] in ("mid", "off")] + [
            p for i, p in enumerate(probes) if p["tag"] == "grid" and i % 2 == 0
        ]
        # unique
        seen, uniq = set(), []
        for p in use:
            kk = round(p["delta"], 10)
            if kk in seen:
                continue
            seen.add(kk)
            uniq.append(p)
        for probe in sorted(uniq, key=lambda r: r["delta"]):
            theta = (k * DELTA + float(probe["delta"])) % 360.0
            h, w = expanded_rotate_shape(SIZE, theta)
            hits = 0
            for marked in marked_list:
                attacked = apply_attack(marked, "rot_jpeg", theta, jpeg_q, SIZE)
                sc = min_score(key, attacked, layout, step)
                hits += int(np.isfinite(sc) and sc <= thr)
            n = len(marked_list)
            rows.append(
                {
                    "k": int(k),
                    "delta": float(probe["delta"]),
                    "tag": probe["tag"],
                    "expand_odd": bool((h % 2) or (w % 2)),
                    "tpr": hits / n if n else float("nan"),
                }
            )
    mids = [r for r in rows if r["tag"] == "mid"]
    return {
        "points": rows,
        "mid_min": float(min(r["tpr"] for r in mids)) if mids else float("nan"),
        "all_min": float(min(r["tpr"] for r in rows)) if rows else float("nan"),
    }


def calibrate_and_eval(
    key,
    layout,
    step: float,
    calib_paths,
    tune_paths,
    neg_paths,
    pos_paths,
    delta_paths,
    angles_calib,
    angles_tune,
    angles_neg,
    angles_pos,
    encode_tune,
    encode_pos,
    encode_delta,
    jpeg_q: int = JPEG_Q_DEFAULT,
    n_delta: int | None = None,
    shift_xy: Tuple[float, float] = (0.0, 0.0),
) -> dict:
    """Full C protocol for one key at a given lattice step / JPEG / shift."""
    scores_none = collect_scores(key, layout, step, calib_paths, None, "none", jpeg_q)
    scores_att = collect_scores(
        key, layout, step, calib_paths, angles_calib, "rot_jpeg", jpeg_q, shift_xy
    )
    tune_pos_scores = []
    for path, seed, ang in zip(tune_paths, encode_tune, angles_tune):
        img = load_image(path, SIZE)
        c = bc.encode(key, rng=np.random.default_rng(int(seed)), add_noise=False).reshape(B, M)
        marked = embed_lattice(img, layout, c, step)
        attacked = apply_attack(marked, "rot_jpeg", float(ang), jpeg_q, SIZE)
        if shift_xy != (0.0, 0.0):
            attacked = _shift_image(attacked, shift_xy[0], shift_xy[1])
        tune_pos_scores.append(min_score(key, attacked, layout, step))
    pick = pick_threshold(scores_none, scores_att, tune_pos_scores)
    thr = pick["threshold"]
    row: Dict = {"step": step, "jpeg_q": jpeg_q, "shift_xy": list(shift_xy), "calibration": pick}
    if thr is None:
        row["failed"] = "no threshold"
        row["passed"] = False
        return row
    row["threshold"] = thr
    row["fpr_none"] = fpr_on(key, layout, step, thr, neg_paths, None, "none", jpeg_q)
    row["fpr_rot_jpeg"] = fpr_on(
        key, layout, step, thr, neg_paths, angles_neg, "rot_jpeg", jpeg_q, shift_xy
    )
    marked_pos, psnrs = embed_paths(key, layout, step, pos_paths, encode_pos)
    row["tpr_random"] = tpr_on(key, layout, step, thr, marked_pos, angles_pos, jpeg_q, shift_xy)
    row["psnr_median"] = float(np.median(psnrs))
    row["psnr_p10"] = float(np.percentile(psnrs, 10))
    row["psnr_p90"] = float(np.percentile(psnrs, 90))
    dpaths = delta_paths if n_delta is None else delta_paths[:n_delta]
    dseeds = encode_delta if n_delta is None else encode_delta[: len(dpaths)]
    marked_d, _ = embed_paths(key, layout, step, dpaths, dseeds)
    # For shift experiments, skip full δ curve (expensive); only when no shift
    if shift_xy == (0.0, 0.0):
        curve = delta_min_tpr(key, layout, step, thr, marked_d, jpeg_q, k_only=(0,))
        row["curve_summary"] = {"mid_min": curve["mid_min"], "all_min": curve["all_min"]}
        row["curve"] = curve["points"]
    else:
        row["curve_summary"] = {"mid_min": row["tpr_random"]["tpr"], "all_min": row["tpr_random"]["tpr"]}
        row["curve"] = []
    cs = row["curve_summary"]
    row["passed"] = bool(
        row["fpr_none"]["pass_upper"]
        and row["fpr_rot_jpeg"]["pass_upper"]
        and row["tpr_random"]["pass"]
        and (cs.get("mid_min") or 0) >= TPR_TARGET
        and (cs.get("all_min") or 0) >= TPR_TARGET
    )
    return row
