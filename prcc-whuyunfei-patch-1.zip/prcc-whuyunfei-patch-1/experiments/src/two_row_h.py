"""Two-row block-circulant parity checks with fixed sector count m.

H is 2m x (b m) with circulant m x m blocks. Then
H T_k = diag(R_k, R_k) H, so the all-ones coset score is T_k-invariant.
Nominal checks = 2m; geometric payload length stays b m.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence

import numpy as np

from .block_circulant import (
    full_circulant,
    gf2_rank,
    gf2_solve_affine,
    simultaneous_shift,
)


@dataclass
class TwoRowKey:
    generators: List[List[np.ndarray]]  # [row][block] generators of length m
    H: np.ndarray  # (2m) x (b m)
    m: int
    b: int
    n_rows: int
    eta: float
    rank: int
    kernel_dim: int
    row_weight: int


def keygen_two_row(
    m: int,
    b: int,
    weights: Sequence[int] | int,
    eta: float,
    rng: np.random.Generator | None = None,
    max_tries: int = 800,
    even_block: bool = True,
) -> TwoRowKey:
    """Sample a two-row H.

    If every block weight is odd, the all-ones vector lies in the left kernel and
    the rank is at most 2m-1. We accept that rank. Setting ``even_block`` flips the
    last generator of the second row to weight ``w-1`` (even) when w>=2, which can
    restore rank 2m.
    """
    rng = rng or np.random.default_rng()
    if isinstance(weights, int):
        weights = [weights] * b
    if len(weights) != b:
        raise ValueError("weights length must equal b")
    n_rows = 2
    n_checks = n_rows * m
    for _ in range(max_tries):
        gens: List[List[np.ndarray]] = []
        blocks_rows = []
        for r in range(n_rows):
            row_gens = []
            row_blocks = []
            for j, w in enumerate(weights):
                ww = w
                if even_block and r == 1 and j == b - 1:
                    # One even-weight block breaks the all-ones left kernel.
                    ww = w + 1 if w % 2 == 1 else w
                    ww = min(ww, m)
                h = np.zeros(m, dtype=np.uint8)
                h[rng.choice(m, size=ww, replace=False)] = 1
                row_gens.append(h)
                row_blocks.append(full_circulant(h))
            gens.append(row_gens)
            blocks_rows.append(np.concatenate(row_blocks, axis=1))
        H = np.concatenate(blocks_rows, axis=0)
        rank = gf2_rank(H)
        # Odd-weight-only structure caps rank at 2m-1; with an even block we want 2m.
        min_rank = n_checks if even_block else n_checks - 1
        if rank < min_rank:
            continue
        target = np.ones(n_checks, dtype=np.uint8)
        try:
            gf2_solve_affine(H, target, rng)
        except np.linalg.LinAlgError:
            continue
        return TwoRowKey(
            generators=gens,
            H=H,
            m=m,
            b=b,
            n_rows=n_rows,
            eta=eta,
            rank=rank,
            kernel_dim=b * m - rank,
            row_weight=int(sum(int(g.sum()) for row in gens for g in row)),
        )
    raise RuntimeError("failed to sample two-row H with solvable all-ones coset")


def detect_score(key: TwoRowKey, y: np.ndarray) -> int:
    ones = np.ones(key.n_rows * key.m, dtype=np.uint8)
    s = (key.H @ y.astype(np.uint8)) % 2
    return int(np.sum(s ^ ones))


def encode(key: TwoRowKey, rng: np.random.Generator | None = None, add_noise: bool | None = None) -> np.ndarray:
    rng = rng or np.random.default_rng()
    target = np.ones(key.n_rows * key.m, dtype=np.uint8)
    c = gf2_solve_affine(key.H, target, rng)
    use_noise = key.eta > 0 if add_noise is None else add_noise
    if use_noise and key.eta > 0:
        noise = rng.random(key.b * key.m) < key.eta
        c = np.bitwise_xor(c, noise.astype(np.uint8))
    return c


def score_invariant_under_Tk(key: TwoRowKey, c: np.ndarray) -> bool:
    base = detect_score(key, c)
    for k in range(key.m):
        if detect_score(key, simultaneous_shift(c, key.m, k)) != base:
            return False
    return True
