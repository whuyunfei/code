"""Denser residual search on the frozen m=64, w=1, η=0 lattice baseline.

Paired L ∈ {8,16,32}: same key (seed independent of L), images, codewords,
and attack angles. Each L calibrates its own blind-search threshold.

Also: own-grid / own-mid / random-off-grid / valley fine-scan; known-true-angle
control on the same attacked images; θ = kΔ+δ for several integer steps k.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np

from . import block_circulant as bc
from .coco_photos import load_image, split_paths
from .fast_radial import make_layout
from .integer_threshold import clopper_pearson, clopper_upper, largest_integer_threshold
from .lattice_carrier import embed_lattice
from .lattice_detect import known_angle_ber, known_angle_score, scores_over_angles_lattice
from .residual_search import shared_grids
from .spatial_multiring import apply_attack, psnr


M = 64
W = 1
ETA = 0.0
B = 4
GUARD = 0.15
SIZE = 256
STEP = 0.19745071411132814
FPR_ALPHA = 1e-2
TPR_TARGET = 0.90
JPEG_Q = 70
DELTA = 360.0 / M
LS = (8, 16, 32)


def _make_key(rng: np.random.Generator) -> bc.BlockCirculantKey:
    tau = bc.suggest_tau(M, B * W, 0.03, 0.05)
    return bc.keygen(M, B, W, tau, ETA, rng)


def _probes_for_L(L: int) -> List[dict]:
    """Own grid, own midpoints, and a few tagged extras."""
    bin_w = DELTA / L
    out = []
    seen = set()

    def add(delta: float, tag: str):
        d = float(delta % DELTA)
        key = round(d, 10)
        if key in seen:
            return
        seen.add(key)
        out.append({"delta": d, "tag": tag})

    for i in range(L):
        add(i * bin_w, "grid")
        add((i + 0.5) * bin_w, "mid")
    # Valley fine-scan around first midpoint (worst expected for uniform grid)
    mid0 = 0.5 * bin_w
    for frac in (-0.25, -0.125, 0.0, 0.125, 0.25):
        add(mid0 + frac * bin_w, "valley")
    # Random off-grid: fixed offsets not on grid/mid
    add(0.37 * bin_w, "off")
    add(0.73 * bin_w, "off")
    return sorted(out, key=lambda r: r["delta"])


def calibrate(key, layout, L, paths, size) -> Tuple[int | None, List[float], float]:
    deltas, _ = shared_grids(M, L)
    t0 = time.perf_counter()
    scores = [
        scores_over_angles_lattice(key, load_image(p, size), layout, deltas, STEP).best
        for p in paths
    ]
    elapsed = time.perf_counter() - t0
    return largest_integer_threshold(scores, FPR_ALPHA), scores, elapsed


def fpr_block(key, layout, L, thr, paths, size, angles: Sequence[float] | None, kind: str) -> dict:
    deltas, _ = shared_grids(M, L)
    hits = 0
    t0 = time.perf_counter()
    for i, path in enumerate(paths):
        img = load_image(path, size)
        if kind == "none":
            attacked = img
        else:
            attacked = apply_attack(img, "rot_jpeg", float(angles[i]), JPEG_Q, size)
        sc = scores_over_angles_lattice(key, attacked, layout, deltas, STEP).best
        hits += int(np.isfinite(sc) and sc <= thr)
    elapsed = time.perf_counter() - t0
    n = len(paths)
    lo, hi = clopper_pearson(hits, n)
    return {
        "k": hits,
        "n": n,
        "fpr": hits / n,
        "cp_lo": lo,
        "cp_hi": hi,
        "cp_upper": clopper_upper(hits, n),
        "seconds": elapsed,
        "sec_per_image": elapsed / n if n else float("nan"),
    }


def eval_paired_attacks(
    key,
    layout,
    L: int,
    thr: int,
    marked_list: Sequence[np.ndarray],
    bits_list: Sequence[np.ndarray],
    angles: Sequence[float],
) -> dict:
    """Blind vs known-angle on the same rot+JPEG attacked images."""
    deltas, _ = shared_grids(M, L)
    n = len(marked_list)
    blind_hits = 0
    known_hits = 0
    bers = []
    t0 = time.perf_counter()
    for marked, bits, ang in zip(marked_list, bits_list, angles):
        attacked = apply_attack(marked, "rot_jpeg", float(ang), JPEG_Q, SIZE)
        sc_b = scores_over_angles_lattice(key, attacked, layout, deltas, STEP).best
        blind_hits += int(np.isfinite(sc_b) and sc_b <= thr)
        sc_k = known_angle_score(key, attacked, layout, STEP, float(ang))
        known_hits += int(sc_k is not None and sc_k <= thr)
        bers.append(known_angle_ber(attacked, layout, bits, STEP, float(ang)))
    elapsed = time.perf_counter() - t0
    blo, bhi = clopper_pearson(blind_hits, n)
    klo, khi = clopper_pearson(known_hits, n)
    return {
        "n": n,
        "blind_tpr": blind_hits / n,
        "blind_k": blind_hits,
        "blind_cp_lo": blo,
        "blind_cp_hi": bhi,
        "known_tpr": known_hits / n,
        "known_k": known_hits,
        "known_cp_lo": klo,
        "known_cp_hi": khi,
        "known_ber_mean": float(np.mean(bers)),
        "known_ber_p90": float(np.percentile(bers, 90)),
        "seconds": elapsed,
        "sec_per_image": elapsed / n,
    }


def _probes_for_k(probes: Sequence[dict], k: int) -> List[dict]:
    """Full probe set at k=0; other integer steps: mids + subsampled grid + offs."""
    if k == 0:
        return list(probes)
    out = []
    grids = [p for p in probes if p["tag"] == "grid"]
    for i, p in enumerate(grids):
        if i % 4 == 0:
            out.append(p)
    out.extend([p for p in probes if p["tag"] in ("mid", "off")])
    # keep unique by delta
    seen = set()
    uniq = []
    for p in out:
        key = round(p["delta"], 10)
        if key in seen:
            continue
        seen.add(key)
        uniq.append(p)
    return sorted(uniq, key=lambda r: r["delta"])


def delta_curve_with_k(
    key,
    layout,
    L: int,
    thr: int,
    marked_list: Sequence[np.ndarray],
    bits_list: Sequence[np.ndarray],
    probes: Sequence[dict],
    ks: Sequence[int],
) -> List[dict]:
    deltas, _ = shared_grids(M, L)
    n = len(marked_list)
    rows = []
    for k in ks:
        use = _probes_for_k(probes, k)
        for probe in use:
            delta = float(probe["delta"])
            theta = (k * DELTA + delta) % 360.0
            blind_hits = 0
            known_hits = 0
            t0 = time.perf_counter()
            for marked, bits in zip(marked_list, bits_list):
                attacked = apply_attack(marked, "rot_jpeg", theta, JPEG_Q, SIZE)
                sc_b = scores_over_angles_lattice(key, attacked, layout, deltas, STEP).best
                blind_hits += int(np.isfinite(sc_b) and sc_b <= thr)
                sc_k = known_angle_score(key, attacked, layout, STEP, theta)
                known_hits += int(sc_k is not None and sc_k <= thr)
            elapsed = time.perf_counter() - t0
            blo, bhi = clopper_pearson(blind_hits, n)
            klo, khi = clopper_pearson(known_hits, n)
            rows.append(
                {
                    "L": L,
                    "k": int(k),
                    "delta": delta,
                    "theta": theta,
                    "tag": probe["tag"],
                    "blind_tpr": blind_hits / n,
                    "blind_cp_lo": blo,
                    "blind_cp_hi": bhi,
                    "known_tpr": known_hits / n,
                    "known_cp_lo": klo,
                    "known_cp_hi": khi,
                    "seconds": elapsed,
                    "sec_per_image": elapsed / n,
                }
            )
            print(
                f"  L={L} k={k} δ={delta:.4f} ({probe['tag']}) "
                f"blind={blind_hits/n:.3f} known={known_hits/n:.3f} "
                f"({elapsed/n*1000:.1f} ms/img)",
                flush=True,
            )
    return rows


def _summarize_curve(rows: List[dict], L: int, k: int) -> dict:
    sub = [r for r in rows if r["L"] == L and r["k"] == k]
    if not sub:
        return {}
    by_tag: Dict[str, List[dict]] = {}
    for r in sub:
        by_tag.setdefault(r["tag"], []).append(r)
    out = {"k": k}
    for tag, items in by_tag.items():
        tprs = [r["blind_tpr"] for r in items]
        known = [r["known_tpr"] for r in items]
        out[f"blind_{tag}_mean"] = float(np.mean(tprs))
        out[f"blind_{tag}_min"] = float(np.min(tprs))
        out[f"known_{tag}_mean"] = float(np.mean(known))
        out[f"known_{tag}_min"] = float(np.min(known))
    out["blind_min_all"] = float(min(r["blind_tpr"] for r in sub))
    out["known_min_all"] = float(min(r["known_tpr"] for r in sub))
    # worst mid for this L
    mids = [r for r in sub if r["tag"] == "mid"]
    if mids:
        worst = min(mids, key=lambda r: r["blind_tpr"])
        out["worst_mid_delta"] = worst["delta"]
        out["worst_mid_blind"] = worst["blind_tpr"]
        out["worst_mid_known"] = worst["known_tpr"]
    return out


def _plot(rows: List[dict], out_png: Path) -> None:
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return
    # Facet by L; lines for k; markers for blind at k=0
    fig, axes = plt.subplots(1, len(LS), figsize=(4.0 * len(LS), 3.5), sharey=True)
    for ax, L in zip(axes, LS):
        for k in sorted({r["k"] for r in rows if r["L"] == L}):
            sub = sorted([r for r in rows if r["L"] == L and r["k"] == k], key=lambda r: r["delta"])
            # unique deltas (probes may repeat tags)
            xs = [r["delta"] for r in sub]
            ys = [r["blind_tpr"] for r in sub]
            ax.plot(xs, ys, marker="o", ms=2.5, lw=1.0, label=f"k={k} blind")
            if k == 0:
                known = [r["known_tpr"] for r in sub]
                ax.plot(xs, known, marker="x", ms=3, lw=0.8, ls="--", label="k=0 known")
                mids = [r for r in sub if r["tag"] == "mid"]
                ax.scatter(
                    [r["delta"] for r in mids],
                    [r["blind_tpr"] for r in mids],
                    c="C3",
                    s=22,
                    zorder=3,
                )
        ax.axhline(TPR_TARGET, color="gray", ls=":", lw=0.8)
        ax.set_title(f"L={L} (bin={DELTA/L:.3f}°)")
        ax.set_xlabel("δ (deg)")
        ax.set_xlim(0, DELTA)
        ax.set_ylim(0, 1.02)
        ax.legend(fontsize=6, loc="lower left")
    axes[0].set_ylabel("TPR")
    fig.suptitle("m=64 w=1 η=0 denser residual search", fontsize=11)
    fig.tight_layout()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_png, dpi=140)
    plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=2)
    ap.add_argument("--n-pos", type=int, default=250)
    ap.add_argument("--n-neg", type=int, default=1500)
    ap.add_argument("--n-calib", type=int, default=1000)
    ap.add_argument("--n-delta", type=int, default=120)
    ap.add_argument("--ks", type=str, default="0,1,7,31")
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()

    ks = [int(x) for x in args.ks.split(",") if x.strip() != ""]
    rng = np.random.default_rng(args.seed)
    # Key seed must NOT depend on L
    key = _make_key(rng)
    layout = make_layout(SIZE, M, B, GUARD, 0.0)

    pos_paths = split_paths("test_pos")[: args.n_pos]
    neg_paths = split_paths("test_neg")[: args.n_neg]
    calib_paths = split_paths("calib")[: args.n_calib]
    delta_paths = split_paths("test_pos")[: args.n_delta]

    # Shared codewords / angles across L
    encode_seeds = rng.integers(0, 2**31 - 1, size=len(pos_paths))
    encode_seeds_delta = rng.integers(0, 2**31 - 1, size=len(delta_paths))
    angles_pos = rng.uniform(0.0, 360.0, size=len(pos_paths))
    angles_neg = rng.uniform(0.0, 360.0, size=len(neg_paths))

    def embed_set(paths, seeds):
        marked, bits = [], []
        psnrs = []
        for path, seed in zip(paths, seeds):
            img = load_image(path, SIZE)
            erng = np.random.default_rng(int(seed))
            c = bc.encode(key, rng=erng, add_noise=False).reshape(B, M)
            mk = embed_lattice(img, layout, c, STEP)
            marked.append(mk)
            bits.append(c)
            psnrs.append(psnr(img, mk))
        return marked, bits, psnrs

    print("embedding paired positives…", flush=True)
    marked_pos, bits_pos, psnrs_pos = embed_set(pos_paths, encode_seeds)
    print("embedding δ-curve set…", flush=True)
    marked_delta, bits_delta, _ = embed_set(delta_paths, encode_seeds_delta)

    per_L = []
    all_curve_rows: List[dict] = []

    for L in LS:
        print(f"\n=== L={L} bin={DELTA/L:.4f}° max_mismatch≈{0.5*DELTA/L:.4f}° ===", flush=True)
        thr, calib_scores, calib_sec = calibrate(key, layout, L, calib_paths, SIZE)
        row: Dict = {
            "m": M,
            "w": W,
            "eta": ETA,
            "L": L,
            "step": STEP,
            "size": SIZE,
            "bin_deg": DELTA / L,
            "max_mismatch_deg": 0.5 * DELTA / L,
            "threshold": thr,
            "mass0_calib": float(np.mean(np.asarray(calib_scores) == 0)),
            "calib_seconds": calib_sec,
            "calib_sec_per_image": calib_sec / len(calib_paths),
            "psnr_median": float(np.median(psnrs_pos)),
        }
        if thr is None:
            row["failed"] = "no threshold"
            per_L.append(row)
            print("NO THRESHOLD", flush=True)
            continue

        print(f"thr={thr}; FPR none / random-rot+JPEG", flush=True)
        row["fpr_none"] = fpr_block(key, layout, L, thr, neg_paths, SIZE, None, "none")
        row["fpr_rot_jpeg_random"] = fpr_block(
            key, layout, L, thr, neg_paths, SIZE, angles_neg, "rot_jpeg"
        )

        print("paired random-θ: blind vs known", flush=True)
        row["random_theta"] = eval_paired_attacks(
            key, layout, L, thr, marked_pos, bits_pos, angles_pos
        )

        probes = _probes_for_L(L)
        print(f"δ curve + k∈{ks} ({len(probes)} probes)", flush=True)
        curve = delta_curve_with_k(
            key, layout, L, thr, marked_delta, bits_delta, probes, ks
        )
        all_curve_rows.extend(curve)
        row["curve_summaries"] = [_summarize_curve(curve, L, k) for k in ks]
        # Primary summary at k=0
        s0 = next(s for s in row["curve_summaries"] if s.get("k") == 0)
        row["k0_blind_mid_min"] = s0.get("blind_mid_min")
        row["k0_known_mid_min"] = s0.get("known_mid_min")
        row["k0_blind_grid_min"] = s0.get("blind_grid_min")
        row["k0_known_grid_min"] = s0.get("known_grid_min")
        row["k0_blind_min_all"] = s0.get("blind_min_all")
        row["k0_known_min_all"] = s0.get("known_min_all")

        rt = row["random_theta"]
        row["passed_random"] = bool(
            rt["blind_tpr"] >= TPR_TARGET
            and row["fpr_none"]["cp_upper"] <= FPR_ALPHA
            and row["psnr_median"] >= 34.0
        )
        row["passed_midpoint"] = bool(
            (row["k0_blind_mid_min"] or 0) >= TPR_TARGET
            and row["fpr_none"]["cp_upper"] <= FPR_ALPHA
        )
        row["search_gap"] = bool(rt["known_tpr"] - rt["blind_tpr"] > 0.05) or bool(
            (row["k0_known_mid_min"] or 0) - (row["k0_blind_mid_min"] or 0) > 0.05
        )
        print(
            f"L={L} thr={thr} random blind={rt['blind_tpr']:.3f} known={rt['known_tpr']:.3f} "
            f"mid_blind_min={row['k0_blind_mid_min']} mid_known_min={row['k0_known_mid_min']} "
            f"FPRu={row['fpr_none']['cp_upper']:.4f} "
            f"pass_rand={row['passed_random']} pass_mid={row['passed_midpoint']} "
            f"search_gap={row['search_gap']}",
            flush=True,
        )
        per_L.append(row)

    # Smallest L that passes midpoint + random + FPR
    ok = [r for r in per_L if r.get("passed_midpoint") and r.get("passed_random")]
    if ok:
        best = min(ok, key=lambda r: r["L"])
        decision = (
            f"Smallest L that flattens midpoints under FPR: L={best['L']} "
            f"(mid_min={best['k0_blind_mid_min']}, random={best['random_theta']['blind_tpr']:.3f})."
        )
    else:
        # Diagnose
        gaps = [r for r in per_L if r.get("search_gap")]
        if gaps and all(
            (r.get("k0_known_mid_min") or 0) < TPR_TARGET for r in per_L if r.get("threshold") is not None
        ):
            decision = (
                "Known-angle mid TPR also below 90%: denser L alone is unlikely to fix; "
                "inspect rotation resampling / extract alignment."
            )
        elif gaps:
            decision = (
                "Known-angle stays high while blind mid stays low even at densest L: "
                "keep improving search (or hybrid coarse+fine)."
            )
        else:
            decision = (
                "No L in {8,16,32} simultaneously meets random-θ TPR, midpoint TPR, and FPR upper."
            )

    out = {
        "baseline": {"m": M, "w": W, "eta": ETA, "step": STEP, "size": SIZE},
        "note": (
            "Same key for all L (seed independent of L). Paired images/codewords/angles. "
            "δ curve includes k*Δ+δ for several k; known-angle control on same attacks."
        ),
        "ks": ks,
        "per_L": per_L,
        "curve": all_curve_rows,
        "decision": decision,
    }

    if args.out:
        out_path = Path(args.out)
        if not out_path.is_absolute():
            out_path = Path(__file__).resolve().parents[1] / out_path
    else:
        out_path = Path(__file__).resolve().parents[2] / "figures" / "dense_search.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2))
    _plot(all_curve_rows, out_path.with_suffix(".png"))
    print(decision, flush=True)
    print(f"wrote {out_path}", flush=True)


if __name__ == "__main__":
    main()
