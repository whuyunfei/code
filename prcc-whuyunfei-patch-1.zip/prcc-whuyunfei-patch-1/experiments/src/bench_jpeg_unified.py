"""Unified-threshold JPEG sweep on frozen detector C (~38 dB step).

Formal protocol: mixed-Q calibration (unmarked + per-image worst score over
Q∈{50..90} on rot+JPEG), freeze one τ per key, then evaluate every Q with
that same τ. Q70-only calibration is retained as a migration / ablation arm.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from . import block_circulant as bc
from .baseline_c_common import (
    BASELINE_KEY_SEEDS,
    EXTRA_KEY_SEEDS,
    FPR_TEST,
    SIZE,
    TPR_TARGET,
    collect_scores,
    delta_min_tpr,
    embed_paths,
    fpr_on,
    make_key,
    make_layout_c,
    min_score,
    pick_threshold,
    tpr_on,
)
from .coco_photos import load_image, split_paths
from .lattice_carrier import embed_lattice
from .spatial_multiring import apply_attack


STEP = 0.141640625
JPEG_QS = [90, 80, 70, 60, 50]


def _tune_pos_scores(key, layout, step, paths, seeds, angles, jpeg_q: int):
    out = []
    for path, seed, ang in zip(paths, seeds, angles):
        img = load_image(path, SIZE)
        c = bc.encode(key, rng=np.random.default_rng(int(seed)), add_noise=False).reshape(4, 64)
        marked = embed_lattice(img, layout, c, step)
        attacked = apply_attack(marked, "rot_jpeg", float(ang), jpeg_q, SIZE)
        out.append(min_score(key, attacked, layout, step))
    return out


def _mixed_att_scores(key, layout, step, paths, angles, qs):
    """Per image: min score over Q (worst for lower-better FPR)."""
    out = []
    for i, path in enumerate(paths):
        img = load_image(path, SIZE)
        ang = float(angles[i])
        scores_q = []
        for q in qs:
            attacked = apply_attack(img, "rot_jpeg", ang, q, SIZE)
            scores_q.append(min_score(key, attacked, layout, step))
        out.append(float(np.min(scores_q)))
    return out


def _mixed_tune_pos(key, layout, step, paths, seeds, angles, qs):
    """Per image: max score over Q (must clear thr at every Q)."""
    out = []
    for path, seed, ang in zip(paths, seeds, angles):
        img = load_image(path, SIZE)
        c = bc.encode(key, rng=np.random.default_rng(int(seed)), add_noise=False).reshape(4, 64)
        marked = embed_lattice(img, layout, c, step)
        scores_q = []
        for q in qs:
            attacked = apply_attack(marked, "rot_jpeg", float(ang), q, SIZE)
            scores_q.append(min_score(key, attacked, layout, step))
        out.append(float(np.max(scores_q)))
    return out


def eval_at_q(key, layout, step, thr, neg, pos, delta, angles_neg, angles_pos, encode_pos, encode_delta, q, n_delta):
    fpr_none = fpr_on(key, layout, step, thr, neg, None, "none", q)
    fpr_att = fpr_on(key, layout, step, thr, neg, angles_neg, "rot_jpeg", q)
    marked, psnrs = embed_paths(key, layout, step, pos, encode_pos)
    tpr = tpr_on(key, layout, step, thr, marked, angles_pos, q)
    marked_d, _ = embed_paths(key, layout, step, delta[:n_delta], encode_delta[:n_delta])
    curve = delta_min_tpr(key, layout, step, thr, marked_d, q, k_only=(0,))
    passed = bool(
        fpr_none["pass_upper"]
        and fpr_att["pass_upper"]
        and tpr["pass"]
        and curve["mid_min"] >= TPR_TARGET
        and curve["all_min"] >= TPR_TARGET
    )
    return {
        "jpeg_q": q,
        "fpr_none": fpr_none,
        "fpr_rot_jpeg": fpr_att,
        "tpr_random": tpr,
        "curve_summary": {"mid_min": curve["mid_min"], "all_min": curve["all_min"]},
        "psnr_median": float(np.median(psnrs)),
        "passed": passed,
    }


def run_key(key_id, key_seed, step, shared, n_delta):
    print(f"\n######## key {key_id} seed={key_seed} ########", flush=True)
    key = make_key(np.random.default_rng(key_seed))
    layout = make_layout_c()

    # --- Mode A: calibrate on Q=70 only ---
    scores_none = collect_scores(key, layout, step, shared["calib"], None, "none", 70)
    scores_att70 = collect_scores(
        key, layout, step, shared["calib"], shared["angles_calib"], "rot_jpeg", 70
    )
    tune70 = _tune_pos_scores(
        key, layout, step, shared["tune"], shared["encode_tune"], shared["angles_tune"], 70
    )
    pick70 = pick_threshold(scores_none, scores_att70, tune70)
    thr70 = pick70["threshold"]
    print(f"Q70-calib thr={thr70}", flush=True)

    rows70 = []
    if thr70 is not None:
        for q in JPEG_QS:
            row = eval_at_q(
                key,
                layout,
                step,
                thr70,
                shared["neg"],
                shared["pos"],
                shared["delta"],
                shared["angles_neg"],
                shared["angles_pos"],
                shared["encode_pos"],
                shared["encode_delta"],
                q,
                n_delta,
            )
            rows70.append(row)
            print(
                f"  [Q70-thr] Q={q} TPR={row['tpr_random']['tpr']:.3f} "
                f"mid={row['curve_summary']['mid_min']:.3f} "
                f"FPRu={row['fpr_none']['cp_upper']:.4f} "
                f"FPRatt={row['fpr_rot_jpeg']['cp_upper']:.4f} pass={row['passed']}",
                flush=True,
            )

    all_pass_70 = bool(rows70) and all(r["passed"] for r in rows70)
    result = {
        "key_id": key_id,
        "key_seed": key_seed,
        "q70_calibration": pick70,
        "threshold_q70": thr70,
        "eval_q70_thr": rows70,
        "all_pass_q70_thr": all_pass_70,
        "migration_q70": {
            "threshold": thr70,
            "all_pass": all_pass_70,
            "eval": rows70,
        },
    }

    # --- Formal: mixed-Q calibration for every key ---
    print("mixed-Q calibration (formal protocol)…", flush=True)
    scores_att_mix = _mixed_att_scores(
        key, layout, step, shared["calib"], shared["angles_calib"], JPEG_QS
    )
    tune_mix = _mixed_tune_pos(
        key, layout, step, shared["tune"], shared["encode_tune"], shared["angles_tune"], JPEG_QS
    )
    pick_mix = pick_threshold(scores_none, scores_att_mix, tune_mix)
    thr_mix = pick_mix["threshold"]
    print(f"mixed-Q thr={thr_mix}", flush=True)
    rows_mix = []
    if thr_mix is not None:
        for q in JPEG_QS:
            row = eval_at_q(
                key,
                layout,
                step,
                thr_mix,
                shared["neg"],
                shared["pos"],
                shared["delta"],
                shared["angles_neg"],
                shared["angles_pos"],
                shared["encode_pos"],
                shared["encode_delta"],
                q,
                n_delta,
            )
            rows_mix.append(row)
            print(
                f"  [mixed-thr] Q={q} TPR={row['tpr_random']['tpr']:.3f} "
                f"mid={row['curve_summary']['mid_min']:.3f} "
                f"FPRatt_u={row['fpr_rot_jpeg']['cp_upper']:.4f} pass={row['passed']}",
                flush=True,
            )
    result["mode"] = "mixed_q_threshold"
    result["mixed_calibration"] = pick_mix
    result["threshold_final"] = thr_mix
    result["eval_final"] = rows_mix
    result["all_pass"] = bool(rows_mix) and all(r["passed"] for r in rows_mix)
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--step", type=float, default=STEP)
    ap.add_argument("--seed", type=int, default=50)
    ap.add_argument("--n-keys", type=int, default=3)
    ap.add_argument("--n-neg", type=int, default=1500)
    ap.add_argument("--n-pos", type=int, default=300)
    ap.add_argument("--n-delta", type=int, default=60)
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    calib = split_paths("calib")
    tune = split_paths("tune")
    neg = split_paths("test_neg")[: args.n_neg]
    pos = split_paths("test_pos")[: args.n_pos]
    delta = split_paths("test_pos")[: args.n_delta]
    shared = {
        "calib": calib,
        "tune": tune,
        "neg": neg,
        "pos": pos,
        "delta": delta,
        "angles_calib": rng.uniform(0, 360, len(calib)),
        "angles_tune": rng.uniform(0, 360, len(tune)),
        "angles_neg": rng.uniform(0, 360, len(neg)),
        "angles_pos": rng.uniform(0, 360, len(pos)),
        "encode_tune": rng.integers(0, 2**31 - 1, len(tune)),
        "encode_pos": rng.integers(0, 2**31 - 1, len(pos)),
        "encode_delta": rng.integers(0, 2**31 - 1, len(delta)),
    }
    key_seeds = (BASELINE_KEY_SEEDS + EXTRA_KEY_SEEDS)[: args.n_keys]
    rows = [run_key(i, ks, args.step, shared, args.n_delta) for i, ks in enumerate(key_seeds)]

    n_q70 = sum(1 for r in rows if r.get("all_pass_q70_thr"))
    n_final = sum(1 for r in rows if r.get("all_pass"))
    decision = (
        f"Formal mixed-Q protocol: {n_final}/{len(rows)} keys cover Q=50–90 with one frozen τ. "
        f"Migration (Q70-only calib): {n_q70}/{len(rows)} keys cover the same Q grid."
    )
    out = {
        "step": args.step,
        "jpeg_qs": JPEG_QS,
        "protocol": "mixed_q_formal",
        "note": (
            "Formal: every key uses mixed-Q calibration (per-image worst over Q grid), "
            "then one frozen τ is evaluated at each Q. Q70-only calibration is reported "
            "as migration/ablation only."
        ),
        "per_key": rows,
        "decision": decision,
    }
    out_path = (
        Path(args.out)
        if args.out
        else Path(__file__).resolve().parents[2] / "figures" / "jpeg_unified.json"
    )
    if args.out and not Path(args.out).is_absolute():
        out_path = Path(__file__).resolve().parents[1] / args.out
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2))
    print(decision, flush=True)
    print(f"wrote {out_path}", flush=True)


if __name__ == "__main__":
    main()
