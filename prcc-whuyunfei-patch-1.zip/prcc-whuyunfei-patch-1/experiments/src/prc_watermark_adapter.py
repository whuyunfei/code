"""Adapter around XuandongZhao/PRC-Watermark bit-level KeyGen/Encode/Detect.

Pure NumPy + galois port of vendor/PRC-Watermark/src/prc.py (no torch/ldpc).
Diffusion pipelines are not used.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional, Tuple

import numpy as np
from scipy.sparse import csr_matrix
from scipy.special import binom

try:
    import galois

    GF = galois.GF(2)
    _HAS_PRC = True
    _IMPORT_ERR: Optional[Exception] = None
except Exception as e:  # pragma: no cover
    GF = None
    _HAS_PRC = False
    _IMPORT_ERR = e


def available() -> bool:
    return _HAS_PRC


def KeyGen(n, message_length=32, false_positive_rate=1e-2, t=3, g=None, r=None, noise_rate=None):
    if not _HAS_PRC:
        raise ImportError(f"PRC deps missing: {_IMPORT_ERR}")
    num_test_bits = int(np.ceil(np.log2(1 / false_positive_rate)))
    secpar = int(np.log2(max(binom(n, t), 2)))
    if g is None:
        g = min(secpar, max(8, n // 8))
    if noise_rate is None:
        noise_rate = float(min(0.5, max(0.05, 1 - 2 ** (-secpar / max(g, 1) ** 2))))
    k = message_length + g + num_test_bits
    if r is None:
        r = max(t, n - k - max(secpar // 2, 4))
    r = int(min(max(r, t), n - 2))
    k = min(k, n - r)

    generator_matrix = GF.Random((n, k))
    row_indices, col_indices, data = [], [], []
    for row in range(r):
        pool = n - r + row
        take = min(t - 1, pool)
        chosen_indices = np.random.choice(pool, take, replace=False)
        chosen_indices = np.append(chosen_indices, n - r + row)
        row_indices.extend([row] * len(chosen_indices))
        col_indices.extend(chosen_indices.tolist())
        data.extend([1] * len(chosen_indices))
        generator_matrix[n - r + row] = generator_matrix[chosen_indices[:-1]].sum(axis=0)
    parity_check_matrix = csr_matrix((data, (row_indices, col_indices)), shape=(r, n))

    max_bp_iter = int(np.log(max(n, 2)) / np.log(max(t, 2)))
    one_time_pad = GF.Random(n)
    test_bits = GF.Random(num_test_bits)
    permutation = np.random.permutation(n)
    generator_matrix = generator_matrix[permutation]
    one_time_pad = one_time_pad[permutation]
    parity_check_matrix = parity_check_matrix[:, permutation]

    encoding_key = (generator_matrix, one_time_pad, test_bits, g, noise_rate)
    decoding_key = (
        generator_matrix,
        parity_check_matrix,
        one_time_pad,
        false_positive_rate,
        noise_rate,
        test_bits,
        g,
        max_bp_iter,
        t,
    )
    return encoding_key, decoding_key


def Encode(encoding_key, message=None) -> np.ndarray:
    """Return length-n codeword as ±1 float array (vendor convention)."""
    generator_matrix, one_time_pad, test_bits, g, noise_rate = encoding_key
    n, k = generator_matrix.shape
    if message is None:
        payload = np.concatenate((test_bits, GF.Random(k - len(test_bits))))
    else:
        payload = np.concatenate(
            (test_bits, GF.Random(g), GF(message), GF.Zeros(k - len(test_bits) - g - len(message)))
        )
    error = GF(np.random.binomial(1, noise_rate, n))
    bits = np.array(payload @ generator_matrix.T + one_time_pad + error, dtype=np.uint8)
    return 1.0 - 2.0 * bits.astype(np.float64)


def codeword_bits01(pm1: np.ndarray) -> np.ndarray:
    return (pm1 < 0).astype(np.uint8)


def _csr_row_products(parity_check_matrix, post: np.ndarray) -> np.ndarray:
    """Product of ``post[cols]`` on each CSR row (empty row → 0)."""
    indptr = parity_check_matrix.indptr
    indices = parity_check_matrix.indices
    r = parity_check_matrix.shape[0]
    lengths = np.diff(indptr)
    out = np.zeros(r, dtype=np.float64)
    if indices.size == 0:
        return out
    # log-sum-exp style product; clip away nonpositive for log
    vals = np.asarray(post, dtype=np.float64)[indices]
    safe = np.clip(np.abs(vals), 1e-300, None)
    row_id = np.repeat(np.arange(r), lengths)
    log_sum = np.bincount(row_id, weights=np.log(safe), minlength=r)
    neg_count = np.bincount(row_id, weights=(vals < 0).astype(np.float64), minlength=r)
    sign_prod = np.where(np.round(neg_count).astype(np.int64) % 2 == 0, 1.0, -1.0)
    out = sign_prod * np.exp(log_sum)
    out[lengths == 0] = 0.0
    return out


def _whitened_post(decoding_key, posteriors: np.ndarray) -> np.ndarray:
    (
        _generator_matrix,
        _parity_check_matrix,
        one_time_pad,
        _false_positive_rate_key,
        noise_rate,
        _test_bits,
        _g,
        _max_bp_iter,
        _t,
    ) = decoding_key
    post = np.asarray(posteriors, dtype=float).reshape(-1)
    return (1 - 2 * noise_rate) * (1 - 2 * np.array(one_time_pad, dtype=float)) * post


def detect_stat(decoding_key, posteriors: np.ndarray) -> float:
    """Vendor log-plus sum statistic (higher ⇒ more watermark-like)."""
    (
        _generator_matrix,
        parity_check_matrix,
        _one_time_pad,
        _false_positive_rate_key,
        _noise_rate,
        _test_bits,
        _g,
        _max_bp_iter,
        _t,
    ) = decoding_key
    post = _whitened_post(decoding_key, posteriors)
    Pi = _csr_row_products(parity_check_matrix, post)
    log_plus = np.log((1 + Pi) / 2 + 1e-300)
    return float(log_plus.sum())


def Detect(decoding_key, posteriors: np.ndarray, false_positive_rate=None, threshold: Optional[float] = None) -> bool:
    (
        _generator_matrix,
        parity_check_matrix,
        _one_time_pad,
        false_positive_rate_key,
        _noise_rate,
        _test_bits,
        _g,
        _max_bp_iter,
        _t,
    ) = decoding_key
    fpr = false_positive_rate if false_positive_rate is not None else false_positive_rate_key
    post = _whitened_post(decoding_key, posteriors)
    Pi = _csr_row_products(parity_check_matrix, post)
    log_plus = np.log((1 + Pi) / 2 + 1e-300)
    log_minus = np.log((1 - Pi) / 2 + 1e-300)
    log_prod = log_plus + log_minus
    stat = float(log_plus.sum())
    if threshold is not None:
        return stat >= threshold
    const = 0.5 * np.sum(np.power(log_plus, 2) + np.power(log_minus, 2) - 0.5 * np.power(log_prod, 2))
    thr = np.sqrt(max(2 * const * np.log(1 / max(fpr, 1e-300)), 0.0)) + 0.5 * log_prod.sum()
    return bool(stat >= thr)


def soft_from_bits(bits01: np.ndarray, reliability: float = 0.9) -> np.ndarray:
    pm1 = 1.0 - 2.0 * bits01.astype(np.float64)
    return pm1 * reliability


def soft_from_sector_scores(soft_scores: np.ndarray, scale: float = 3.0) -> np.ndarray:
    return np.tanh(scale * soft_scores.astype(np.float64).reshape(-1))


@dataclass
class PRCWatermarkKey:
    encoding_key: Any
    decoding_key: Any
    n: int
    fpr: float


def keygen(n: int, fpr: float = 1e-2, t: int = 3, message_length: int = 16) -> PRCWatermarkKey:
    enc, dec = KeyGen(n, message_length=message_length, false_positive_rate=fpr, t=t)
    return PRCWatermarkKey(encoding_key=enc, decoding_key=dec, n=n, fpr=fpr)


def encode_bits(key: PRCWatermarkKey) -> np.ndarray:
    return codeword_bits01(Encode(key.encoding_key))


def detect_from_bits(
    key: PRCWatermarkKey,
    bits01: np.ndarray,
    reliability: float = 0.85,
    threshold: Optional[float] = None,
) -> bool:
    return Detect(
        key.decoding_key,
        soft_from_bits(bits01, reliability),
        false_positive_rate=key.fpr,
        threshold=threshold,
    )


def detect_from_soft(
    key: PRCWatermarkKey,
    soft_scores: np.ndarray,
    threshold: Optional[float] = None,
) -> bool:
    return Detect(
        key.decoding_key,
        soft_from_sector_scores(soft_scores),
        false_positive_rate=key.fpr,
        threshold=threshold,
    )


def score_from_bits(key: PRCWatermarkKey, bits01: np.ndarray, reliability: float = 0.85) -> float:
    return detect_stat(key.decoding_key, soft_from_bits(bits01, reliability))


def calibrate_threshold(scores_unmarked: np.ndarray, target_fpr: float) -> float:
    """Empirical threshold: fraction of unmarked scores >= thr equals target_fpr."""
    s = np.sort(np.asarray(scores_unmarked, dtype=float))[::-1]
    if len(s) == 0:
        return 0.0
    idx = min(len(s) - 1, max(0, int(np.floor(target_fpr * len(s)))))
    # thr such that about target_fpr pass: use quantile
    return float(np.quantile(scores_unmarked, 1.0 - target_fpr))
