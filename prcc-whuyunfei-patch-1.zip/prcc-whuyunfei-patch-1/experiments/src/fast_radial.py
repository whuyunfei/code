"""Vectorized radial-coefficient extract and push-to-margin embed.

Same pixels as ``spatial_multiring`` sector masks. Used for the large-image
sweeps. The operation pushes each coefficient to ±gamma; it is not lattice QIM.
"""

from __future__ import annotations

from functools import lru_cache

import numpy as np

from .spatial_multiring import MultiRingLayout, _polar_grids, default_annuli


@lru_cache(maxsize=8)
def _cached_polar(size: int):
    rad, ang, _y, _x = _polar_grids(size)
    return rad, ang


@lru_cache(maxsize=32)
def _cached_polar_at(size: int, cy: float, cx: float):
    yy, xx = np.mgrid[0:size, 0:size]
    y = yy.astype(np.float64) - cy
    x = xx.astype(np.float64) - cx
    rad = np.sqrt(x * x + y * y)
    ang = (np.arctan2(y, x) + 2.0 * np.pi) % (2.0 * np.pi)
    return rad, ang


def _gray01(image: np.ndarray) -> tuple[np.ndarray, float, np.ndarray]:
    img = image.astype(np.float64)
    gray = img.mean(axis=2) if img.ndim == 3 else img
    scale = 255.0 if float(gray.max()) > 1.5 else 1.0
    return gray / scale, scale, img


def _sector_index(ang: np.ndarray, m: int, offset_deg: float, guard: float):
    shifted = (ang + np.deg2rad(offset_deg)) % (2.0 * np.pi)
    pos = shifted / (2.0 * np.pi / m)
    sector = np.floor(pos).astype(np.int32) % m
    frac = pos - np.floor(pos)
    half = 0.5 * guard
    usable = (frac >= half) & (frac < 1.0 - half)
    return sector, usable


def radial_soft(
    image: np.ndarray,
    layout: MultiRingLayout,
    angle_offset_deg: float = 0.0,
    center: tuple[float, float] | None = None,
) -> np.ndarray:
    g, _scale, _img = _gray01(image)
    if center is None:
        rad, ang = _cached_polar(layout.size)
    else:
        rad, ang = _cached_polar_at(layout.size, float(center[0]), float(center[1]))
    sector, usable = _sector_index(ang, layout.m, angle_offset_deg, layout.guard_frac)
    soft = np.zeros((layout.b, layout.m), dtype=np.float64)
    flat = g.ravel()
    sec = sector.ravel()
    for j, (r0, r1) in enumerate(layout.annuli):
        mid = 0.5 * (r0 + r1)
        inner = (usable & (rad >= r0) & (rad < mid)).ravel()
        outer = (usable & (rad >= mid) & (rad <= r1)).ravel()
        si, so = sec[inner], sec[outer]
        ci = np.bincount(si, minlength=layout.m).astype(np.float64)
        co = np.bincount(so, minlength=layout.m).astype(np.float64)
        sum_i = np.bincount(si, weights=flat[inner], minlength=layout.m)
        sum_o = np.bincount(so, weights=flat[outer], minlength=layout.m)
        with np.errstate(divide="ignore", invalid="ignore"):
            mean_i = np.divide(sum_i, ci, out=np.zeros(layout.m), where=ci > 0)
            mean_o = np.divide(sum_o, co, out=np.zeros(layout.m), where=co > 0)
        both = (ci > 0) & (co > 0)
        soft[j] = np.where(both, mean_o - mean_i, 0.0)
    return soft


def sector_pixel_counts(layout: MultiRingLayout) -> np.ndarray:
    """Inner+outer usable pixels per (ring, sector) on a blank grid."""
    rad, ang = _cached_polar(layout.size)
    sector, usable = _sector_index(ang, layout.m, 0.0, layout.guard_frac)
    sec = sector.ravel()
    counts = np.zeros((layout.b, layout.m), dtype=np.int32)
    for j, (r0, r1) in enumerate(layout.annuli):
        mid = 0.5 * (r0 + r1)
        inner = (usable & (rad >= r0) & (rad < mid)).ravel()
        outer = (usable & (rad >= mid) & (rad <= r1)).ravel()
        counts[j] = np.bincount(sec[inner], minlength=layout.m) + np.bincount(sec[outer], minlength=layout.m)
    return counts


def _apply_deltas(g: np.ndarray, layout: MultiRingLayout, delta: np.ndarray) -> np.ndarray:
    """Add the minimum-MSE radial push. ``delta[j,t]`` increases outer-inner."""
    rad, ang = _cached_polar(layout.size)
    sector, usable = _sector_index(ang, layout.m, 0.0, layout.guard_frac)
    out = g.copy()
    sec = sector
    for j, (r0, r1) in enumerate(layout.annuli):
        mid = 0.5 * (r0 + r1)
        inner = usable & (rad >= r0) & (rad < mid)
        outer = usable & (rad >= mid) & (rad <= r1)
        ci = np.bincount(sec[inner].ravel(), minlength=layout.m).astype(np.float64)
        co = np.bincount(sec[outer].ravel(), minlength=layout.m).astype(np.float64)
        denom = ci + co
        dj = delta[j]
        di = np.zeros(layout.m)
        do = np.zeros(layout.m)
        ok = denom > 0
        di[ok] = -co[ok] / denom[ok] * dj[ok]
        do[ok] = ci[ok] / denom[ok] * dj[ok]
        out[inner] += di[sec[inner]]
        out[outer] += do[sec[outer]]
    return out


def push_to_margin(image: np.ndarray, layout: MultiRingLayout, bits: np.ndarray) -> np.ndarray:
    """Push each radial coefficient to ±layout.strength (the frozen embed)."""
    g, scale, img = _gray01(image)
    coeff = radial_soft(image, layout, 0.0)
    bits = np.asarray(bits, dtype=np.uint8).reshape(layout.b, layout.m)
    sign = np.where(bits == 1, 1.0, -1.0)
    target = sign * layout.strength
    # Already on the correct side of the margin: leave it.
    need = np.where(sign > 0.0, coeff < target, coeff > target)
    delta = np.where(need, target - coeff, 0.0)
    out = np.clip(_apply_deltas(g, layout, delta), 0.0, 1.0)
    if image.ndim == 3:
        res = np.clip(img / scale + (out - g)[:, :, None], 0.0, 1.0)
        return res * scale
    return out * scale


def make_layout(size: int, m: int, b: int, guard: float, strength: float) -> MultiRingLayout:
    return MultiRingLayout(size, default_annuli(size, b), m, guard, strength, mode="qim")
