"""Integer syndrome thresholds and Clopper-Pearson intervals.

A threshold t accepts when the search minimum is <= t. Ties at the same integer
are kept or dropped together. The most permissive feasible t is the largest
integer whose empirical FPR is still within the budget. If none exists, the
configuration has no operating point.
"""

from __future__ import annotations

from typing import Optional, Sequence, Tuple

import numpy as np
from scipy.stats import beta


def largest_integer_threshold(scores: Sequence[float], alpha: float) -> Optional[int]:
    """Largest integer t >= 0 with mean(score <= t) <= alpha.

    Non-finite scores (every candidate rejected) do not pass. Returns None when
    even t = 0 exceeds the budget.
    """
    s = np.asarray(scores, dtype=np.float64)
    if len(s) == 0:
        return None
    finite = s[np.isfinite(s)]
    if len(finite) == 0:
        return None
    best: Optional[int] = None
    for t in range(0, int(np.max(finite)) + 1):
        fpr = float(np.mean(s <= t))
        if fpr <= alpha + 1e-15:
            best = t
        else:
            break
    return best


def most_permissive_upper(scores: Sequence[float], alpha: float) -> Optional[float]:
    """Smallest t with mean(score >= t) <= alpha, keeping tied values together.

    Used for PRC, where a larger score is more watermark-like. Returns None when
    the only rule that meets the budget accepts nothing.
    """
    s = np.sort(np.asarray(scores, dtype=np.float64))
    n = len(s)
    if n == 0:
        return None
    allow = int(np.floor(alpha * n + 1e-12))
    if allow <= 0:
        return None
    desc = s[::-1]
    if allow >= n:
        return float(desc[-1])
    boundary = float(desc[allow - 1])
    if float(desc[allow]) == boundary:
        higher = desc[:allow]
        if np.all(higher == boundary):
            return None
        return float(np.nextafter(boundary, np.inf))
    return boundary


def discrete_roc(pos: Sequence[float], neg: Sequence[float], tmax: int) -> list[dict]:
    p = np.asarray(pos, dtype=np.float64)
    n = np.asarray(neg, dtype=np.float64)
    rows = []
    for t in range(0, tmax + 1):
        rows.append(
            {
                "t": t,
                "tpr": float(np.mean(p <= t)) if len(p) else float("nan"),
                "fpr": float(np.mean(n <= t)) if len(n) else float("nan"),
                "n_pos": int(len(p)),
                "n_neg": int(len(n)),
            }
        )
    return rows


def clopper_pearson(k: int, n: int, alpha: float = 0.05) -> Tuple[float, float]:
    """Exact two-sided binomial interval. Zero events => lower 0, upper ~3/n."""
    if n <= 0:
        return float("nan"), float("nan")
    if k < 0 or k > n:
        raise ValueError("k out of range")
    lo = 0.0 if k == 0 else float(beta.ppf(alpha / 2, k, n - k + 1))
    hi = 1.0 if k == n else float(beta.ppf(1.0 - alpha / 2, k + 1, n - k))
    return lo, hi


def clopper_upper(k: int, n: int, alpha: float = 0.05) -> float:
    """One-sided 1-alpha upper bound. For k=0 this is 1 - alpha**(1/n) ≈ 3/n."""
    if n <= 0:
        return float("nan")
    if k == n:
        return 1.0
    return float(beta.ppf(1.0 - alpha, k + 1, n - k))


def hist_counts(scores: Sequence[float], tmax: int) -> dict:
    s = np.asarray(list(scores), dtype=np.float64)
    out = {}
    finite = s[np.isfinite(s)]
    for t in range(0, tmax + 1):
        out[str(t)] = int(np.sum(finite == t))
    out["gt"] = int(np.sum(finite > tmax))
    out["rejected_all"] = int(np.sum(~np.isfinite(s)))
    out["n"] = int(len(s))
    return out
