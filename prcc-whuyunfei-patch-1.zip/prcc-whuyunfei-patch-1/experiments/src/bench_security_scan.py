"""Phase 1: coarse security parameter scan for block-circulant PRCC."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import List

import numpy as np

from .security_probes import SweepCellResult, evaluate_cell, weight_ladder_for_gap


def cell_to_row(c: SweepCellResult) -> dict:
    return {
        "m": c.m,
        "b": c.b,
        "w": c.w,
        "eta": c.eta,
        "W": c.W,
        "tau": c.tau,
        "keygen_ok": int(c.keygen_ok),
        "encode_coset_ok": int(c.encode_coset_ok),
        "odd_block_ones_accept": c.odd_block_ones_accept,
        "fixed_all_zero": c.fixed_accept.get("all_zero", 0.0),
        "fixed_block_last_ones": c.fixed_accept.get(f"block{c.b-1}_ones", 0.0),
        "single_max_adv": c.single_adv.get("max_adv", 0.0),
        "multi_gap_vs_uniform": c.multi.get("gap_vs_uniform", 0.0),
        "const_reject_fnr": c.const_reject_fnr,
        "bsc_p0": c.bsc_detection.get("0.0", 0.0),
        "bsc_p002": c.bsc_detection.get("0.02", 0.0),
        "bsc_p005": c.bsc_detection.get("0.05", 0.0),
        "excluded": int(c.excluded),
        "exclude_reason": c.exclude_reason,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--keys", type=int, default=2)
    ap.add_argument("--quick", action="store_true", help="smaller grid for CI/smoke")
    ap.add_argument("--out", type=str, default="../figures/security_scan.csv")
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    if args.quick:
        ms = [32, 64]
        bs = [2, 4]
        etas = [0.0, 0.03, 0.10]
    else:
        ms = [32, 64, 128, 256]
        bs = [2, 4, 8]
        etas = [0.0, 0.01, 0.03, 0.05, 0.10]

    results: List[SweepCellResult] = []
    # Always include weak-structure control
    forced = [(32, 2, 1, 0.03), (32, 2, 1, 0.10), (64, 2, 1, 0.05)]

    seen = set()
    jobs = []
    for m, b, w, eta in forced:
        jobs.append((m, b, w, eta))
        seen.add((m, b, w, eta))
    for m in ms:
        for b in bs:
            for eta in etas:
                for _lab, w in weight_ladder_for_gap(m, b, max(eta, 0.01)):
                    key = (m, b, w, eta)
                    if key not in seen:
                        seen.add(key)
                        jobs.append(key)

    print(f"scanning {len(jobs)} cells (keys/cell={args.keys})")
    for i, (m, b, w, eta) in enumerate(jobs):
        do_multi = not (m >= 256 and b >= 8)
        # skip multi for very large unless not excluded by single later — evaluate_cell handles
        cell = evaluate_cell(m, b, w, eta, rng, n_keys=args.keys, do_multi=do_multi)
        results.append(cell)
        flag = "EXCL" if cell.excluded else "keep"
        print(
            f"[{i+1}/{len(jobs)}] m={m} b={b} w={w} eta={eta:.2f} "
            f"adv={cell.single_adv.get('max_adv',0):.2f} "
            f"odd1_acc={cell.odd_block_ones_accept:.0f} "
            f"fnr_const={cell.const_reject_fnr:.2f} {flag} {cell.exclude_reason}"
        )

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    rows = [cell_to_row(c) for c in results]
    with out.open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wri.writeheader()
        wri.writerows(rows)

    kept = [c for c in results if not c.excluded and c.keygen_ok]
    summary = {
        "n_cells": len(results),
        "n_kept": len(kept),
        "n_excluded": sum(1 for c in results if c.excluded),
        "odd_block_ones_always": all(c.odd_block_ones_accept >= 0.99 for c in results if c.keygen_ok),
        "const_reject_fnr_max_among_kept": max((c.const_reject_fnr for c in kept), default=1.0),
        "kept_params": [
            {"m": c.m, "b": c.b, "w": c.w, "eta": c.eta, "tau": c.tau, "W": c.W} for c in kept
        ],
        "csv": str(out),
    }
    sum_path = out.with_suffix(".json")
    sum_path.write_text(json.dumps(summary, indent=2))
    print(f"wrote {out}")
    print(f"wrote {sum_path}")
    print(f"kept {summary['n_kept']}/{summary['n_cells']} cells")
    if summary["n_kept"] == 0:
        print("EXIT: all cells excluded — stop before geometry stages.")
    else:
        print("CONTINUE: retained parameter cells exist; see phase-1 note for soundness goal.")


if __name__ == "__main__":
    main()
