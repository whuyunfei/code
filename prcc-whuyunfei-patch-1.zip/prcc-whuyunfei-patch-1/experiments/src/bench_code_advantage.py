"""PRCC residual search vs PRC extract-once-then-shift, same embedding and grid.

Runs only when embed_compare.json names a winner. Thresholds are fit on the
calibration split (unmarked, full search). Test-split attacked unmarked images
supply the FPR.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from . import block_circulant as bc
from .bench_fair_compare import extraction_shift_sign, prc_reuse_search
from .kodak_photos import load_split
from .prc_watermark_adapter import KeyGen, PRCWatermarkKey, available as prc_available, score_from_bits
from .residual_search import passes_lower, search_deltas, shared_grids
from .spatial_multiring import (
    MultiRingLayout,
    apply_attack,
    default_annuli,
    embed_weak,
    psnr,
)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--embed-json", type=str, default="../figures/embed_compare.json")
    ap.add_argument("--size", type=int, default=256)
    ap.add_argument("--m", type=int, default=8)
    ap.add_argument("--b", type=int, default=4)
    ap.add_argument("--L", type=int, default=4)
    ap.add_argument("--guard", type=float, default=0.15)
    ap.add_argument("--eta", type=float, default=0.03)
    ap.add_argument("--w", type=int, default=1)
    ap.add_argument("--angle", type=float, default=22.5)
    ap.add_argument("--target-fpr", type=float, default=0.05)
    ap.add_argument("--seed", type=int, default=3)
    ap.add_argument("--out", type=str, default="../figures/code_advantage.json")
    args = ap.parse_args()

    embed_path = Path(args.embed_json)
    if not embed_path.is_absolute():
        embed_path = Path(__file__).resolve().parents[1] / args.embed_json
    summary_in = json.loads(embed_path.read_text())
    winner = summary_in.get("winner")
    out = Path(args.out)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    if not winner:
        payload = {
            "skipped": True,
            "reason": "channel did not beat mean-shift under the fixed rule; no detection-advantage claim",
        }
        out.write_text(json.dumps(payload, indent=2))
        print(json.dumps(payload))
        return
    if not prc_available():
        raise SystemExit("galois required")

    strength = float(summary_in["chosen"][winner]["strength"])
    rng = np.random.default_rng(args.seed)
    calib = load_split("calib", args.size)
    test = load_split("test", args.size)
    layout = MultiRingLayout(
        args.size, default_annuli(args.size, args.b), args.m, args.guard, strength, mode=winner
    )
    sign = extraction_shift_sign(test[0], layout)
    if sign == 0:
        raise SystemExit("shift does not match re-extraction for the winning embed")

    tau = bc.suggest_tau(args.m, args.b * args.w, args.eta, 0.20)
    block_key = bc.keygen(args.m, args.b, args.w, tau, args.eta, rng)
    n = args.m * args.b
    enc, dec = KeyGen(
        n,
        message_length=max(4, n // 8),
        false_positive_rate=args.target_fpr,
        t=3,
        noise_rate=0.05,
        g=8,
        r=max(8, n // 3),
    )
    prc_key = PRCWatermarkKey(encoding_key=enc, decoding_key=dec, n=n, fpr=args.target_fpr)
    deltas, _angles = shared_grids(args.m, args.L)

    block_neg = []
    prc_neg = []
    for img in calib:
        r = search_deltas(block_key, img, layout, deltas, constant_reject=True)
        block_neg.append(r.best_score)
        sc, _e, _c = prc_reuse_search(prc_key, img, layout, args.L, sign)
        prc_neg.append(sc)
    thr_block = float(np.quantile(block_neg, args.target_fpr))
    thr_prc = float(np.quantile(prc_neg, 1.0 - args.target_fpr))

    attacks = ("none", "rot", "jpeg", "rot_jpeg")
    rows = []
    time_rows = []
    for attack in attacks:
        hb = hp = fb = fp = 0
        psnrs = []
        for img in test:
            c = bc.encode(block_key, rng=rng).reshape(args.b, args.m)
            marked = embed_weak(img, layout, c)
            psnrs.append(psnr(img, marked))
            attacked = apply_attack(marked, attack, args.angle, 70, args.size)
            r = search_deltas(block_key, attacked, layout, deltas, constant_reject=True)
            hb += int(passes_lower(r, thr_block))
            from .prc_watermark_adapter import encode_bits

            bits = encode_bits(prc_key).reshape(args.b, args.m)
            marked_p = embed_weak(img, layout, bits)
            attacked_p = apply_attack(marked_p, attack, args.angle, 70, args.size)
            sc, ext_ms, code_ms = prc_reuse_search(prc_key, attacked_p, layout, args.L, sign)
            hp += int(sc >= thr_prc)
            time_rows.append({"who": "prc", "extract_ms": ext_ms, "code_ms": code_ms, "attack": attack})

            plain = apply_attack(img, attack, args.angle, 70, args.size)
            r0 = search_deltas(block_key, plain, layout, deltas, constant_reject=True)
            fb += int(passes_lower(r0, thr_block))
            sc0, _e0, _c0 = prc_reuse_search(prc_key, plain, layout, args.L, sign)
            fp += int(sc0 >= thr_prc)
        n_test = len(test)
        row = {
            "attack": attack,
            "tpr_prcc": hb / n_test,
            "tpr_prc": hp / n_test,
            "fpr_prcc": fb / n_test,
            "fpr_prc": fp / n_test,
            "psnr_mean": float(np.mean(psnrs)),
            "n": n_test,
        }
        rows.append(row)
        print(
            f"{attack:8} PRCC={row['tpr_prcc']:.2f} PRC={row['tpr_prc']:.2f} "
            f"FPR {row['fpr_prcc']:.2f}/{row['fpr_prc']:.2f}"
        )

    # One clean timing pass on test images for the split, PRCC side.
    prcc_ext = []
    prcc_code = []
    from time import perf_counter

    from .residual_search import hard_score
    from .spatial_multiring import extract_bits

    for img in test:
        te = tc = 0.0
        for d in deltas:
            t0 = perf_counter()
            y = extract_bits(img, layout, angle_offset_deg=float(d)).reshape(-1)
            te += perf_counter() - t0
            t1 = perf_counter()
            hard_score(block_key, y)
            tc += perf_counter() - t1
        prcc_ext.append(1e3 * te)
        prcc_code.append(1e3 * tc)

    prc_times = [t for t in time_rows if t["attack"] == "none"]
    payload = {
        "skipped": False,
        "mode": winner,
        "strength": strength,
        "shift_sign": sign,
        "thr_block": thr_block,
        "thr_prc": thr_prc,
        "rows": rows,
        "median_prcc_extract_ms": float(np.median(prcc_ext)),
        "median_prcc_code_ms": float(np.median(prcc_code)),
        "median_prc_extract_ms": float(np.median([t["extract_ms"] for t in prc_times])) if prc_times else None,
        "median_prc_code_ms": float(np.median([t["code_ms"] for t in prc_times])) if prc_times else None,
        "code_evals_prcc": args.L,
        "code_evals_prc": args.m * args.L,
        "m8_w1_is_demo": True,
        "not_1e-3": "n=8 cannot support an FPR of 1e-3",
    }
    # silence unused if encode path imported score
    _ = score_from_bits
    out.write_text(json.dumps(payload, indent=2))
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
