"""Round 2: independent confirm on fresh train2017 images, 5 keys."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from .baseline_c_common import (
    BASELINE_KEY_SEEDS,
    EXTRA_KEY_SEEDS,
    SIZE,
    calibrate_and_eval,
    make_key,
    make_layout_c,
)
from .coco_confirm import confirm_split_paths, write_confirm_manifest


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--step", type=float, required=True)
    ap.add_argument("--seed", type=int, default=20)
    ap.add_argument("--n-delta", type=int, default=80)
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()

    write_confirm_manifest(seed=0)
    rng = np.random.default_rng(args.seed)
    calib = confirm_split_paths("calib")
    tune = confirm_split_paths("tune")
    neg = confirm_split_paths("test_neg")
    pos = confirm_split_paths("test_pos")
    delta = confirm_split_paths("test_pos")[: args.n_delta]

    angles_calib = rng.uniform(0, 360, len(calib))
    angles_tune = rng.uniform(0, 360, len(tune))
    angles_neg = rng.uniform(0, 360, len(neg))
    angles_pos = rng.uniform(0, 360, len(pos))
    encode_tune = rng.integers(0, 2**31 - 1, len(tune))
    encode_pos = rng.integers(0, 2**31 - 1, len(pos))
    encode_delta = rng.integers(0, 2**31 - 1, len(delta))

    key_seeds = list(BASELINE_KEY_SEEDS) + list(EXTRA_KEY_SEEDS)
    layout = make_layout_c()
    rows = []
    for kid, ks in enumerate(key_seeds):
        print(f"\n######## confirm key {kid} seed={ks} step={args.step} ########", flush=True)
        key = make_key(np.random.default_rng(ks))
        row = calibrate_and_eval(
            key,
            layout,
            args.step,
            calib,
            tune,
            neg,
            pos,
            delta,
            angles_calib,
            angles_tune,
            angles_neg,
            angles_pos,
            encode_tune,
            encode_pos,
            encode_delta,
            n_delta=args.n_delta,
        )
        row["key_id"] = kid
        row["key_seed"] = ks
        rows.append(row)
        print(
            f"key={kid} thr={row.get('threshold')} pass={row.get('passed')} "
            f"TPR={row.get('tpr_random', {}).get('tpr')} "
            f"FPRu={row.get('fpr_none', {}).get('cp_upper')} "
            f"mid={row.get('curve_summary', {}).get('mid_min')}",
            flush=True,
        )

    n_pass = sum(1 for r in rows if r.get("passed"))
    decision = (
        f"{n_pass}/{len(rows)} keys pass on fresh confirm images at step={args.step}."
        if n_pass == len(rows)
        else f"{n_pass}/{len(rows)} keys pass on confirm set; see per-key failures."
    )
    out = {
        "step": args.step,
        "n_keys": len(rows),
        "n_passed": n_pass,
        "per_key": rows,
        "decision": decision,
        "image_source": "COCO train2017 confirm_splits.json",
    }
    out_path = (
        Path(args.out)
        if args.out
        else Path(__file__).resolve().parents[2] / "figures" / "confirm_holdout.json"
    )
    if args.out and not out_path.is_absolute():
        out_path = Path(__file__).resolve().parents[1] / args.out
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2))
    print(decision, flush=True)
    print(f"wrote {out_path}", flush=True)


if __name__ == "__main__":
    main()
