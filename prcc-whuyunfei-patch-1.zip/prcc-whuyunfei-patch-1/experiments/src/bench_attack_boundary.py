"""Round 4: JPEG quality and extra center-offset sweeps on frozen C step."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from .baseline_c_common import (
    BASELINE_KEY_SEEDS,
    SIZE,
    calibrate_and_eval,
    make_key,
    make_layout_c,
)
from .coco_photos import split_paths


JPEG_QS = [90, 80, 70, 60, 50]
OFFSETS = [0.0, 0.25, -0.25, 0.5, -0.5, 1.0, -1.0]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--step", type=float, required=True)
    ap.add_argument("--seed", type=int, default=40)
    ap.add_argument("--n-delta", type=int, default=40)
    ap.add_argument("--n-neg", type=int, default=1500)
    ap.add_argument("--n-pos", type=int, default=300)
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    key = make_key(np.random.default_rng(BASELINE_KEY_SEEDS[0]))
    layout = make_layout_c()
    calib = split_paths("calib")
    tune = split_paths("tune")
    neg = split_paths("test_neg")[: args.n_neg]
    pos = split_paths("test_pos")[: args.n_pos]
    delta = split_paths("test_pos")[: args.n_delta]

    def pack_angles(n):
        return rng.uniform(0, 360, n)

    angles_calib = pack_angles(len(calib))
    angles_tune = pack_angles(len(tune))
    angles_neg = pack_angles(len(neg))
    angles_pos = pack_angles(len(pos))
    encode_tune = rng.integers(0, 2**31 - 1, len(tune))
    encode_pos = rng.integers(0, 2**31 - 1, len(pos))
    encode_delta = rng.integers(0, 2**31 - 1, len(delta))

    jpeg_rows = []
    for q in JPEG_QS:
        print(f"\n=== JPEG Q={q} ===", flush=True)
        row = calibrate_and_eval(
            key,
            layout,
            args.step,
            calib,
            tune,
            neg,
            pos,
            delta,
            angles_calib,
            angles_tune,
            angles_neg,
            angles_pos,
            encode_tune,
            encode_pos,
            encode_delta,
            jpeg_q=q,
            n_delta=args.n_delta,
        )
        row["jpeg_q"] = q
        jpeg_rows.append(row)
        print(
            f"Q={q} thr={row.get('threshold')} pass={row.get('passed')} "
            f"TPR={row.get('tpr_random', {}).get('tpr')} "
            f"mid={row.get('curve_summary', {}).get('mid_min')}",
            flush=True,
        )

    offset_rows = []
    # axis-aligned: apply same magnitude on x then on y separately; also (dx,dy)=(o,o)
    for o in OFFSETS:
        for axis, shift in (("x", (o, 0.0)), ("y", (0.0, o)), ("xy", (o, o) if o != 0 else (0.0, 0.0))):
            if o == 0.0 and axis != "x":
                continue
            print(f"\n=== offset {axis}={o} ===", flush=True)
            row = calibrate_and_eval(
                key,
                layout,
                args.step,
                calib,
                tune,
                neg,
                pos,
                delta,
                angles_calib,
                angles_tune,
                angles_neg,
                angles_pos,
                encode_tune,
                encode_pos,
                encode_delta,
                jpeg_q=70,
                n_delta=args.n_delta,
                shift_xy=shift,
            )
            row["offset_axis"] = axis
            row["offset"] = o
            offset_rows.append(row)
            print(
                f"off {axis}={o} thr={row.get('threshold')} pass={row.get('passed')} "
                f"TPR={row.get('tpr_random', {}).get('tpr')}",
                flush=True,
            )

    jpeg_pass = [r["jpeg_q"] for r in jpeg_rows if r.get("passed")]
    jpeg_fail = [r["jpeg_q"] for r in jpeg_rows if not r.get("passed")]
    off_fail = [
        f"{r['offset_axis']}={r['offset']}"
        for r in offset_rows
        if not r.get("passed") and r.get("threshold") is not None
    ]
    decision = (
        f"JPEG pass Q∈{jpeg_pass}; fail Q∈{jpeg_fail}. "
        f"Offset failures: {off_fail if off_fail else 'none at tested grid'}."
    )
    out = {
        "step": args.step,
        "jpeg": jpeg_rows,
        "offsets": offset_rows,
        "decision": decision,
    }
    out_path = (
        Path(args.out)
        if args.out
        else Path(__file__).resolve().parents[2] / "figures" / "attack_boundary.json"
    )
    if args.out and not out_path.is_absolute():
        out_path = Path(__file__).resolve().parents[1] / args.out
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2))
    try:
        import matplotlib.pyplot as plt

        fig, axes = plt.subplots(1, 2, figsize=(9, 3.6))
        qs = [r["jpeg_q"] for r in jpeg_rows if r.get("tpr_random")]
        axes[0].plot(qs, [r["tpr_random"]["tpr"] for r in jpeg_rows if r.get("tpr_random")], "o-")
        axes[0].axhline(0.9, color="gray", ls=":")
        axes[0].set_xlabel("JPEG Q")
        axes[0].set_ylabel("TPR")
        axes[0].set_title("JPEG sweep")
        # offset: |o| on x for axis x
        xs = [abs(r["offset"]) for r in offset_rows if r["offset_axis"] == "x" and r.get("tpr_random")]
        ys = [r["tpr_random"]["tpr"] for r in offset_rows if r["offset_axis"] == "x" and r.get("tpr_random")]
        axes[1].plot(xs, ys, "o-", label="dx")
        ys2 = [r["tpr_random"]["tpr"] for r in offset_rows if r["offset_axis"] == "y" and r.get("tpr_random")]
        xs2 = [abs(r["offset"]) for r in offset_rows if r["offset_axis"] == "y" and r.get("tpr_random")]
        if xs2:
            axes[1].plot(xs2, ys2, "s--", label="dy")
        axes[1].axhline(0.9, color="gray", ls=":")
        axes[1].set_xlabel("|offset| (px)")
        axes[1].set_ylabel("TPR")
        axes[1].legend(fontsize=8)
        axes[1].set_title("Center offset sweep")
        fig.tight_layout()
        fig.savefig(out_path.with_suffix(".png"), dpi=140)
        plt.close(fig)
    except Exception:
        pass
    print(decision, flush=True)
    print(f"wrote {out_path}", flush=True)


if __name__ == "__main__":
    main()
