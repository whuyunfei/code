"""Legacy benchmark for retracted full-circulant construction.

Prefer ``bench_compare_codes`` / ``demo_block_circulant`` for the current candidate.
"""

from __future__ import annotations

import argparse

import numpy as np

from .circulant_code import bsc, cyclic_shift, detect, encode, keygen


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=256)
    ap.add_argument("--w", type=int, default=7)
    ap.add_argument("--tau", type=int, default=30)
    ap.add_argument("--eta", type=float, default=0.0)
    ap.add_argument("--trials", type=int, default=50)
    ap.add_argument("--seed", type=int, default=1)
    # legacy alias ignored
    ap.add_argument("--r", type=int, default=0, help="ignored (full circulant)")
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    key = keygen(args.n, args.w, args.tau, args.eta, rng)

    ps = [0.0, 0.01, 0.02, 0.05, 0.08]
    print(f"params n={args.n} w={args.w} tau={args.tau} eta={args.eta} trials={args.trials}")
    for p in ps:
        ok = 0
        fpr = 0
        for _ in range(args.trials):
            c = encode(key, rng=rng)
            k = int(rng.integers(0, args.n))
            c2 = bsc(cyclic_shift(c, k), p, rng)
            ok += int(detect(key, c2))
            u = rng.integers(0, 2, size=args.n, dtype=np.uint8)
            fpr += int(detect(key, u))
        print(f"p={p:.3f}  detection={ok/args.trials:.3f}  FPR_uniform={fpr/args.trials:.3f}")


if __name__ == "__main__":
    main()
