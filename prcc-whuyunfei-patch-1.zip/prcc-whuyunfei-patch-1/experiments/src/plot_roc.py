"""Plot syndrome-weight histograms for the retracted full-circulant candidate.

Prefer block-circulant demos for the current construction.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from .circulant_code import encode, keygen, syndrome


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=str, default="../figures/roc_syndrome.png")
    ap.add_argument("--trials", type=int, default=100)
    args = ap.parse_args()

    rng = np.random.default_rng(42)
    key = keygen(n=128, w=5, tau=20, eta=0.0, rng=rng)
    honest = [int(syndrome(key.H, encode(key, rng=rng)).sum()) for _ in range(args.trials)]
    uni = [
        int(syndrome(key.H, rng.integers(0, 2, size=key.H.shape[1], dtype=np.uint8)).sum())
        for _ in range(args.trials)
    ]

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(6, 4))
    plt.hist(honest, bins=20, alpha=0.7, label="Encode")
    plt.hist(uni, bins=20, alpha=0.7, label="Uniform")
    plt.axvline(key.tau, color="k", linestyle="--", label=f"tau={key.tau}")
    plt.xlabel("syndrome weight")
    plt.ylabel("count")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out, dpi=150)
    print(f"wrote {out}")
    print(f"honest mean wt={np.mean(honest):.1f}  uniform mean wt={np.mean(uni):.1f}")


if __name__ == "__main__":
    main()
