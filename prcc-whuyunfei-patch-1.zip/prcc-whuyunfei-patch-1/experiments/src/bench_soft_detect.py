"""Hard syndrome vs calibrated soft parity vs erasure, on the winning embed.

Skipped when embed_compare.json has no winner. Thresholds come from the
calibration split; the test split is only scored.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from . import block_circulant as bc
from .kodak_photos import load_split
from .residual_search import shared_grids
from .soft_detect import (
    best_over_deltas,
    bit_probs,
    fit_logistic,
    passes,
    shift_invariant,
)
from .spatial_multiring import (
    MultiRingLayout,
    apply_attack,
    default_annuli,
    embed_weak,
    extract_soft,
    make_bits,
)


def views_at(image, layout, deltas, a, b, gamma: float):
    """Blind residual grid. The attack angle is not given to the detector."""
    raw = []
    erased = []
    for d in deltas:
        soft = extract_soft(image, layout, angle_offset_deg=float(d)).reshape(-1)
        p = bit_probs(soft, a, b)
        raw.append(p)
        pe = p.copy()
        pe[np.abs(soft) < gamma] = 0.5
        erased.append(pe)
    return raw, erased


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--embed-json", type=str, default="../figures/embed_compare.json")
    ap.add_argument("--size", type=int, default=256)
    ap.add_argument("--m", type=int, default=8)
    ap.add_argument("--b", type=int, default=4)
    ap.add_argument("--L", type=int, default=4)
    ap.add_argument("--guard", type=float, default=0.15)
    ap.add_argument("--eta", type=float, default=0.03)
    ap.add_argument("--w", type=int, default=1)
    ap.add_argument("--angle", type=float, default=22.5)
    ap.add_argument("--target-fpr", type=float, default=0.05)
    ap.add_argument("--seed", type=int, default=2)
    ap.add_argument("--out", type=str, default="../figures/soft_detect.json")
    args = ap.parse_args()

    embed_path = Path(args.embed_json)
    if not embed_path.is_absolute():
        embed_path = Path(__file__).resolve().parents[1] / args.embed_json
    summary_in = json.loads(embed_path.read_text())
    winner = summary_in.get("winner")
    out = Path(args.out)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    if not winner:
        payload = {
            "skipped": True,
            "reason": "no embed beat mean on jpeg and rot_jpeg; soft detection is not used to rescue a weak channel",
        }
        out.write_text(json.dumps(payload, indent=2))
        print(json.dumps(payload))
        return

    strength = float(summary_in["chosen"][winner]["strength"])
    sign = int(summary_in["offset_sign"])
    rng = np.random.default_rng(args.seed)
    calib = load_split("calib", args.size)
    test = load_split("test", args.size)
    layout = MultiRingLayout(
        args.size, default_annuli(args.size, args.b), args.m, args.guard, strength, mode=winner
    )
    tau = bc.suggest_tau(args.m, args.b * args.w, args.eta, 0.20)
    key = bc.keygen(args.m, args.b, args.w, tau, args.eta, rng)
    deltas, _ = shared_grids(args.m, args.L)

    softs = []
    bits = []
    rels = []
    for img in calib:
        bts = make_bits(layout, rng)
        marked = embed_weak(img, layout, bts)
        soft = extract_soft(marked, layout, 0.0).reshape(-1)
        p_true = None
        softs.append(soft)
        bits.append(bts.reshape(-1))
        rels.append(np.abs(soft))
        del p_true
    a, bcoef = fit_logistic(np.concatenate(softs), np.concatenate(bits))
    # |2p-1| saturates when the logistic is a step. Erase on |soft| instead,
    # using the calibration split's 20th percentile.
    gamma = float(np.quantile(np.abs(np.concatenate(softs)), 0.2))

    kinds = ("hard", "soft", "erasure")
    from .block_circulant import simultaneous_shift
    from .soft_detect import soft_parity_loglik

    def _erased(soft_vec: np.ndarray) -> np.ndarray:
        p = bit_probs(soft_vec, a, bcoef)
        p = p.copy()
        p[np.abs(soft_vec) < gamma] = 0.5
        return p

    base_ll = soft_parity_loglik(key, _erased(softs[0]))
    erasure_invariant = True
    for k in range(key.m):
        shifted = simultaneous_shift(softs[0], key.m, k)
        if abs(soft_parity_loglik(key, _erased(shifted)) - base_ll) > 1e-5:
            erasure_invariant = False
    inv = {
        "hard": shift_invariant(key, bit_probs(softs[0], a, bcoef), "hard"),
        "soft": shift_invariant(key, bit_probs(softs[0], a, bcoef), "soft"),
        "erasure": erasure_invariant,
    }

    thresholds = {}
    for kind in kinds:
        scores = []
        for img in calib:
            raw, erased = views_at(img, layout, deltas, a, bcoef, gamma)
            plist = erased if kind == "erasure" else raw
            stat = "soft" if kind == "erasure" else kind
            sc, _n = best_over_deltas(key, plist, stat, 0.0)
            scores.append(sc)
        if kind == "hard":
            thresholds[kind] = float(np.quantile(scores, args.target_fpr))
        else:
            thresholds[kind] = float(np.quantile(scores, 1.0 - args.target_fpr))

    attacks = ("none", "rot", "jpeg", "rot_jpeg")
    rows = []
    for kind in kinds:
        for attack in attacks:
            hit = false = 0
            for img in test:
                bts = bc.encode(key, rng=rng).reshape(args.b, args.m)
                marked = embed_weak(img, layout, bts)
                attacked = apply_attack(marked, attack, args.angle, 70, args.size)
                raw, erased = views_at(attacked, layout, deltas, a, bcoef, gamma)
                plist = erased if kind == "erasure" else raw
                stat = "soft" if kind == "erasure" else kind
                sc, n_valid = best_over_deltas(key, plist, stat, 0.0)
                hit += int(passes(sc, n_valid, thresholds[kind], kind))
                plain = apply_attack(img, attack, args.angle, 70, args.size)
                raw0, erased0 = views_at(plain, layout, deltas, a, bcoef, gamma)
                plist0 = erased0 if kind == "erasure" else raw0
                sc0, n0 = best_over_deltas(key, plist0, stat, 0.0)
                false += int(passes(sc0, n0, thresholds[kind], kind))
            n = len(test)
            row = {
                "kind": kind,
                "attack": attack,
                "tpr": hit / n,
                "fpr_attacked_unmarked": false / n,
                "hits": hit,
                "false": false,
                "n": n,
                "thr": thresholds[kind],
            }
            rows.append(row)
            print(f"{kind:8} {attack:8} TPR={row['tpr']:.2f} FPR={row['fpr_attacked_unmarked']:.2f}")

    payload = {
        "skipped": False,
        "mode": winner,
        "logistic_a": a,
        "logistic_b": bcoef,
        "erasure_gamma": gamma,
        "shift_invariant": inv,
        "rows": rows,
        "n_test": len(test),
        "not_1e-3": "n=8 cannot support an FPR of 1e-3",
    }
    out.write_text(json.dumps(payload, indent=2))
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
