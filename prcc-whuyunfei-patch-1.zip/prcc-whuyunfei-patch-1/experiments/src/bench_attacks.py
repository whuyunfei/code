"""Phase 5: rotation + JPEG / blur / noise / center offset on held-out images."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter, shift as nd_shift

from . import block_circulant as bc
from .residual_search import passes_lower, search_residual
from .spatial_multiring import (
    MultiRingLayout,
    center_crop_or_pad,
    default_annuli,
    embed_weak,
    jpeg_compress,
    load_images,
    psnr,
    rotate_pad,
)


def apply_blur(img: np.ndarray, sigma: float) -> np.ndarray:
    if img.ndim == 3:
        out = np.stack([gaussian_filter(img[:, :, c], sigma=sigma) for c in range(img.shape[2])], axis=2)
    else:
        out = gaussian_filter(img, sigma=sigma)
    return out


def apply_noise(img: np.ndarray, sigma: float, rng: np.random.Generator) -> np.ndarray:
    return np.clip(img.astype(np.float64) + rng.normal(0, sigma, size=img.shape), 0, 255)


def apply_center_offset_rotate(img: np.ndarray, angle: float, offset: float) -> np.ndarray:
    """Shift center then rotate (pad/crop)."""
    shifted = nd_shift(img, shift=(offset, offset, 0) if img.ndim == 3 else (offset, offset), order=1, mode="constant")
    return center_crop_or_pad(rotate_pad(shifted, angle), img.shape[0])


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--images", type=str, default="data/images")
    ap.add_argument("--size", type=int, default=256)
    ap.add_argument("--holdout-start", type=int, default=12, help="images[holdout_start:] for test")
    ap.add_argument("--m", type=int, default=8)
    ap.add_argument("--b", type=int, default=4)
    ap.add_argument("--L", type=int, default=4)
    ap.add_argument("--strength", type=float, default=0.05)
    ap.add_argument("--guard", type=float, default=0.15)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", type=str, default="../figures/attacks.csv")
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    img_dir = Path(__file__).resolve().parents[1] / args.images
    images = load_images(img_dir, args.size, limit=24)
    test_imgs = images[args.holdout_start :]
    if len(test_imgs) < 4:
        raise SystemExit("need more holdout images; run bootstrap_images")

    m, b, L = args.m, args.b, args.L
    layout = MultiRingLayout(
        args.size, default_annuli(args.size, b), m, args.guard, args.strength, mode="mean"
    )
    tau = bc.suggest_tau(m, b * 1, 0.03, 0.20)
    key = bc.keygen(m, b, 1, tau, 0.03, rng)

    # Calibrate on holdout unmarked
    neg_scores = []
    for img in test_imgs:
        r = search_residual(key, img, layout, L)
        neg_scores.append(r.best_score)
    thr = float(np.quantile(neg_scores, 0.05))

    attacks = [
        ("rot_only", lambda im, a, rng: center_crop_or_pad(rotate_pad(im, a), args.size)),
        ("rot_jpeg70", lambda im, a, rng: jpeg_compress(center_crop_or_pad(rotate_pad(im, a), args.size), 70, rng)),
        ("rot_blur", lambda im, a, rng: apply_blur(center_crop_or_pad(rotate_pad(im, a), args.size), 0.8)),
        ("rot_noise", lambda im, a, rng: apply_noise(center_crop_or_pad(rotate_pad(im, a), args.size), 8.0, rng)),
        ("rot_offset3", lambda im, a, rng: apply_center_offset_rotate(im, a, 3.0)),
    ]
    angles = [22.5, 45.0, 90.0]
    rows = []
    for name, fn in attacks:
        for a in angles:
            hits = 0
            psnrs = []
            for img in test_imgs:
                c = bc.encode(key, rng=rng)
                bits = c.reshape(b, m)
                marked = embed_weak(img, layout, bits)
                attacked = fn(marked, a, rng)
                if attacked.ndim == 2:
                    attacked = np.stack([attacked] * 3, axis=2)
                if attacked.shape[0] != args.size:
                    attacked = center_crop_or_pad(attacked, args.size)
                psnrs.append(psnr(img, attacked) if attacked.shape == img.shape else float("nan"))
                r = search_residual(key, attacked, layout, L)
                hits += int(passes_lower(r, thr))
            row = {
                "attack": name,
                "angle": a,
                "tpr": hits / len(test_imgs),
                "psnr_mean": float(np.nanmean(psnrs)),
                "n": len(test_imgs),
                "thr": thr,
            }
            rows.append(row)
            print(f"{name:12} ang={a:5.1f} TPR={row['tpr']:.2f} PSNR={row['psnr_mean']:.1f}")

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wri.writeheader()
        wri.writerows(rows)
    summary = {
        "csv": str(out),
        "holdout": len(test_imgs),
        "note": "scale/translation left as separate sync problem",
        "failure_modes": {
            "jpeg": "expect large drop vs rot_only",
            "offset": "ring geometry mismatch",
        },
    }
    out.with_suffix(".json").write_text(json.dumps(summary, indent=2))
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
