"""Round 3 (revised): PRCC vs PRC on the same lattice carrier + 2-center sync.

PRC threshold: lowest legal thr (most permissive) with both calib FPRs under budget.
Detect uses vectorized CSR row products. Multi-key paired images/angles.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np

from . import block_circulant as bc
from .baseline_c_common import (
    BASELINE_KEY_SEEDS,
    BLIND_CENTERS,
    EXTRA_KEY_SEEDS,
    FPR_CALIB_TARGET,
    FPR_TEST,
    L,
    M,
    SIZE,
    make_key,
    make_layout_c,
)
from .block_circulant import simultaneous_shift
from .coco_photos import load_image, split_paths
from .integer_threshold import clopper_pearson, clopper_upper, most_permissive_upper
from .lattice_carrier import embed_lattice, extract_lattice
from .residual_search import shared_grids
from .search_scores import score_bits
from .spatial_multiring import apply_attack, psnr

try:
    from . import prc_watermark_adapter as prc
except Exception:  # pragma: no cover
    prc = None


def pick_prc_threshold(scores_none, scores_att, alpha: float = FPR_CALIB_TARGET) -> dict:
    """Lowest legal thr (most permissive) with both FPRs strictly below alpha."""
    ta = most_permissive_upper(scores_none, alpha)
    tb = most_permissive_upper(scores_att, alpha)
    if ta is None or tb is None:
        return {"threshold": None, "t_none": ta, "t_att": tb}
    thr = float(max(ta, tb))
    # Enforce strict < alpha (margin): bump thr upward while FPR not strictly below
    sa = np.asarray(scores_none, dtype=float)
    sb = np.asarray(scores_att, dtype=float)

    def fpr(s, t):
        return float(np.mean(s >= t))

    # If sitting exactly on cap, raise thr past tied mass
    guard = 0
    while guard < 10000 and (fpr(sa, thr) >= alpha or fpr(sb, thr) >= alpha):
        thr = float(np.nextafter(thr, np.inf))
        guard += 1
    return {
        "threshold": thr,
        "t_none": ta,
        "t_att": tb,
        "fpr_none_calib": fpr(sa, thr),
        "fpr_att_calib": fpr(sb, thr),
    }


def prcc_search_timed(key, image, layout, step: float):
    deltas, _ = shared_grids(M, L)
    t_ext = t_code = 0.0
    n_ext = n_code = 0
    best = float("inf")
    for center in BLIND_CENTERS:
        for d in deltas:
            t0 = time.perf_counter()
            y, _ = extract_lattice(image, layout, float(d), step, center=center)
            t_ext += time.perf_counter() - t0
            n_ext += 1
            t1 = time.perf_counter()
            sc = score_bits(key, y.reshape(-1), True)
            t_code += time.perf_counter() - t1
            n_code += 1
            if sc is not None and sc < best:
                best = float(sc)
    return best, t_ext, t_code, n_ext, n_code


def prc_reuse_search_timed(prc_key, image, layout, step: float, sign: int = 1):
    deltas, _ = shared_grids(M, L)
    t_ext = t_code = 0.0
    n_ext = n_code = 0
    best = -1e18
    for center in BLIND_CENTERS:
        for d in deltas:
            t0 = time.perf_counter()
            bits, _ = extract_lattice(image, layout, float(d), step, center=center)
            t_ext += time.perf_counter() - t0
            n_ext += 1
            bits = bits.reshape(-1)
            for k in range(M):
                y = simultaneous_shift(bits, M, sign * k)
                t1 = time.perf_counter()
                sc = prc.score_from_bits(prc_key, y)
                t_code += time.perf_counter() - t1
                n_code += 1
                if sc > best:
                    best = sc
    return best, t_ext, t_code, n_ext, n_code


def run_pair(key_id, prcc_seed, prc_seed, step, shared):
    print(f"\n######## key_pair {key_id} ########", flush=True)
    layout = make_layout_c()
    prcc_key = make_key(np.random.default_rng(prcc_seed))
    np.random.seed(int(prc_seed) % (2**31 - 1))
    prc_key = prc.keygen(M * 4, fpr=FPR_TEST, t=3, message_length=16)

    # Calibrate PRCC
    from .baseline_c_common import pick_threshold

    prcc_none, prcc_att, tune_pos = [], [], []
    for i, path in enumerate(shared["calib"]):
        img = load_image(path, SIZE)
        sc, *_ = prcc_search_timed(prcc_key, img, layout, step)
        prcc_none.append(sc)
        att = apply_attack(img, "rot_jpeg", float(shared["angles_calib"][i]), 70, SIZE)
        sc2, *_ = prcc_search_timed(prcc_key, att, layout, step)
        prcc_att.append(sc2)
    for path, seed, ang in zip(shared["tune"], shared["encode_tune"], shared["angles_tune"]):
        img = load_image(path, SIZE)
        c = bc.encode(prcc_key, rng=np.random.default_rng(int(seed)), add_noise=False).reshape(4, M)
        marked = embed_lattice(img, layout, c, step)
        att = apply_attack(marked, "rot_jpeg", float(ang), 70, SIZE)
        sc, *_ = prcc_search_timed(prcc_key, att, layout, step)
        tune_pos.append(sc)
    pick_prcc = pick_threshold(prcc_none, prcc_att, tune_pos)
    thr_prcc = pick_prcc["threshold"]
    print(f"PRCC thr={thr_prcc}", flush=True)

    # Calibrate PRC (lowest legal thr)
    prc_none, prc_att = [], []
    for i, path in enumerate(shared["calib"]):
        img = load_image(path, SIZE)
        sc, *_ = prc_reuse_search_timed(prc_key, img, layout, step)
        prc_none.append(sc)
        att = apply_attack(img, "rot_jpeg", float(shared["angles_calib"][i]), 70, SIZE)
        sc2, *_ = prc_reuse_search_timed(prc_key, att, layout, step)
        prc_att.append(sc2)
    pick_prc = pick_prc_threshold(prc_none, prc_att)
    thr_prc = pick_prc["threshold"]
    print(f"PRC thr={thr_prc} (lowest legal)", flush=True)

    def eval_one(accept_fn, timed_fn, embed_fn):
        hits_n = hits_a = hits_p = 0
        t_ext = t_code = 0.0
        n_ext = n_code = 0
        psnrs = []
        for i, path in enumerate(shared["neg"]):
            img = load_image(path, SIZE)
            sc, te, tc, ne, nc = timed_fn(img)
            t_ext += te
            t_code += tc
            n_ext += ne
            n_code += nc
            hits_n += int(accept_fn(sc))
            att = apply_attack(img, "rot_jpeg", float(shared["angles_neg"][i]), 70, SIZE)
            sc2, te2, tc2, ne2, nc2 = timed_fn(att)
            t_ext += te2
            t_code += tc2
            n_ext += ne2
            n_code += nc2
            hits_a += int(accept_fn(sc2))
        for i, path in enumerate(shared["pos"]):
            img = load_image(path, SIZE)
            bits = embed_fn(i)
            marked = embed_lattice(img, layout, bits, step)
            psnrs.append(psnr(img, marked))
            att = apply_attack(marked, "rot_jpeg", float(shared["angles_pos"][i]), 70, SIZE)
            sc, te, tc, ne, nc = timed_fn(att)
            t_ext += te
            t_code += tc
            n_ext += ne
            n_code += nc
            hits_p += int(accept_fn(sc))
        nn = len(shared["neg"])
        np_ = len(shared["pos"])
        n_img = nn * 2 + np_
        return {
            "fpr_none": {"k": hits_n, "n": nn, "fpr": hits_n / nn, "cp_upper": clopper_upper(hits_n, nn)},
            "fpr_att": {"k": hits_a, "n": nn, "fpr": hits_a / nn, "cp_upper": clopper_upper(hits_a, nn)},
            "tpr": {
                "k": hits_p,
                "n": np_,
                "tpr": hits_p / np_,
                "cp_lo": clopper_pearson(hits_p, np_)[0],
                "cp_hi": clopper_pearson(hits_p, np_)[1],
            },
            "psnr_median": float(np.median(psnrs)),
            "timing": {
                "extract_seconds": t_ext,
                "code_seconds": t_code,
                "total_seconds": t_ext + t_code,
                "n_extracts": n_ext,
                "n_code_detects": n_code,
                "code_detects_per_image": n_code / max(n_img, 1),
                "extract_ms_per_call": 1e3 * t_ext / max(n_ext, 1),
                "code_ms_per_call": 1e3 * t_code / max(n_code, 1),
            },
        }

    def emb_prcc(i):
        return bc.encode(
            prcc_key, rng=np.random.default_rng(int(shared["encode_pos"][i])), add_noise=False
        ).reshape(4, M)

    def emb_prc(i):
        np.random.seed(int(shared["encode_pos"][i]) % (2**31 - 1))
        return prc.encode_bits(prc_key).reshape(4, M)

    print("eval PRCC…", flush=True)
    row_prcc = eval_one(
        lambda sc: thr_prcc is not None and np.isfinite(sc) and sc <= thr_prcc,
        lambda im: prcc_search_timed(prcc_key, im, layout, step),
        emb_prcc,
    )
    print("eval PRC…", flush=True)
    row_prc = eval_one(
        lambda sc: thr_prc is not None and sc >= thr_prc,
        lambda im: prc_reuse_search_timed(prc_key, im, layout, step),
        emb_prc,
    )
    print(
        f"key={key_id} PRCC TPR={row_prcc['tpr']['tpr']:.3f} code/img={row_prcc['timing']['code_detects_per_image']:.1f} "
        f"PRC TPR={row_prc['tpr']['tpr']:.3f} code/img={row_prc['timing']['code_detects_per_image']:.1f}",
        flush=True,
    )
    return {
        "key_id": key_id,
        "prcc_seed": prcc_seed,
        "prc_seed": prc_seed,
        "thr_prcc": thr_prcc,
        "thr_prc": thr_prc,
        "prc_calibration": pick_prc,
        "prcc": row_prcc,
        "prc": row_prc,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--step", type=float, default=0.141640625)
    ap.add_argument("--seed", type=int, default=30)
    ap.add_argument("--n-keys", type=int, default=3)
    ap.add_argument("--n-pos", type=int, default=300)
    ap.add_argument("--n-neg", type=int, default=1500)
    ap.add_argument("--n-calib", type=int, default=1000)
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()
    if prc is None or not prc.available():
        raise SystemExit("PRC adapter unavailable (need galois)")

    rng = np.random.default_rng(args.seed)
    shared = {
        "calib": split_paths("calib")[: args.n_calib],
        "tune": split_paths("tune")[:200],
        "neg": split_paths("test_neg")[: args.n_neg],
        "pos": split_paths("test_pos")[: args.n_pos],
    }
    shared["angles_calib"] = rng.uniform(0, 360, len(shared["calib"]))
    shared["angles_neg"] = rng.uniform(0, 360, len(shared["neg"]))
    shared["angles_pos"] = rng.uniform(0, 360, len(shared["pos"]))
    shared["angles_tune"] = rng.uniform(0, 360, len(shared["tune"]))
    shared["encode_pos"] = rng.integers(0, 2**31 - 1, len(shared["pos"]))
    shared["encode_tune"] = rng.integers(0, 2**31 - 1, len(shared["tune"]))

    prcc_seeds = (BASELINE_KEY_SEEDS + EXTRA_KEY_SEEDS)[: args.n_keys]
    prc_seeds = [int(x) ^ 0xA5A5A5A5 for x in prcc_seeds]
    pairs = [
        run_pair(i, prcc_seeds[i], prc_seeds[i], args.step, shared) for i in range(args.n_keys)
    ]

    # Aggregate timing / detects
    def mean_key(path):
        vals = []
        for p in pairs:
            cur = p
            for k in path:
                cur = cur[k]
            vals.append(cur)
        return float(np.mean(vals))

    decision = (
        f"{args.n_keys} paired keys (vectorized PRC detect). "
        f"Mean code detects/img: PRCC={mean_key(['prcc','timing','code_detects_per_image']):.1f}, "
        f"PRC={mean_key(['prc','timing','code_detects_per_image']):.1f} (64×). "
        f"Mean code time: PRCC={mean_key(['prcc','timing','code_seconds']):.1f}s, "
        f"PRC={mean_key(['prc','timing','code_seconds']):.1f}s "
        f"(includes per-call cost; not purely structural). "
        f"Mean TPR: PRCC={mean_key(['prcc','tpr','tpr']):.3f}, PRC={mean_key(['prc','tpr','tpr']):.3f}."
    )
    out = {
        "step": args.step,
        "n_keys": args.n_keys,
        "threshold_rule": "PRC: lowest legal thr (most_permissive_upper on both calib sets, strict <0.5%)",
        "per_key": pairs,
        "decision": decision,
    }
    out_path = (
        Path(args.out)
        if args.out
        else Path(__file__).resolve().parents[2] / "figures" / "prc_fair_C.json"
    )
    if args.out and not Path(args.out).is_absolute():
        out_path = Path(__file__).resolve().parents[1] / args.out
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2))
    try:
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(5.5, 3.5))
        prcc_c = mean_key(["prcc", "timing", "code_seconds"])
        prc_c = mean_key(["prc", "timing", "code_seconds"])
        prcc_e = mean_key(["prcc", "timing", "extract_seconds"])
        prc_e = mean_key(["prc", "timing", "extract_seconds"])
        x = np.arange(2)
        ax.bar(x - 0.18, [prcc_e, prcc_c], 0.36, label="PRCC")
        ax.bar(x + 0.18, [prc_e, prc_c], 0.36, label="PRC")
        ax.set_xticks(x)
        ax.set_xticklabels(["extract", "code"])
        ax.set_ylabel("mean seconds (eval set)")
        ax.legend()
        ax.set_title("PRCC vs PRC (vectorized, multi-key)")
        fig.tight_layout()
        fig.savefig(out_path.with_suffix(".png"), dpi=140)
        plt.close(fig)
    except Exception:
        pass
    print(decision, flush=True)
    print(f"wrote {out_path}", flush=True)


if __name__ == "__main__":
    main()
