"""Three metrics at once: ~35 dB, FPR upper ≤ 1%, rot+JPEG70 TPR ≥ 90%.

Lattice carrier only. w=1 and eta=0 are allowed performance candidates.
Tune = step + screen; calib = freeze integer threshold; test = report all three.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from . import block_circulant as bc
from .coco_photos import load_image, load_split, split_paths
from .fast_radial import make_layout, sector_pixel_counts
from .integer_threshold import clopper_pearson, clopper_upper, largest_integer_threshold
from .lattice_carrier import embed_lattice
from .lattice_detect import known_angle_ber, scores_over_angles_lattice
from .residual_search import shared_grids
from .spatial_multiring import apply_attack, psnr


PSNR_LO, PSNR_HI = 34.0, 36.0
FPR_ALPHA = 1e-2
TPR_TARGET = 0.90
B = 4
GUARD = 0.15


def _median_psnr(images, m, size, step, rng, n=40) -> float:
    layout = make_layout(size, m, B, GUARD, 0.0)
    vals = []
    for im in images[:n]:
        bits = rng.integers(0, 2, size=(B, m), dtype=np.uint8)
        vals.append(psnr(im, embed_lattice(im, layout, bits, step)))
    return float(np.median(vals))


def fit_step(images, m, size, rng) -> dict:
    counts = sector_pixel_counts(make_layout(size, m, B, GUARD, 0.0))
    empty = float(np.mean(counts == 0))
    # Grow step until median PSNR is in [34, 36].
    lo, hi = 0.02, 0.8
    p_lo = _median_psnr(images, m, size, lo, rng)
    p_hi = _median_psnr(images, m, size, hi, rng)
    note = "ok"
    if p_lo < PSNR_LO:
        note = "smallest_step_already_below_budget"
        step = lo
    elif p_hi > PSNR_HI:
        note = "cannot_spend_budget"
        step = hi
    else:
        for _ in range(16):
            mid = 0.5 * (lo + hi)
            if _median_psnr(images, m, size, mid, rng) > 35.0:
                lo = mid
            else:
                hi = mid
        step = 0.5 * (lo + hi)
    med = _median_psnr(images, m, size, step, rng)
    return {
        "m": m,
        "size": size,
        "step": float(step),
        "psnr_median": med,
        "pixels_per_sector_median": float(np.median(counts)),
        "empty_sector_fraction": empty,
        "note": note,
    }


def _make_key(m, w, eta, rng):
    tau = bc.suggest_tau(m, B * w, eta if eta > 0 else 0.03, 0.05)
    return bc.keygen(m, B, w, tau, eta, rng)


def _half_step(m: float) -> float:
    return 180.0 / m


def screen_cell(images, m, size, step, w, eta, L, rng, n_pos=80, n_neg=120) -> dict:
    layout = make_layout(size, m, B, GUARD, 0.0)
    key = _make_key(m, w, eta, rng)
    deltas, _ = shared_grids(m, L)
    angle = _half_step(m)
    neg_mins = [
        scores_over_angles_lattice(key, img, layout, deltas, step).best for img in images[:n_neg]
    ]
    thr = largest_integer_threshold(neg_mins, FPR_ALPHA)
    mass0 = float(np.mean(np.asarray(neg_mins) == 0))
    psnrs = []
    known_bers = []
    hits = 0
    for img in images[:n_pos]:
        c = bc.encode(key, rng=rng, add_noise=(eta > 0)).reshape(B, m)
        marked = embed_lattice(img, layout, c, step)
        psnrs.append(psnr(img, marked))
        attacked = apply_attack(marked, "rot_jpeg", angle, 70, size)
        known_bers.append(known_angle_ber(attacked, layout, c, step, angle))
        sc = scores_over_angles_lattice(key, attacked, layout, deltas, step).best
        if thr is not None and np.isfinite(sc) and sc <= thr:
            hits += 1
    tpr = hits / n_pos if n_pos else 0.0
    psnrs_a = np.asarray(psnrs)
    row = {
        "m": m,
        "size": size,
        "step": step,
        "w": w,
        "eta": eta,
        "L": L,
        "psnr_median": float(np.median(psnrs_a)),
        "psnr_p10": float(np.percentile(psnrs_a, 10)),
        "mass0_unmarked": mass0,
        "tune_threshold": thr,
        "tpr_rot_jpeg_tune": tpr,
        "known_ber_mean": float(np.mean(known_bers)),
        "known_ber_p90": float(np.percentile(known_bers, 90)),
        "budget_ok": bool(PSNR_LO <= float(np.median(psnrs_a)) <= PSNR_HI + 0.5),
        "mass0_ok": bool(mass0 <= FPR_ALPHA),
        "tpr_ok": bool(tpr >= TPR_TARGET),
    }
    row["screen_pass"] = bool(row["budget_ok"] and row["mass0_ok"] and row["tpr_ok"] and thr is not None)
    print(
        f"screen m={m} w={w} eta={eta} L={L} PSNR={row['psnr_median']:.1f} "
        f"mass0={mass0:.3f} thr={thr} TPR={tpr:.2f} knownBER={row['known_ber_mean']:.3f} "
        f"pass={row['screen_pass']}",
        flush=True,
    )
    return row


def holdout_cell(spec: dict, rng) -> dict:
    m, size, step = int(spec["m"]), int(spec["size"]), float(spec["step"])
    w, eta, L = int(spec["w"]), float(spec["eta"]), int(spec["L"])
    layout = make_layout(size, m, B, GUARD, 0.0)
    key = _make_key(m, w, eta, rng)
    deltas, _ = shared_grids(m, L)
    angle = _half_step(m)

    calib_scores = []
    for path in split_paths("calib"):
        img = load_image(path, size)
        calib_scores.append(scores_over_angles_lattice(key, img, layout, deltas, step).best)
    thr = largest_integer_threshold(calib_scores, FPR_ALPHA)
    row = {
        "m": m,
        "size": size,
        "step": step,
        "w": w,
        "eta": eta,
        "L": L,
        "threshold": thr,
        "n_calib": len(calib_scores),
        "mass0_calib": float(np.mean(np.asarray(calib_scores) == 0)),
    }
    if thr is None:
        row["failed"] = "no integer threshold with empirical FPR <= 1e-2 on calibration"
        row["passed"] = False
        print(f"holdout m={m} w={w} eta={eta} L={L} NO THRESHOLD")
        return row

    def fpr_on(kind: str):
        hits = 0
        n = 0
        for path in split_paths("test_neg"):
            img = apply_attack(load_image(path, size), kind, angle, 70, size)
            sc = scores_over_angles_lattice(key, img, layout, deltas, step).best
            hits += int(np.isfinite(sc) and sc <= thr)
            n += 1
        lo, hi = clopper_pearson(hits, n)
        return {
            "k": hits,
            "n": n,
            "fpr": hits / n,
            "cp_lo": lo,
            "cp_hi": hi,
            "cp_upper": clopper_upper(hits, n),
        }

    fpr_none = fpr_on("none")
    fpr_rj = fpr_on("rot_jpeg")

    tpr_hits = 0
    psnrs = []
    n_pos = 0
    for path in split_paths("test_pos"):
        img = load_image(path, size)
        c = bc.encode(key, rng=rng, add_noise=(eta > 0)).reshape(B, m)
        marked = embed_lattice(img, layout, c, step)
        psnrs.append(psnr(img, marked))
        attacked = apply_attack(marked, "rot_jpeg", angle, 70, size)
        sc = scores_over_angles_lattice(key, attacked, layout, deltas, step).best
        tpr_hits += int(np.isfinite(sc) and sc <= thr)
        n_pos += 1
    tpr_lo, tpr_hi = clopper_pearson(tpr_hits, n_pos)
    row.update(
        {
            "psnr_median": float(np.median(psnrs)),
            "psnr_p10": float(np.percentile(psnrs, 10)),
            "tpr_rot_jpeg": tpr_hits / n_pos,
            "tpr_k": tpr_hits,
            "tpr_n": n_pos,
            "tpr_cp_lo": tpr_lo,
            "tpr_cp_hi": tpr_hi,
            "fpr_none": fpr_none,
            "fpr_rot_jpeg_unmarked": fpr_rj,
        }
    )
    row["passed"] = bool(
        PSNR_LO - 0.5 <= row["psnr_median"] <= PSNR_HI + 1.0
        and fpr_none["cp_upper"] <= FPR_ALPHA
        and row["tpr_rot_jpeg"] >= TPR_TARGET
    )
    print(
        f"holdout m={m} w={w} eta={eta} L={L} thr={thr} "
        f"PSNR={row['psnr_median']:.1f} TPR={row['tpr_rot_jpeg']:.3f} "
        f"FPR_upper={fpr_none['cp_upper']:.4f} pass={row['passed']}",
        flush=True,
    )
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--size", type=int, default=256)
    ap.add_argument("--out", type=str, default="")
    ap.add_argument("--screen-pos", type=int, default=80)
    ap.add_argument("--screen-neg", type=int, default=120)
    ap.add_argument(
        "--max-holdout",
        type=int,
        default=0,
        help="If >0, hold out at most this many screen-pass configs (prefer L=8, then w=1).",
    )
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)

    tune = load_split("tune", args.size)
    steps = {}
    for m in (32, 64):
        info = fit_step(tune, m, args.size, rng)
        if m == 64 and info["empty_sector_fraction"] > 0.05:
            print(f"m=64 empty sectors {info['empty_sector_fraction']:.2f}; retry size 512")
            tune512 = load_split("tune", 512)
            info = fit_step(tune512, m, 512, rng)
            # keep size 512 for m=64 screens
            steps[m] = info
            del tune512
        else:
            steps[m] = info
        print(
            f"step m={m} size={info['size']} step={info['step']:.4f} "
            f"PSNR={info['psnr_median']:.1f} empty={info['empty_sector_fraction']:.3f}",
            flush=True,
        )

    # Preferentially screen w=1, eta=0 first, then the full grid.
    screen_rows = []
    priority = [(m, 1, 0.0, L) for m in (32, 64) for L in (2, 4, 8)]
    rest = [
        (m, w, eta, L)
        for m in (32, 64)
        for w in (1, 3)
        for eta in (0.0, 0.005, 0.01)
        for L in (2, 4, 8)
        if (m, w, eta, L) not in priority
    ]
    # Cache images per size
    images_by_size = {args.size: tune}
    for m, w, eta, L in priority + rest:
        size = int(steps[m]["size"])
        if size not in images_by_size:
            images_by_size[size] = load_split("tune", size)
        screen_rows.append(
            screen_cell(
                images_by_size[size],
                m,
                size,
                float(steps[m]["step"]),
                w,
                eta,
                L,
                rng,
                n_pos=args.screen_pos,
                n_neg=args.screen_neg,
            )
        )

    candidates = [r for r in screen_rows if r["screen_pass"]]
    # Also keep near-misses with tpr>=0.8 and mass0_ok for diagnostics if none pass
    if not candidates:
        near = [
            r
            for r in screen_rows
            if r["budget_ok"] and r["mass0_ok"] and r["tpr_rot_jpeg_tune"] >= 0.8 and r["tune_threshold"] is not None
        ]
        candidates = near
        near_note = "no full screen pass; holding out near-misses with TPR_tune>=0.8"
    else:
        near_note = None

    if args.max_holdout and len(candidates) > args.max_holdout:
        candidates = sorted(
            candidates,
            key=lambda r: (r["L"] != 8, r["w"] != 1, r["eta"], -r["tpr_rot_jpeg_tune"]),
        )[: args.max_holdout]
        near_note = (near_note or "") + f" capped holdout to {args.max_holdout} configs"

    holdout_rows = []
    for spec in candidates:
        holdout_rows.append(holdout_cell(spec, rng))

    passed = [r for r in holdout_rows if r.get("passed")]
    if passed:
        decision = f"{len(passed)} configuration(s) meet all three metrics on the holdout set."
    elif holdout_rows:
        # Find closest failure mode
        best = max(holdout_rows, key=lambda r: (r.get("tpr_rot_jpeg") or 0, -((r.get("fpr_none") or {}).get("cp_upper") or 1)))
        decision = (
            "No configuration meets all three metrics. Closest: "
            f"m={best['m']} w={best['w']} eta={best['eta']} L={best['L']} "
            f"PSNR={best.get('psnr_median')} TPR={best.get('tpr_rot_jpeg')} "
            f"FPR_upper={(best.get('fpr_none') or {}).get('cp_upper')}"
        )
    else:
        decision = "No configuration passed the tune screen; holdout not run."

    summary = {
        "criteria": {
            "psnr": [PSNR_LO, PSNR_HI],
            "fpr_upper": FPR_ALPHA,
            "tpr_rot_jpeg": TPR_TARGET,
            "metric": "single random encoding per image",
        },
        "steps": steps,
        "screen": screen_rows,
        "candidates": [
            {"m": r["m"], "w": r["w"], "eta": r["eta"], "L": r["L"], "size": r["size"], "step": r["step"]}
            for r in candidates
        ],
        "near_note": near_note,
        "holdout": holdout_rows,
        "passed": [
            {"m": r["m"], "w": r["w"], "eta": r["eta"], "L": r["L"], "threshold": r["threshold"]}
            for r in passed
        ],
        "decision": decision,
    }
    if args.out:
        out = Path(args.out)
        if not out.is_absolute():
            out = Path(__file__).resolve().parents[1] / out
    else:
        out = Path(__file__).resolve().parents[2] / "figures" / "three_metrics.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(summary, indent=2))
    print(decision)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
