"""Experiment 2: m by w scan at a frozen 35 dB push-to-margin budget.

Screening statistics are computed on the tune split only.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from . import block_circulant as bc
from .coco_photos import load_split, split_paths, load_image
from .fast_radial import make_layout, push_to_margin, radial_soft, sector_pixel_counts
from .integer_threshold import hist_counts, largest_integer_threshold
from .margin_fit import fit_strength, median_psnr
from .residual_search import shared_grids
from .search_scores import scores_over_angles
from .spatial_multiring import psnr


BER_USABLE = 0.10
MASS0_MAX = 1e-2


def _eval_at_strength(images, m, b, w, eta, guard, strength, L, rng, target):
    size = int(images[0].shape[0])
    layout = make_layout(size, m, b, guard, strength)
    counts = sector_pixel_counts(layout)
    tau = bc.suggest_tau(m, b * w, eta, 0.05)
    key = bc.keygen(m, b, w, tau, eta, rng)
    deltas, _ = shared_grids(m, L)
    psnrs = []
    bers = []
    channel_scores = []
    pos_mins = []
    neg_mins = []
    algebraic = []
    for _ in range(200):
        algebraic.append(bc.detect_score(key, bc.encode(key, rng=rng)))
    for img in images:
        code = bc.encode(key, rng=rng).reshape(b, m)
        marked = push_to_margin(img, layout, code)
        psnrs.append(psnr(img, marked))
        soft = radial_soft(marked, layout, 0.0)
        hat = (soft >= 0).astype(np.uint8)
        bers.append(float(np.mean(hat != code)))
        known = scores_over_angles(key, marked, layout, [0.0])
        channel_scores.append(known.best)
        searched = scores_over_angles(key, marked, layout, deltas)
        pos_mins.append(searched.best)
        neg = scores_over_angles(key, img, layout, deltas)
        neg_mins.append(neg.best)
    psnrs_a = np.asarray(psnrs)
    bers_a = np.asarray(bers)
    neg_a = np.asarray(neg_mins, dtype=float)
    thr = largest_integer_threshold(neg_mins, 1e-2)
    tpr = float(np.mean(np.asarray(pos_mins) <= thr)) if thr is not None else 0.0
    floor_bits = [np.zeros((b, m), dtype=np.uint8) for _ in images[: min(40, len(images))]]
    # floor bits are replaced below by the caller's measurement
    return {
        "m": m,
        "w": w,
        "b": b,
        "L": L,
        "eta": eta,
        "n_bits": b * m,
        "n_checks": m,
        "n_images": len(images),
        "size": size,
        "strength": strength,
        "psnr_median": float(np.median(psnrs_a)),
        "psnr_p10": float(np.percentile(psnrs_a, 10)),
        "ber_mean": float(bers_a.mean()),
        "ber_p90": float(np.percentile(bers_a, 90)),
        "image_failure_rate": float(np.mean(bers_a > 0.5)),
        "pixels_per_sector_median": float(np.median(counts)),
        "empty_sector_fraction": float(np.mean(counts == 0)),
        "algebraic_syndrome_hist": hist_counts(algebraic, m),
        "channel_syndrome_hist": hist_counts(channel_scores, m),
        "unmarked_min_hist": hist_counts(neg_mins, m),
        "unmarked_mass_at_0": float(np.mean(neg_a == 0)),
        "tune_threshold": thr,
        "tune_screen_tpr": tpr,
        "target_psnr": target,
        "_floor_bits_placeholder": floor_bits,
    }


def eval_cell(images, m, b, w, eta, guard, L, rng, target):
    fit_n = min(40, len(images))
    fit_images = images[:fit_n]
    fit_bits = [rng.integers(0, 2, size=(b, m), dtype=np.uint8) for _ in fit_images]
    floor_psnr = median_psnr(fit_images, fit_bits, m, b, guard, 1e-4)
    no_room = floor_psnr < target - 0.5
    if no_room:
        strength, fit_note = 1e-4, "sign_floor_exceeds_budget"
        fit_psnr = floor_psnr
    else:
        strength, fit_psnr, fit_note = fit_strength(fit_images, fit_bits, m, b, guard, target)
    row = _eval_at_strength(images, m, b, w, eta, guard, strength, L, rng, target)
    row.pop("_floor_bits_placeholder", None)
    row["sign_floor_psnr_median"] = floor_psnr
    row["fit_note"] = fit_note
    row["fit_psnr_on_match_subset"] = fit_psnr
    row["budget_ok"] = (not no_room) and abs(row["psnr_median"] - target) <= 1.5
    row["ber_usable"] = bool(row["ber_mean"] <= BER_USABLE and row["image_failure_rate"] <= 0.05)
    row["mass0_ok"] = bool(row["unmarked_mass_at_0"] < MASS0_MAX)
    row["screen_pass"] = bool(row["w"] == 3 and row["budget_ok"] and row["ber_usable"] and row["mass0_ok"])
    print(
        f"m={m} w={w} size={row['size']} PSNR={row['psnr_median']:.1f} "
        f"floor={floor_psnr:.1f} BER={row['ber_mean']:.3f} mass0={row['unmarked_mass_at_0']:.4f} "
        f"tpr={row['tune_screen_tpr']:.2f} pass={row['screen_pass']} {fit_note}"
    )
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", type=int, default=256)
    ap.add_argument("--b", type=int, default=4)
    ap.add_argument("--L", type=int, default=4)
    ap.add_argument("--eta", type=float, default=0.03)
    ap.add_argument("--guard", type=float, default=0.15)
    ap.add_argument("--target-psnr", type=float, default=35.0)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", type=str, default="../figures/capacity_scan.json")
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    images = load_split("tune", args.size)
    rows = []
    for m in (8, 16, 32, 64):
        for w in (1, 3):
            rows.append(eval_cell(images, m, args.b, w, args.eta, args.guard, args.L, rng, args.target_psnr))
    # Higher resolution only where m=64 known-angle BER has collapsed.
    collapsed = [r for r in rows if r["m"] == 64 and r["ber_mean"] > 0.25]
    if collapsed:
        print("m=64 BER collapsed at 256; retrying size 512")
        paths = split_paths("tune")
        big = [load_image(p, 512) for p in paths]
        for w in (1, 3):
            retried = eval_cell(big, 64, args.b, w, args.eta, args.guard, args.L, rng, args.target_psnr)
            retried["retry_of_size"] = 256
            rows.append(retried)
        del big

    candidates = [r for r in rows if r["screen_pass"]]
    summary = {
        "ber_usable_rule": f"mean BER <= {BER_USABLE} and image BER>0.5 rate <= 0.05",
        "mass0_rule": f"unmarked P(min=0) < {MASS0_MAX}",
        "budget_rule": "sign-floor median PSNR is not below 35 dB, and achieved median is within 1.5 dB of 35",
        "continue": len(candidates) > 0,
        "candidates": [{"m": r["m"], "w": r["w"], "size": r["size"], "strength": r["strength"]} for r in candidates],
        "rows": rows,
    }
    if not summary["continue"]:
        summary["stop"] = "No w=3 cell is inside the 35 dB budget with usable known-angle BER and unmarked mass at 0 below 1e-2. Do not run the independent FPR test."
    out = Path(args.out)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(summary, indent=2))
    print(f"continue={summary['continue']} candidates={summary['candidates']}")
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
