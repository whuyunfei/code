"""Kodak lossless test images, split by filename.

Tune kodim01–08, calibrate kodim09–16, test kodim17–24.
Download with ``python -m src.bootstrap_photos``. Missing files are an error;
callers must not fall back to the proxy set.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import numpy as np

SPLITS: Dict[str, range] = {
    "tune": range(1, 9),
    "calib": range(9, 17),
    "test": range(17, 25),
}


def photos_dir() -> Path:
    return Path(__file__).resolve().parents[1] / "data" / "photos"


def split_paths(split: str, folder: Path | None = None) -> List[Path]:
    if split not in SPLITS:
        raise KeyError(split)
    root = Path(folder) if folder is not None else photos_dir()
    return [root / f"kodim{i:02d}.png" for i in SPLITS[split]]


def load_split(split: str, size: int, folder: Path | None = None) -> List[np.ndarray]:
    from PIL import Image

    paths = split_paths(split, folder)
    missing = [p for p in paths if not p.is_file() or p.stat().st_size < 10000]
    if missing:
        names = ", ".join(p.name for p in missing)
        raise FileNotFoundError(
            f"Kodak split {split} incomplete ({names}). Run: python -m src.bootstrap_photos"
        )
    imgs = []
    for p in paths:
        im = Image.open(p).convert("RGB").resize((size, size), Image.BILINEAR)
        imgs.append(np.asarray(im).astype(np.float64))
    return imgs
