"""Download COCO 2017 val into experiments/data/coco/val2017 and write splits.

Does not touch the proxy set or the Kodak photos.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

from .coco_photos import coco_dir, write_manifest

URL = "http://images.cocodataset.org/zips/val2017.zip"


def main() -> None:
    root = coco_dir()
    root.mkdir(parents=True, exist_ok=True)
    n_jpg = len(list(root.glob("*.jpg"))) + len(list(root.glob("*.jpeg")))
    if n_jpg < 5000:
        zip_path = root.parent / "val2017.zip"
        print(f"downloading {URL}")
        proc = subprocess.run(
            ["curl", "-L", "--fail", "--retry", "3", "-o", str(zip_path), URL],
            check=False,
        )
        if proc.returncode != 0:
            raise SystemExit(f"COCO download failed with code {proc.returncode}")
        subprocess.run(["unzip", "-q", "-o", str(zip_path), "-d", str(root.parent)], check=True)
        zip_path.unlink(missing_ok=True)
    manifest = write_manifest()
    print({k: len(v) for k, v in manifest.items()})
    print(f"ok {coco_dir()}")


if __name__ == "__main__":
    main()
