"""Experiment 3: margin push vs two-coset lattice vs smooth lattice carrier.

Known-angle, single random payload per image. No code. Budget ~35 dB.
Primary metric: one-shot BER (not best-of-two).
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.stats import ks_2samp

from .coco_photos import load_split
from .fast_radial import make_layout, push_to_margin, radial_soft
from .lattice_carrier import (
    embed_lattice,
    embed_smooth_lattice,
    extract_lattice,
    extract_smooth_lattice,
    lattice_step,
)
from .spatial_multiring import apply_attack, psnr


def _fit_margin_strength(images, bits_list, m, b, target=35.0):
    lo, hi = 1e-4, 0.5
    for _ in range(12):
        mid = 0.5 * (lo + hi)
        layout = make_layout(images[0].shape[0], m, b, 0.15, mid)
        med = float(np.median([psnr(im, push_to_margin(im, layout, bt)) for im, bt in zip(images, bits_list)]))
        if med > target:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def _rotation_sign(layout, embed_fn, extract_fn, rng) -> int:
    bits = rng.integers(0, 2, size=(layout.b, layout.m), dtype=np.uint8)
    img = np.full((layout.size, layout.size, 3), 140.0)
    marked = embed_fn(img, layout, bits)
    attacked = apply_attack(marked, "rot", 22.5, size=layout.size)
    best_s, best_b = 1, 1.0
    for sign in (1, -1):
        hat, _ = extract_fn(attacked, layout, sign * 22.5)
        ber = float(np.mean(hat != bits))
        if ber < best_b:
            best_s, best_b = sign, ber
    return best_s


def eval_mode(name, images, m, b, rng, strength=None, step=None):
    size = int(images[0].shape[0])
    if name == "margin":
        layout = make_layout(size, m, b, 0.15, strength)
        embed_fn = push_to_margin
        def extract_fn(im, lay, ang):
            soft = radial_soft(im, lay, ang)
            return (soft >= 0).astype(np.uint8), soft
        floor_layout = make_layout(size, m, b, 0.15, 1e-4)
        floor_psnr = float(np.median([
            psnr(im, push_to_margin(im, floor_layout, rng.integers(0, 2, size=(b, m), dtype=np.uint8)))
            for im in images[:40]
        ]))
    elif name == "lattice":
        layout = make_layout(size, m, b, 0.15, 0.0)
        step = lattice_step(m) if step is None else step
        embed_fn = lambda im, lay, bt: embed_lattice(im, lay, bt, step)
        extract_fn = lambda im, lay, ang: extract_lattice(im, lay, ang, step)
        floor_psnr = float(np.median([
            psnr(im, embed_lattice(im, layout, rng.integers(0, 2, size=(b, m), dtype=np.uint8), step))
            for im in images[:40]
        ]))
    else:
        layout = make_layout(size, m, b, 0.15, 0.0)
        step = lattice_step(m) if step is None else step
        embed_fn = lambda im, lay, bt: embed_smooth_lattice(im, lay, bt, step)
        extract_fn = lambda im, lay, ang: extract_smooth_lattice(im, lay, ang, step)
        floor_psnr = float(np.median([
            psnr(im, embed_smooth_lattice(im, layout, rng.integers(0, 2, size=(b, m), dtype=np.uint8), step))
            for im in images[:40]
        ]))

    sign = _rotation_sign(layout, embed_fn, extract_fn, rng)
    attacks = ("none", "rot", "jpeg", "rot_jpeg")
    angle = 180.0 / m
    out_attacks = {}
    coeffs_marked = []
    coeffs_plain = []
    for kind in attacks:
        bers = []
        psnrs = []
        for img in images:
            bits = rng.integers(0, 2, size=(b, m), dtype=np.uint8)
            marked = embed_fn(img, layout, bits)
            psnrs.append(psnr(img, marked))
            attacked = apply_attack(marked, kind, angle, 70, size)
            off = 0.0 if kind in ("none", "jpeg") else sign * angle
            hat, _soft = extract_fn(attacked, layout, off)
            bers.append(float(np.mean(hat != bits)))
            if kind == "none":
                if name == "margin":
                    coeffs_marked.append(radial_soft(marked, layout, 0.0).ravel())
                    coeffs_plain.append(radial_soft(img, layout, 0.0).ravel())
                elif name == "lattice":
                    coeffs_marked.append(radial_soft(marked, layout, 0.0).ravel())
                    coeffs_plain.append(radial_soft(img, layout, 0.0).ravel())
                else:
                    from .lattice_carrier import smooth_radial_soft
                    coeffs_marked.append(smooth_radial_soft(marked, layout, 0.0).ravel())
                    coeffs_plain.append(smooth_radial_soft(img, layout, 0.0).ravel())
        ba = np.asarray(bers)
        out_attacks[kind] = {
            "ber_mean": float(ba.mean()),
            "ber_p90": float(np.percentile(ba, 90)),
            "image_failure_rate": float(np.mean(ba > 0.5)),
            "psnr_median": float(np.median(psnrs)),
            "psnr_p10": float(np.percentile(psnrs, 10)),
            "n": len(ba),
        }
    pool_m = np.concatenate(coeffs_marked)
    pool_p = np.concatenate(coeffs_plain)
    ks = ks_2samp(pool_m, pool_p)
    # Simple pile-up score near lattice / margin
    if name == "margin":
        pile = float(np.mean(np.abs(np.abs(pool_m) - (strength or 0.03)) < 0.01))
    else:
        s = lattice_step(m) if step is None else step
        r = np.mod(pool_m, s)
        pile = float(np.mean((r < 0.05 * s) | (np.abs(r - 0.5 * s) < 0.05 * s) | (s - r < 0.05 * s)))
    return {
        "mode": name,
        "m": m,
        "b": b,
        "strength": strength,
        "step": step if name != "margin" else None,
        "floor_or_embed_psnr_median": floor_psnr,
        "budget_ok": floor_psnr >= 34.0 or out_attacks["none"]["psnr_median"] >= 34.0,
        "attacks": out_attacks,
        "ks_D": float(ks.statistic),
        "ks_p": float(ks.pvalue),
        "coeff_pile_fraction": pile,
        "rotation_sign": sign,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", type=int, default=256)
    ap.add_argument("--b", type=int, default=4)
    ap.add_argument("--seed", type=int, default=2)
    ap.add_argument("--n-images", type=int, default=80)
    ap.add_argument("--out", type=str, default="../figures/lattice_carrier.json")
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    images = load_split("tune", args.size, limit=args.n_images)
    rows = []
    for m in (16, 32):
        bits_list = [rng.integers(0, 2, size=(args.b, m), dtype=np.uint8) for _ in images[:40]]
        strength = _fit_margin_strength(images[:40], bits_list, m, args.b, 35.0)
        for name in ("margin", "lattice", "smooth"):
            row = eval_mode(name, images, m, args.b, rng, strength=strength)
            rows.append(row)
            a = row["attacks"]["rot_jpeg"]
            print(
                f"m={m} {name:7} PSNR={a['psnr_median']:.1f} floor={row['floor_or_embed_psnr_median']:.1f} "
                f"BER={a['ber_mean']:.3f} p90={a['ber_p90']:.3f} pile={row['coeff_pile_fraction']:.2f}"
            )

    def better(mode_row, base_row):
        for kind in ("jpeg", "rot_jpeg"):
            if not (
                mode_row["attacks"][kind]["ber_p90"] <= base_row["attacks"][kind]["ber_p90"] - 0.05
                and mode_row["attacks"][kind]["ber_mean"] < base_row["attacks"][kind]["ber_mean"]
            ):
                return False
        return mode_row["attacks"]["none"]["psnr_median"] >= 34.0

    winners = []
    for m in (16, 32):
        base = next(r for r in rows if r["m"] == m and r["mode"] == "margin")
        for name in ("lattice", "smooth"):
            alt = next(r for r in rows if r["m"] == m and r["mode"] == name)
            if better(alt, base):
                winners.append({"m": m, "mode": name, "rot_jpeg_ber": alt["attacks"]["rot_jpeg"]["ber_mean"]})
    # Reliable bits for pure-code needs: rough — BER p90 <= 0.05 at m that pure-code wanted
    reliable = [
        r for r in rows
        if r["mode"] != "margin"
        and r["attacks"]["rot_jpeg"]["ber_p90"] <= 0.05
        and r["attacks"]["none"]["psnr_median"] >= 34.0
    ]
    summary = {
        "primary_metric": "single random payload BER per image",
        "rows": rows,
        "winners_vs_margin": winners,
        "reliable_enough_for_code": [
            {"m": r["m"], "mode": r["mode"], "ber_p90": r["attacks"]["rot_jpeg"]["ber_p90"]} for r in reliable
        ],
        "decision": (
            "At least one new carrier beats margin on JPEG/rot+JPEG and stays near 35 dB; may reconnect to code."
            if winners and reliable
            else (
                "New carrier improves on margin but still not enough reliable bits for the pure-code target."
                if winners
                else "Neither lattice nor smooth lattice lowers the distortion/BER floor enough at m=16/32 under ~35 dB. Stop this post-process image-watermark line; keep PRCC theory and these runs as application limits."
            )
        ),
        "stealth_note": "Lattice pile-up is reported via coeff_pile_fraction and KS; not claimed undetectable.",
    }
    out = Path(args.out)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(summary, indent=2))
    print(summary["decision"])
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
