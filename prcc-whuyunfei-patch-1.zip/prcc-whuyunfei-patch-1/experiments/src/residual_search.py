"""Phase 3: residual-angle search for block-circulant detection.

theta = k * Delta + delta, Delta = 360/m.
Block-circulant absorbs integer k; search only delta in [0, Delta).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

import numpy as np

from .block_circulant import BlockCirculantKey, detect_score, simultaneous_shift
from .security_probes import detect_with_constant_reject, reject_near_constant_blocks
from .spatial_multiring import (
    MultiRingLayout,
    center_crop_or_pad,
    extract_bits,
    extract_soft,
    rotate_pad,
)


def delta_grid(m: int, L: int) -> np.ndarray:
    """L candidates uniformly in [0, Delta)."""
    Delta = 360.0 / m
    if L <= 1:
        return np.array([0.0])
    return (np.arange(L) + 0.5) * (Delta / L)  # bin centers


def shared_grids(m: int, L: int) -> Tuple[np.ndarray, np.ndarray]:
    """Residual offsets and the full angle grid ``k*Delta + delta``.

    The full grid is ``arange(0, 360, Delta/L)``. Residual offsets are the L
    angles in ``[0, Delta)``. Integer steps are the code's job, not a second extract.
    """
    delta = 360.0 / m
    step = delta / max(L, 1)
    deltas = np.arange(L, dtype=np.float64) * step
    angles = np.arange(0.0, 360.0, step)
    return deltas, angles


def select_valid_candidate(
    scored: Sequence[Tuple[float, np.ndarray]],
    m: int,
    constant_reject: bool,
    lower_is_better: bool = True,
) -> Tuple[float, Optional[np.ndarray], int, int]:
    """Best score among candidates that are not near-constant blocks.

    Returns ``(best_score, best_y, best_index, n_valid)``. If every candidate is
    rejected, ``best_score`` is ``+inf`` and ``best_index`` is -1 so a lower-tail
    threshold cannot accept the sample.
    """
    best_sc = float("inf") if lower_is_better else float("-inf")
    best_y: Optional[np.ndarray] = None
    best_i = -1
    n_valid = 0
    for i, (sc, y) in enumerate(scored):
        if constant_reject and reject_near_constant_blocks(y, m):
            continue
        n_valid += 1
        better = sc < best_sc if lower_is_better else sc > best_sc
        if better:
            best_sc = float(sc)
            best_y = y
            best_i = i
    if n_valid == 0:
        return float("inf"), None, -1, 0
    return best_sc, best_y, best_i, n_valid


def passes_lower(result: "SearchResult", thr: float) -> bool:
    """Calibrated lower-tail test. Rejected-all samples do not pass."""
    return result.n_valid > 0 and np.isfinite(result.best_score) and result.best_score <= thr


def hard_score(key: BlockCirculantKey, bits_flat: np.ndarray) -> int:
    return detect_score(key, bits_flat.astype(np.uint8))


def soft_check_score(key: BlockCirculantKey, soft_flat: np.ndarray) -> float:
    """Soft reliability-weighted syndrome disagreement with target 1.

    For each check row, approx: soft parity via tanh product on LLR-like soft.
    Lower is better (agree with all-ones target).
    """
    # Map soft in [-1,1]-ish to LLR proxy
    llr = np.clip(soft_flat.astype(np.float64), -1, 1) * 4.0
    # bits 0/1 from sign; reliability |tanh|
    # Score: expected wt(Hy + 1) under independent soft bits — use hard for simplicity
    # plus penalty on low-confidence bits that participate in unsatisfied checks
    y = (soft_flat >= 0).astype(np.uint8)
    s = (key.H @ y) % 2
    ones = np.ones(key.m, dtype=np.uint8)
    unsat = s ^ ones
    # weight unsatisfied checks by mean |soft| of variables in check
    score = 0.0
    for i in range(key.m):
        if unsat[i] == 0:
            continue
        cols = np.where(key.H[i] == 1)[0]
        rel = float(np.mean(np.abs(soft_flat[cols]))) if len(cols) else 1.0
        score += 1.0 + 0.5 * (1.0 - rel)
    return score


@dataclass
class SearchResult:
    best_delta: float
    best_score: float
    accepted: bool
    scores: List[float]
    deltas: List[float]
    n_valid: int = 0


def _search_angles(
    key: BlockCirculantKey,
    image: np.ndarray,
    layout: MultiRingLayout,
    angles: np.ndarray,
    use_soft: bool,
    constant_reject: bool,
) -> SearchResult:
    scored: List[Tuple[float, np.ndarray]] = []
    raw_scores: List[float] = []
    for d in angles:
        if use_soft:
            soft = extract_soft(image, layout, angle_offset_deg=float(d)).reshape(-1)
            sc = float(soft_check_score(key, soft))
            y = (soft >= 0).astype(np.uint8)
        else:
            y = extract_bits(image, layout, angle_offset_deg=float(d)).reshape(-1)
            sc = float(hard_score(key, y))
        scored.append((sc, y))
        raw_scores.append(sc)
    best_sc, best_y, best_i, n_valid = select_valid_candidate(
        scored, key.m, constant_reject, lower_is_better=True
    )
    shown: List[float] = []
    for sc, y in scored:
        if constant_reject and reject_near_constant_blocks(y, key.m):
            shown.append(float("nan"))
        else:
            shown.append(float(sc))
    if best_y is None:
        acc = False
        best_delta = float("nan")
    else:
        acc = detect_with_constant_reject(key, best_y) if constant_reject else (best_sc <= key.tau)
        best_delta = float(angles[best_i])
    return SearchResult(
        best_delta=best_delta,
        best_score=float(best_sc),
        accepted=bool(acc),
        scores=shown,
        deltas=[float(d) for d in angles],
        n_valid=n_valid,
    )


def search_deltas(
    key: BlockCirculantKey,
    image: np.ndarray,
    layout: MultiRingLayout,
    deltas: Sequence[float],
    use_soft: bool = False,
    constant_reject: bool = True,
) -> SearchResult:
    """Residual (or any explicit) angle search on ``deltas``."""
    return _search_angles(key, image, layout, np.asarray(deltas, dtype=np.float64), use_soft, constant_reject)


def search_residual(
    key: BlockCirculantKey,
    image: np.ndarray,
    layout: MultiRingLayout,
    L: int,
    use_soft: bool = False,
    constant_reject: bool = True,
) -> SearchResult:
    """Blind residual-angle search (image + key only)."""
    deltas = delta_grid(layout.m, L)
    return _search_angles(key, image, layout, deltas, use_soft, constant_reject)


def search_full_angle(
    key: BlockCirculantKey,
    image: np.ndarray,
    layout: MultiRingLayout,
    L_per_bin: int,
    use_soft: bool = False,
) -> SearchResult:
    """Diagnostic: search all angles with step Delta/L (m*L candidates)."""
    _delta, angles = shared_grids(layout.m, L_per_bin)
    return _search_angles(key, image, layout, angles, use_soft, constant_reject=True)


def verify_integer_absorption(
    key: BlockCirculantKey,
    c: np.ndarray,
    m: int,
) -> bool:
    """On bit strings: score(T_k c) == score(c) for all k."""
    base = detect_score(key, c)
    for k in range(m):
        if detect_score(key, simultaneous_shift(c, m, k)) != base:
            return False
    return True


def residual_equals_full_on_synthetic(
    key: BlockCirculantKey,
    c: np.ndarray,
    m: int,
    L: int,
    true_delta: float,
    true_k: int,
) -> Tuple[bool, float, float]:
    """Pure bit-level: apply T_k only (delta=0 on bits). Residual L search vs full.

    For fractional delta we need the image pipeline; here check k-absorption only.
    """
    y = simultaneous_shift(c, m, true_k)
    # residual search over delta is N/A on bits; compare score invariance
    return verify_integer_absorption(key, c, m), float(detect_score(key, y)), float(detect_score(key, c))
