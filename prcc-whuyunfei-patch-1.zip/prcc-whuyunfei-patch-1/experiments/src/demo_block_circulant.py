"""Demo: block-circulant coset encoding, T_k invariance, BSC budget."""

from __future__ import annotations

import numpy as np

from .block_circulant import (
    bsc,
    detect,
    detect_score,
    encode,
    expected_syndrome_weight,
    keygen,
    simultaneous_shift,
    suggest_tau,
    verify_shift_invariance,
)


def main() -> None:
    rng = np.random.default_rng(0)
    # Keep check weight W = b*w small enough that E[score] < m/2 under mild BSC.
    m, b, w, eta = 32, 4, 1, 0.03
    tau = suggest_tau(m, row_weight=b * w, eta=eta, p_channel=0.02)
    key = keygen(m=m, b=b, weights=w, tau=tau, eta=eta, rng=rng)

    c0 = encode(key, rng=rng, add_noise=False)
    ok0, scores0 = verify_shift_invariance(key, c0, ks=list(range(0, m, max(1, m // 8))))
    print(f"params m={m} b={b} w={w} tau={tau} eta={eta} n={m*b} W={b*w}")
    print(f"noiseless score={detect_score(key, c0)} shift-invariant={ok0} scores={scores0}")

    c = encode(key, rng=rng)
    ok, scores = verify_shift_invariance(key, c, ks=list(range(0, m, max(1, m // 8))))
    print(f"noisy score={detect_score(key, c)} shift-invariant={ok}")
    step = max(1, m // 8)
    accepts = sum(detect(key, simultaneous_shift(c, m, k)) for k in range(0, m, step))
    print(f"Detect accepts subsampled T_k: {accepts}/{len(range(0, m, step))}")

    for p in (0.0, 0.02, 0.05):
        exp_wt = expected_syndrome_weight(key, p)
        ok_p = 0
        trials = 40
        for _ in range(trials):
            c2 = bsc(simultaneous_shift(encode(key, rng=rng), m, int(rng.integers(0, m))), p, rng)
            ok_p += int(detect(key, c2))
        print(f"BSC p={p:.3f}  E[score]≈{exp_wt:.1f}  detection={ok_p/trials:.3f}  (tau={tau})")
    u = rng.integers(0, 2, size=m * b, dtype=np.uint8)
    print(f"Detect(uniform)={detect(key, u)} score={detect_score(key, u)}")


if __name__ == "__main__":
    main()
