"""Compare block-circulant PRCC vs ring-OR sparse PRC under matched settings."""

from __future__ import annotations

import argparse
from time import perf_counter

import numpy as np

from . import block_circulant as bc
from . import prc_baseline as prc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--m", type=int, default=32)
    ap.add_argument("--b", type=int, default=4)
    ap.add_argument("--w", type=int, default=1)
    ap.add_argument("--r-prc", type=int, default=-1, help="sparse PRC rows (-1 => m)")
    ap.add_argument("--tau-block", type=int, default=-1, help="-1 => auto from BSC budget")
    ap.add_argument("--tau-prc", type=int, default=-1, help="-1 => same as tau-block")
    ap.add_argument("--eta", type=float, default=0.03)
    ap.add_argument("--p", type=float, default=0.02)
    ap.add_argument("--trials", type=int, default=40)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    m, b = args.m, args.b
    n = m * b
    W = b * args.w
    tau_block = args.tau_block if args.tau_block >= 0 else bc.suggest_tau(m, W, args.eta, args.p)
    tau_prc = args.tau_prc if args.tau_prc >= 0 else tau_block

    r_prc = args.r_prc if args.r_prc > 0 else m
    if r_prc >= n:
        r_prc = max(1, n // 2)
    block_key = bc.keygen(m=m, b=b, weights=args.w, tau=tau_block, eta=args.eta, rng=rng)
    prc_key = prc.keygen(m=m, b=b, r=r_prc, w=max(args.w, 3), tau=tau_prc, eta=args.eta, rng=rng)

    print(
        f"n={n} m={m} b={b} w={args.w} eta={args.eta} p={args.p} "
        f"tau_block={tau_block} tau_prc={tau_prc} r_prc={r_prc}"
    )
    print(f"block E[score|BSC]≈{bc.expected_syndrome_weight(block_key, args.p):.2f}")

    block_det = block_fpr = 0
    prc_det = prc_fpr = 0
    block_time = prc_time = 0.0
    # Also measure aligned-only PRC (no OR) for reference
    prc_aligned_det = 0

    for _ in range(args.trials):
        c = bc.encode(block_key, rng=rng)
        k = int(rng.integers(0, m))
        y = bc.bsc(bc.simultaneous_shift(c, m, k), args.p, rng)
        t0 = perf_counter()
        block_det += int(bc.detect(block_key, y))
        block_time += perf_counter() - t0
        u = rng.integers(0, 2, size=n, dtype=np.uint8)
        block_fpr += int(bc.detect(block_key, u))

        c2 = prc.encode(prc_key, rng=rng)
        k2 = int(rng.integers(0, m))
        y2 = bc.bsc(bc.simultaneous_shift(c2, m, k2), args.p, rng)
        ok, dt = prc.timed_detect_ring_or(prc_key, y2)
        prc_det += int(ok)
        prc_time += dt
        prc_aligned_det += int(prc.detect_aligned(prc_key, y2))
        u2 = rng.integers(0, 2, size=n, dtype=np.uint8)
        prc_fpr += int(prc.detect_ring_or(prc_key, u2))

    print(
        f"block: detection={block_det/args.trials:.3f}  "
        f"FPR_uniform={block_fpr/args.trials:.3f}  "
        f"ms/detect={1e3*block_time/args.trials:.3f}"
    )
    print(
        f"prc_or: detection={prc_det/args.trials:.3f}  "
        f"FPR_uniform={prc_fpr/args.trials:.3f}  "
        f"ms/detect={1e3*prc_time/args.trials:.3f}  "
        f"aligned_only_det={prc_aligned_det/args.trials:.3f}"
    )


if __name__ == "__main__":
    main()
