"""Geometry gate: embed–rotate–extract BER with ordinary random bits."""

from __future__ import annotations

import argparse

import numpy as np

from .ring_channel import (
    RingLayout,
    compare_embed_methods,
    default_angles,
    gate_decision,
    run_channel_sweep,
    unmarked_bit_stats,
)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", type=int, default=128)
    ap.add_argument("--m", type=int, default=8)
    ap.add_argument("--radii", type=str, default="28,48", help="FFT radii or spatial [r_inner,r_outer]")
    ap.add_argument("--trials", type=int, default=4)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--amp", type=float, default=0.5)
    ap.add_argument("--embed", type=str, default="spatial", choices=["point", "sector", "spatial"])
    ap.add_argument(
        "--extract", type=str, default="spatial", choices=["nearest", "bilinear", "sector", "spatial"]
    )
    ap.add_argument("--sector-frac", type=float, default=0.9)
    ap.add_argument("--radial-half", type=float, default=1.0)
    ap.add_argument("--compare-methods", action="store_true")
    args = ap.parse_args()

    radii = [float(x) for x in args.radii.split(",")]
    rng = np.random.default_rng(args.seed)

    if args.compare_methods:
        # FFT methods need larger amp; spatial uses amp inside compare_embed_methods
        print(f"method comparison size={args.size} radii={radii}")
        results = compare_embed_methods(
            size=args.size, radii=radii if len(radii) > 2 else [16, 24, 32, 40], rng=rng, trials_per=args.trials
        )
        # also run spatial with annulus radii
        from .ring_channel import run_channel_sweep as sweep

        for m in (16, 8):
            half = 0.5 * (360.0 / m)
            layout = RingLayout(
                size=args.size,
                radii=[28.0, 48.0],
                m=m,
                amp=0.5,
                embed_mode="spatial",
                extract_mode="spatial",
                sector_frac=0.9,
            )
            results.extend(
                sweep(
                    layout,
                    rng,
                    angles=[0.0, half, 90.0],
                    modes=("pad",),
                    patterns=("iid", "lowfreq"),
                    trials_per=args.trials,
                )
            )
        print(f"{'method':42} {'pat':7} {'ang':7} {'roll':7} {'grid':7} {'soft':9}")
        for r in results:
            print(
                f"{r.method:42} {r.pattern:7} {r.angle_deg:7.2f} "
                f"{r.aligned_ber:7.3f} {r.grid_aligned_ber:7.3f} {r.soft_agree:9.2f}"
            )
        half_rows = [r for r in results if r.pattern == "iid" and "spatial" in r.method]
        # keep only half-bin rows
        half_rows = [
            r
            for r in half_rows
            if abs(r.angle_deg - 0.5 * (360.0 / int(r.method.split("m=")[-1]))) < 1e-6
        ]
        if half_rows:
            best = min(half_rows, key=lambda r: r.grid_aligned_ber)
            print(f"best_spatial_half_bin method={best.method} gridBER={best.grid_aligned_ber:.3f}")
            decision = (
                "redesign_embedding"
                if best.grid_aligned_ber >= 0.4
                else ("compare_codes" if best.grid_aligned_ber <= 0.15 else "report_soft")
            )
            print(f"gate_decision={decision}")
        return

    layout = RingLayout(
        size=args.size,
        radii=radii,
        m=args.m,
        amp=args.amp,
        embed_mode=args.embed,  # type: ignore[arg-type]
        extract_mode=args.extract,  # type: ignore[arg-type]
        sector_frac=args.sector_frac,
        radial_half=args.radial_half,
    )
    angles = default_angles(args.m)
    print(
        f"layout size={args.size} m={args.m} radii={radii} amp={args.amp} "
        f"embed={args.embed} extract={args.extract} sector_frac={args.sector_frac}"
    )
    print(f"angles_deg={angles}")
    results = run_channel_sweep(layout, rng, angles=angles, trials_per=args.trials)
    print(f"{'pattern':8} {'mode':4} {'angle':7} {'BER':7} {'rollBER':8} {'gridBER':8} {'soft':8}")
    for r in results:
        print(
            f"{r.pattern:8} {r.mode:4} {r.angle_deg:7.2f} {r.ber:7.3f} "
            f"{r.aligned_ber:8.3f} {r.grid_aligned_ber:8.3f} {r.soft_agree:8.3f}"
        )
    decision = gate_decision(results, m=args.m, use_grid_aligned=True)
    print(f"gate_decision={decision}")
    stats = unmarked_bit_stats(layout, rng, trials=20)
    print(f"unmarked_extraction mean_bit={stats['mean_bit']:.3f} bias={stats['bias_from_half']:.3f}")
    half = 0.5 * (360.0 / args.m)
    half_rows = [
        r for r in results if r.pattern == "iid" and r.mode == "pad" and abs(r.angle_deg - half) < 1e-6
    ]
    if half_rows:
        print(
            f"half_bin gridBER={half_rows[0].grid_aligned_ber:.3f} "
            f"rollBER={half_rows[0].aligned_ber:.3f}"
        )
    if decision == "redesign_embedding":
        print("NOTE: half-bin grid BER high — redesign embedding further.")
    elif decision == "compare_codes":
        p_hat = half_rows[0].grid_aligned_ber if half_rows else float("nan")
        print(f"NOTE: channel usable — run bench_compare_codes with --p≈{p_hat:.3f}")
    else:
        print("NOTE: intermediate BER — report soft agreement alongside hard BER.")


if __name__ == "__main__":
    main()
