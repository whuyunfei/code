"""Security probes for block-circulant PRCC (Phase 1).

Probes:
  1) Fixed inputs across keys (structural false accepts)
  2) Single-sample distinguishers vs uniform
  3) Same-key multi-sample relation fitting vs fresh-key control
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np

from .block_circulant import (
    BlockCirculantKey,
    compose_flip_rate,
    cyclic_shift,
    detect,
    detect_score,
    encode,
    eta_zero_distinguisher,
    expected_syndrome_weight,
    keygen,
    q_bsc,
    suggest_tau,
    syndrome,
)


def blocks_of(y: np.ndarray, m: int) -> List[np.ndarray]:
    n = len(y)
    b = n // m
    return [y[j * m : (j + 1) * m].astype(np.uint8) for j in range(b)]


def fixed_inputs(m: int, b: int) -> Dict[str, np.ndarray]:
    n = m * b
    outs: Dict[str, np.ndarray] = {
        "all_zero": np.zeros(n, dtype=np.uint8),
        "all_one": np.ones(n, dtype=np.uint8),
        "period2": np.tile(np.array([1, 0], dtype=np.uint8), n // 2 + 1)[:n],
    }
    if m % 2 == 0:
        pat = np.zeros(m, dtype=np.uint8)
        pat[: m // 2] = 1
        outs["period_m2"] = np.tile(pat, b)
    # Single block all-ones (last block — user's example)
    for j in range(b):
        y = np.zeros(n, dtype=np.uint8)
        y[j * m : (j + 1) * m] = 1
        outs[f"block{j}_ones"] = y
    # Odd number of all-ones blocks (expected score 0 when all generators odd weight)
    y = np.zeros(n, dtype=np.uint8)
    y[(b - 1) * m :] = 1
    outs["odd_blocks_ones_last"] = y
    if b >= 3:
        y = np.zeros(n, dtype=np.uint8)
        y[0:m] = 1
        y[m : 2 * m] = 1
        y[2 * m : 3 * m] = 1
        outs["three_blocks_ones"] = y
    return outs


def probe_fixed_accepts(
    key: BlockCirculantKey,
    inputs: Optional[Dict[str, np.ndarray]] = None,
) -> Dict[str, Dict[str, float]]:
    inputs = inputs or fixed_inputs(key.m, key.b)
    out = {}
    for name, y in inputs.items():
        score = detect_score(key, y)
        out[name] = {"score": float(score), "accept": float(detect(key, y))}
    return out


def hamming_weight_frac(y: np.ndarray) -> float:
    return float(y.mean())


def block_cyclic_corr_peak(y: np.ndarray, m: int) -> float:
    """Max absolute centered cyclic correlation between consecutive blocks."""
    bl = blocks_of(y, m)
    if len(bl) < 2:
        return 0.0
    peaks = []
    for j in range(len(bl) - 1):
        a = 2 * bl[j].astype(np.float64) - 1
        b = 2 * bl[j + 1].astype(np.float64) - 1
        a = a - a.mean()
        b = b - b.mean()
        denom = (np.linalg.norm(a) * np.linalg.norm(b)) + 1e-12
        corrs = [float(np.dot(a, cyclic_shift(b, k)) / denom) for k in range(m)]
        peaks.append(max(abs(c) for c in corrs))
    return float(max(peaks))


def min_xor_shift_weight(y: np.ndarray, m: int) -> float:
    """Min Hamming weight of block_i XOR R_k(block_j) over i!=j, k, normalized by m."""
    bl = blocks_of(y, m)
    best = m + 1
    for i in range(len(bl)):
        for j in range(len(bl)):
            if i == j:
                continue
            for k in range(m):
                w = int(np.sum(bl[i] ^ cyclic_shift(bl[j], k)))
                # also complement relation (for w=1 / odd-weight structure)
                w2 = int(np.sum(bl[i] ^ (1 - cyclic_shift(bl[j], k))))
                best = min(best, w, w2)
    return best / m


def single_sample_features(y: np.ndarray, m: int, b: int, generators: Sequence[np.ndarray]) -> Dict[str, float]:
    return {
        "wt": hamming_weight_frac(y),
        "corr_peak": block_cyclic_corr_peak(y, m),
        "min_xor_shift": min_xor_shift_weight(y, m),
        "eval_at_one": float(eta_zero_distinguisher(y, m, b, generators)),
    }


def advantage(honest_vals: np.ndarray, uni_vals: np.ndarray, higher_is_honest: bool = True) -> float:
    """Simple threshold advantage: best |P(H>t)-P(U>t)| over thresholds from samples."""
    if len(honest_vals) == 0 or len(uni_vals) == 0:
        return 0.0
    thr = np.unique(np.concatenate([honest_vals, uni_vals]))
    best = 0.0
    for t in thr:
        if higher_is_honest:
            ph = float(np.mean(honest_vals >= t))
            pu = float(np.mean(uni_vals >= t))
        else:
            ph = float(np.mean(honest_vals <= t))
            pu = float(np.mean(uni_vals <= t))
        best = max(best, abs(ph - pu))
    return best


def probe_single_sample(
    key: BlockCirculantKey,
    rng: np.random.Generator,
    n_samples: int = 40,
) -> Dict[str, float]:
    honest_feats = {k: [] for k in ("wt", "corr_peak", "min_xor_shift", "eval_at_one")}
    uni_feats = {k: [] for k in honest_feats}
    n = key.b * key.m
    for _ in range(n_samples):
        c = encode(key, rng=rng)
        u = rng.integers(0, 2, size=n, dtype=np.uint8)
        fh = single_sample_features(c, key.m, key.b, key.generators)
        fu = single_sample_features(u, key.m, key.b, key.generators)
        for k in honest_feats:
            honest_feats[k].append(fh[k])
            uni_feats[k].append(fu[k])
    adv = {}
    # wt near 0.5 is uniform-like; large |wt-0.5| may distinguish low-eta
    adv["wt"] = advantage(
        np.abs(np.array(honest_feats["wt"]) - 0.5),
        np.abs(np.array(uni_feats["wt"]) - 0.5),
        higher_is_honest=True,
    )
    adv["corr_peak"] = advantage(
        np.array(honest_feats["corr_peak"]), np.array(uni_feats["corr_peak"]), True
    )
    adv["min_xor_shift"] = advantage(
        np.array(honest_feats["min_xor_shift"]), np.array(uni_feats["min_xor_shift"]), False
    )
    adv["eval_at_one"] = advantage(
        np.array(honest_feats["eval_at_one"]), np.array(uni_feats["eval_at_one"]), True
    )
    adv["max_adv"] = float(max(adv.values()))
    return adv


def fit_min_xor_relation(samples: List[np.ndarray], m: int) -> Tuple[int, int, int, int]:
    """Return (i, j, k, use_complement) minimizing mean XOR weight on training samples."""
    b = len(samples[0]) // m
    best = (0, 1, 0, 0)
    best_score = 1e9
    for i in range(b):
        for j in range(b):
            if i == j:
                continue
            for k in range(m):
                for comp in (0, 1):
                    ws = []
                    for y in samples:
                        bi = y[i * m : (i + 1) * m]
                        bj = cyclic_shift(y[j * m : (j + 1) * m], k)
                        if comp:
                            bj = 1 - bj
                        ws.append(int(np.sum(bi ^ bj)) / m)
                    sc = float(np.mean(ws))
                    if sc < best_score:
                        best_score = sc
                        best = (i, j, k, comp)
    return best


def relation_score(samples: List[np.ndarray], m: int, rel: Tuple[int, int, int, int]) -> float:
    i, j, k, comp = rel
    ws = []
    for y in samples:
        bi = y[i * m : (i + 1) * m]
        bj = cyclic_shift(y[j * m : (j + 1) * m], k)
        if comp:
            bj = 1 - bj
        ws.append(int(np.sum(bi ^ bj)) / m)
    return float(np.mean(ws))


def probe_multi_sample(
    key: BlockCirculantKey,
    rng: np.random.Generator,
    n_train: int = 20,
    n_test: int = 20,
) -> Dict[str, float]:
    train = [encode(key, rng=rng) for _ in range(n_train)]
    test = [encode(key, rng=rng) for _ in range(n_test)]
    rel = fit_min_xor_relation(train, key.m)
    score_same = relation_score(test, key.m, rel)
    # Fresh-key control encodings
    try:
        key2 = keygen(key.m, key.b, key.row_weight // key.b if key.b else 1, key.tau, key.eta, rng)
        # Use same per-block weight as original if uniform
        w = int(key.generators[0].sum())
        key2 = keygen(key.m, key.b, w, key.tau, key.eta, rng)
    except Exception:
        key2 = keygen(key.m, key.b, max(1, int(key.generators[0].sum())), key.tau, key.eta, rng)
    fresh = [encode(key2, rng=rng) for _ in range(n_test)]
    uni = [rng.integers(0, 2, size=key.b * key.m, dtype=np.uint8) for _ in range(n_test)]
    score_fresh = relation_score(fresh, key.m, rel)
    score_uni = relation_score(uni, key.m, rel)
    return {
        "rel_i": float(rel[0]),
        "rel_j": float(rel[1]),
        "rel_k": float(rel[2]),
        "rel_comp": float(rel[3]),
        "score_same_key": score_same,
        "score_fresh_key": score_fresh,
        "score_uniform": score_uni,
        "gap_vs_uniform": float(score_uni - score_same),
        "gap_vs_fresh": float(score_fresh - score_same),
    }


def block_is_near_constant(block: np.ndarray, thr: float = 0.05) -> bool:
    frac = float(block.mean())
    return frac <= thr or frac >= 1.0 - thr


def reject_near_constant_blocks(y: np.ndarray, m: int, thr: float = 0.05) -> bool:
    """Return True if y should be rejected as near-constant blocks (T_k invariant)."""
    return all(block_is_near_constant(bl, thr) for bl in blocks_of(y, m))


def detect_with_constant_reject(key: BlockCirculantKey, y: np.ndarray, thr: float = 0.05) -> bool:
    if reject_near_constant_blocks(y, key.m, thr):
        return False
    return detect(key, y)


def probe_constant_reject_fnr(
    key: BlockCirculantKey,
    rng: np.random.Generator,
    n_samples: int = 50,
    thr: float = 0.05,
) -> float:
    """Fraction of honest encodings rejected by constant-block rule."""
    rej = 0
    for _ in range(n_samples):
        c = encode(key, rng=rng)
        if reject_near_constant_blocks(c, key.m, thr):
            rej += 1
    return rej / n_samples


@dataclass
class SweepCellResult:
    m: int
    b: int
    w: int
    eta: float
    W: int
    keygen_ok: bool
    encode_coset_ok: bool
    tau: int
    fixed_accept: Dict[str, float] = field(default_factory=dict)
    single_adv: Dict[str, float] = field(default_factory=dict)
    multi: Dict[str, float] = field(default_factory=dict)
    const_reject_fnr: float = 0.0
    odd_block_ones_accept: float = 0.0
    bsc_detection: Dict[str, float] = field(default_factory=dict)
    excluded: bool = False
    exclude_reason: str = ""


def w_tiers(m: int, b: int) -> List[int]:
    """Per-block weights: low / mid / high relative to detectable gap heuristics."""
    # Keep odd weights so generators can be units when needed for A_b
    cands = [1, 3, max(3, (m // 16) | 1), max(5, (m // 8) | 1)]
    out = []
    for w in cands:
        w = min(w, m)
        if w % 2 == 0:
            w = max(1, w - 1)
        if w not in out and 1 <= w <= m:
            out.append(w)
    return out[:3]


def evaluate_cell(
    m: int,
    b: int,
    w: int,
    eta: float,
    rng: np.random.Generator,
    p_bsc: float = 0.02,
    n_keys: int = 3,
    do_multi: bool = True,
) -> SweepCellResult:
    W = b * w
    tau = suggest_tau(m, W, eta, p_bsc)
    try:
        key = keygen(m, b, w, tau, eta, rng)
        keygen_ok = True
    except Exception as e:
        return SweepCellResult(
            m=m,
            b=b,
            w=w,
            eta=eta,
            W=W,
            keygen_ok=False,
            encode_coset_ok=False,
            tau=tau,
            excluded=True,
            exclude_reason=f"keygen_fail:{e}",
        )

    # Coset check (noiseless)
    c0 = encode(key, rng=rng, add_noise=False)
    encode_coset_ok = detect_score(key, c0) == 0

    fixed_acc = {k: 0.0 for k in fixed_inputs(m, b)}
    odd_acc = 0.0
    max_adv = 0.0
    multi_gap = 0.0
    fnr = 0.0
    bsc_det = {str(p): 0.0 for p in (0.0, 0.02, 0.05)}

    for ki in range(n_keys):
        key = keygen(m, b, w, tau, eta, rng)
        fa = probe_fixed_accepts(key)
        for name, d in fa.items():
            fixed_acc[name] = fixed_acc.get(name, 0.0) + d["accept"] / n_keys
        odd_acc += fa.get("odd_blocks_ones_last", fa.get(f"block{b-1}_ones", {"accept": 0}))["accept"] / n_keys

        adv = probe_single_sample(key, rng, n_samples=30 if m <= 128 else 15)
        max_adv = max(max_adv, adv["max_adv"])

        if do_multi and not (m >= 256 and b >= 8):
            multi = probe_multi_sample(
                key, rng, n_train=12 if m <= 128 else 8, n_test=12 if m <= 128 else 8
            )
            multi_gap = max(multi_gap, multi["gap_vs_uniform"])
        fnr += probe_constant_reject_fnr(key, rng, n_samples=30) / n_keys

        for p in (0.0, 0.02, 0.05):
            ok = 0
            trials = 20 if m <= 128 else 10
            for _ in range(trials):
                c = encode(key, rng=rng)
                from .block_circulant import bsc, simultaneous_shift

                y = bsc(simultaneous_shift(c, m, int(rng.integers(0, m))), p, rng)
                ok += int(detect(key, y))
            bsc_det[str(p)] += ok / trials / n_keys

    # Exclusion rules
    excluded = False
    reason = ""
    if not encode_coset_ok:
        excluded, reason = True, "encode_coset_fail"
    elif eta == 0.0 and max_adv >= 0.3:
        excluded, reason = True, "eta0_distinguishable"
    elif b == 2 and w == 1 and (max_adv >= 0.25 or multi_gap >= 0.15):
        excluded, reason = True, "weak_b2_w1_structure"
    elif max_adv >= 0.45:
        excluded, reason = True, f"single_sample_adv={max_adv:.2f}"
    elif multi_gap >= 0.25:
        excluded, reason = True, f"multi_sample_gap={multi_gap:.2f}"

    return SweepCellResult(
        m=m,
        b=b,
        w=w,
        eta=eta,
        W=W,
        keygen_ok=keygen_ok,
        encode_coset_ok=encode_coset_ok,
        tau=tau,
        fixed_accept=fixed_acc,
        single_adv={"max_adv": max_adv},
        multi={"gap_vs_uniform": multi_gap},
        const_reject_fnr=fnr,
        odd_block_ones_accept=odd_acc,
        bsc_detection=bsc_det,
        excluded=excluded,
        exclude_reason=reason,
    )


def weight_ladder_for_gap(m: int, b: int, eta: float, p: float = 0.02) -> List[Tuple[str, int]]:
    """Pick per-block w so W is below / near / above typical detectable gap."""
    tiers = []
    for label, target_q in (("low", 0.15), ("mid", 0.28), ("high", 0.40)):
        # find odd w with q(p', b*w) closest to target
        p_eff = compose_flip_rate(eta, p)
        best_w, best_err = 1, 1e9
        for w in range(1, min(m, 21), 2):
            qq = q_bsc(p_eff, b * w)
            err = abs(qq - target_q)
            if err < best_err:
                best_err, best_w = err, w
        tiers.append((label, best_w))
    # dedup preserving order
    seen = set()
    out = []
    for lab, w in tiers:
        if w not in seen:
            seen.add(w)
            out.append((lab, w))
    return out
