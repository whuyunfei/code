"""Legacy demo for retracted full-circulant construction (shift invariance only)."""

from __future__ import annotations

import numpy as np

from .circulant_code import cyclic_shift, detect, encode, is_full_rank, keygen, verify_shift_invariance


def main() -> None:
    rng = np.random.default_rng(0)
    n, w, tau = 128, 5, 20
    key = keygen(n=n, w=w, tau=tau, eta=0.0, rng=rng)
    c = encode(key, rng=rng)
    ok, wts = verify_shift_invariance(key, c)
    print(f"n={n} w={w} tau={tau} full_rank={is_full_rank(key)}")
    print(f"syndrome wt(c)={wts[0]} shift-invariant={ok}")
    print("NOTE: full-circulant square H is retracted; use demo_block_circulant.")
    step = max(1, n // 16)
    accepts = sum(detect(key, cyclic_shift(c, k)) for k in range(0, n, step))
    print(f"Detect accepts on subsampled shifts: {accepts}/{n//step}")
    u = rng.integers(0, 2, size=n, dtype=np.uint8)
    print(f"Detect(uniform)={detect(key, u)}  (want False)")


if __name__ == "__main__":
    main()
