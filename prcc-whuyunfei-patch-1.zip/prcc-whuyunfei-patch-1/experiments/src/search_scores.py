"""Hard-syndrome scores over a residual-angle grid."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence

import numpy as np

from .block_circulant import BlockCirculantKey, detect_score
from .fast_radial import radial_soft
from .security_probes import reject_near_constant_blocks
from .spatial_multiring import MultiRingLayout


@dataclass
class AngleScores:
    per_angle: List[Optional[int]]
    best: float
    n_valid: int
    n_rejected: int
    bits_at_best: Optional[np.ndarray]


def score_bits(key: BlockCirculantKey, bits: np.ndarray, constant_reject: bool = True) -> Optional[int]:
    y = np.asarray(bits, dtype=np.uint8).reshape(-1)
    if constant_reject and reject_near_constant_blocks(y, key.m):
        return None
    return int(detect_score(key, y))


def scores_over_angles(
    key: BlockCirculantKey,
    image: np.ndarray,
    layout: MultiRingLayout,
    angles: Sequence[float],
    constant_reject: bool = True,
) -> AngleScores:
    per: List[Optional[int]] = []
    best = float("inf")
    n_valid = 0
    n_rejected = 0
    bits_at_best = None
    for ang in angles:
        soft = radial_soft(image, layout, float(ang))
        y = (soft >= 0).astype(np.uint8).reshape(-1)
        sc = score_bits(key, y, constant_reject)
        per.append(sc)
        if sc is None:
            n_rejected += 1
            continue
        n_valid += 1
        if sc < best:
            best = float(sc)
            bits_at_best = y
    if n_valid == 0:
        best = float("inf")
    return AngleScores(per, best, n_valid, n_rejected, bits_at_best)


def uniform_min_scores(
    key: BlockCirculantKey,
    rng: np.random.Generator,
    n_images: int,
    n_angles: int,
    constant_reject: bool = True,
) -> List[float]:
    """L i.i.d. uniform strings per trial; the min is the algebraic search statistic."""
    out = []
    n = key.b * key.m
    for _ in range(n_images):
        best = float("inf")
        n_valid = 0
        for _k in range(n_angles):
            y = rng.integers(0, 2, size=n, dtype=np.uint8)
            sc = score_bits(key, y, constant_reject)
            if sc is None:
                continue
            n_valid += 1
            if sc < best:
                best = float(sc)
        out.append(best if n_valid else float("inf"))
    return out
