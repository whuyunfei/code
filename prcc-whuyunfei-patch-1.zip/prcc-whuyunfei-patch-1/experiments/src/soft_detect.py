"""Calibrated bit probabilities and shift-invariant soft checks.

Hard syndrome weight, soft parity log-likelihood, and the same likelihood
after low-reliability bits are erased (probability 1/2). All three are
invariant to a simultaneous cyclic shift of the bits and their probabilities
when H is block-circulant.
"""

from __future__ import annotations

from typing import Sequence, Tuple

import numpy as np

from .block_circulant import BlockCirculantKey, detect_score, simultaneous_shift
from .security_probes import reject_near_constant_blocks


def sigmoid(z: np.ndarray) -> np.ndarray:
    z = np.clip(z, -30.0, 30.0)
    return 1.0 / (1.0 + np.exp(-z))


def fit_logistic(soft: np.ndarray, bits: np.ndarray, steps: int = 25) -> Tuple[float, float]:
    """P(bit=1 | soft) = sigmoid(a + b * soft). Fit on the calibration split only."""
    s = np.asarray(soft, dtype=np.float64).reshape(-1)
    y = np.asarray(bits, dtype=np.float64).reshape(-1)
    a, b = 0.0, 1.0
    for _ in range(steps):
        p = sigmoid(a + b * s)
        w = p * (1.0 - p) + 1e-6
        ga = float(np.sum(y - p))
        gb = float(np.sum((y - p) * s))
        haa = float(-np.sum(w))
        hab = float(-np.sum(w * s))
        hbb = float(-np.sum(w * s * s))
        det = haa * hbb - hab * hab
        if abs(det) < 1e-12:
            break
        a -= (hbb * ga - hab * gb) / det
        b -= (-hab * ga + haa * gb) / det
    return float(a), float(b)


def bit_probs(soft: np.ndarray, a: float, b: float) -> np.ndarray:
    return sigmoid(a + b * np.asarray(soft, dtype=np.float64).reshape(-1))


def erase_low_reliability(probs: np.ndarray, gamma: float) -> np.ndarray:
    p = np.asarray(probs, dtype=np.float64).copy()
    rel = np.abs(2.0 * p - 1.0)
    p[rel < gamma] = 0.5
    return p


def parity_is_one(probs: np.ndarray) -> float:
    p_one = 0.0
    for p in np.asarray(probs, dtype=np.float64):
        p_one = (1.0 - p_one) * p + p_one * (1.0 - p)
    return float(p_one)


def soft_parity_loglik(key: BlockCirculantKey, probs: np.ndarray) -> float:
    """Sum of log P(check = 1). Higher is more watermark-like. Target syndrome is 1."""
    p = np.asarray(probs, dtype=np.float64).reshape(-1)
    total = 0.0
    for i in range(key.m):
        cols = np.flatnonzero(key.H[i])
        total += float(np.log(parity_is_one(p[cols]) + 1e-12))
    return total


def hard_syndrome_weight(key: BlockCirculantKey, probs: np.ndarray) -> float:
    y = (np.asarray(probs) >= 0.5).astype(np.uint8)
    return float(detect_score(key, y))


def statistic(key: BlockCirculantKey, probs: np.ndarray, kind: str, gamma: float = 0.0) -> float:
    if kind == "hard":
        return hard_syndrome_weight(key, probs)
    if kind == "soft":
        return soft_parity_loglik(key, probs)
    if kind == "erasure":
        return soft_parity_loglik(key, erase_low_reliability(probs, gamma))
    raise ValueError(kind)


def lower_is_better(kind: str) -> bool:
    return kind == "hard"


def shift_invariant(key: BlockCirculantKey, probs: np.ndarray, kind: str, gamma: float = 0.2) -> bool:
    base = statistic(key, probs, kind, gamma)
    for k in range(key.m):
        shifted = simultaneous_shift(np.asarray(probs, dtype=np.float64), key.m, k)
        if abs(statistic(key, shifted, kind, gamma) - base) > 1e-6:
            return False
    return True


def best_over_deltas(
    key: BlockCirculantKey,
    prob_list: Sequence[np.ndarray],
    kind: str,
    gamma: float,
) -> Tuple[float, int]:
    """Return (best_score, n_valid). Constant-block hard reads are dropped."""
    lower = lower_is_better(kind)
    best = float("inf") if lower else float("-inf")
    n_valid = 0
    for probs in prob_list:
        y = (np.asarray(probs) >= 0.5).astype(np.uint8)
        if reject_near_constant_blocks(y, key.m):
            continue
        sc = statistic(key, probs, kind, gamma)
        n_valid += 1
        if lower and sc < best:
            best = sc
        elif not lower and sc > best:
            best = sc
    if n_valid == 0:
        return float("inf") if lower else float("-inf"), 0
    return best, n_valid


def passes(score: float, n_valid: int, thr: float, kind: str) -> bool:
    if n_valid <= 0 or not np.isfinite(score):
        return False
    if lower_is_better(kind):
        return score <= thr
    return score >= thr


def erasure_gamma(reliabilities: np.ndarray, quantile: float = 0.2) -> float:
    """Erase the least reliable fraction, with the cutoff fit on calibration data."""
    r = np.asarray(reliabilities, dtype=np.float64).reshape(-1)
    if len(r) == 0:
        return 0.0
    return float(np.quantile(r, quantile))
