"""Phase 4: fair compare block-circulant+residual vs PRC full-angle search.

Thresholds calibrated *after* search on unmarked images.
Reports TPR/FPR and timed stages (preprocess / search / code).
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from time import perf_counter

import numpy as np

from . import block_circulant as bc
from .prc_watermark_adapter import (
    available as prc_available,
    calibrate_threshold,
    encode_bits,
    keygen as prc_keygen,
    score_from_bits,
)
from .block_circulant import simultaneous_shift
from .residual_search import passes_lower, search_residual, shared_grids
from .security_probes import detect_with_constant_reject
from .spatial_multiring import (
    MultiRingLayout,
    center_crop_or_pad,
    default_annuli,
    embed_weak,
    extract_bits,
    extract_soft,
    load_images,
    psnr,
    rotate_pad,
    ssim_simple,
)


def prc_full_search_score(prc_key, image, layout, L: int) -> tuple[float, float]:
    """Max Detect score over m*L angles; returns (score, search_ms)."""
    Delta = 360.0 / layout.m
    step = Delta / max(L, 1)
    angles = np.arange(0.0, 360.0, step)
    t0 = perf_counter()
    best = -1e18
    for a in angles:
        bits = extract_bits(image, layout, angle_offset_deg=float(a)).reshape(-1)
        best = max(best, score_from_bits(prc_key, bits))
    return best, 1e3 * (perf_counter() - t0)


def extraction_shift_sign(image, layout, atol: float = 1e-5) -> int:
    """+1 or -1 if a one-bin angle offset equals T_k on extracted soft values.

    Returns 0 when neither direction matches (angle definition is wrong).
    """
    delta = 360.0 / layout.m
    base = extract_soft(image, layout, 0.0).reshape(-1)
    direct = extract_soft(image, layout, delta).reshape(-1)
    for sign in (1, -1):
        shifted = simultaneous_shift(base, layout.m, sign)
        if np.allclose(shifted, direct, atol=atol, rtol=1e-4):
            return sign
    return 0


def prc_reuse_search(prc_key, image, layout, L: int, sign: int):
    """One extract per residual delta, then m cyclic shifts and PRC scores.

    Returns (best_score, extract_ms, code_ms).
    """
    deltas, _angles = shared_grids(layout.m, L)
    t_ext = 0.0
    t_code = 0.0
    best = -1e18
    for d in deltas:
        t0 = perf_counter()
        bits = extract_bits(image, layout, angle_offset_deg=float(d)).reshape(-1)
        t_ext += perf_counter() - t0
        for k in range(layout.m):
            y = simultaneous_shift(bits, layout.m, sign * k)
            t1 = perf_counter()
            sc = score_from_bits(prc_key, y)
            t_code += perf_counter() - t1
            if sc > best:
                best = sc
    return best, 1e3 * t_ext, 1e3 * t_code


def reuse_matches_reextract(image, layout, L: int, sign: int) -> bool:
    """Hard bits from shift(extract(delta), sign*k) equal extract(k*Delta+delta)."""
    deltas, angles = shared_grids(layout.m, L)
    step = 360.0 / (layout.m * max(L, 1))
    cached = [
        extract_bits(image, layout, angle_offset_deg=float(d)).reshape(-1) for d in deltas
    ]
    for a in angles:
        index = int(np.round(float(a) / step)) % (layout.m * max(L, 1))
        k, d_i = divmod(index, max(L, 1))
        shifted = simultaneous_shift(cached[d_i], layout.m, sign * k)
        direct = extract_bits(image, layout, angle_offset_deg=float(a)).reshape(-1)
        if not np.array_equal(shifted, direct):
            return False
    return True


def block_residual_score(key, image, layout, L: int):
    """Filtered residual search. Score is +inf when every candidate is constant-rejected."""
    t0 = perf_counter()
    r = search_residual(key, image, layout, L, use_soft=False, constant_reject=True)
    dt = 1e3 * (perf_counter() - t0)
    return r, dt


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--images", type=str, default="data/images")
    ap.add_argument("--size", type=int, default=256)
    ap.add_argument("--n-pos", type=int, default=12)
    ap.add_argument("--n-neg", type=int, default=24)
    ap.add_argument("--m", type=int, default=8)
    ap.add_argument("--b", type=int, default=4)
    ap.add_argument("--L", type=int, default=4)
    ap.add_argument("--strength", type=float, default=0.05)
    ap.add_argument("--guard", type=float, default=0.15)
    ap.add_argument("--eta", type=float, default=0.03)
    ap.add_argument("--w", type=int, default=1)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--target-fpr", type=float, default=1e-2)
    ap.add_argument("--out", type=str, default="../figures/fair_compare.csv")
    args = ap.parse_args()

    if not prc_available():
        raise SystemExit("galois required for PRC adapter")

    rng = np.random.default_rng(args.seed)
    img_dir = Path(__file__).resolve().parents[1] / args.images
    images = load_images(img_dir, args.size, limit=max(args.n_pos, args.n_neg))
    # split pos/neg by index
    pos_imgs = images[: args.n_pos]
    neg_imgs = images[: args.n_neg]  # unmarked same pool (no watermark embed)

    m, b, L = args.m, args.b, args.L
    n = m * b
    layout = MultiRingLayout(
        args.size, default_annuli(args.size, b), m, args.guard, args.strength, mode="mean"
    )
    tau = bc.suggest_tau(m, b * args.w, args.eta, 0.20)
    block_key = bc.keygen(m, b, args.w, tau, args.eta, rng)
    prc_key = prc_keygen(n, fpr=args.target_fpr, t=3, message_length=max(4, n // 8))
    # Lower encode noise for small n
    enc, dec = prc_key.encoding_key, prc_key.decoding_key
    # rebuild with fixed noise
    from .prc_watermark_adapter import KeyGen

    enc, dec = KeyGen(n, message_length=max(4, n // 8), false_positive_rate=args.target_fpr, t=3, noise_rate=0.05, g=8, r=max(8, n // 3))
    prc_key.encoding_key, prc_key.decoding_key = enc, dec

    angles = [22.5, 15.0, 45.0, 90.0]

    # --- Calibrate on unmarked: one full search per negative image ---
    block_neg_scores = []  # syndrome scores; LOWER is more watermark-like
    prc_neg_scores = []  # PRC stats; HIGHER is more watermark-like
    block_neg_times = []
    prc_neg_times = []
    for img in neg_imgs:
        r_b, dt_b = block_residual_score(block_key, img, layout, L)
        block_neg_scores.append(r_b.best_score)
        block_neg_times.append(dt_b)
        sc_p, dt_p = prc_full_search_score(prc_key, img, layout, L)
        prc_neg_scores.append(sc_p)
        prc_neg_times.append(dt_p)

    # Block: accept if score <= thr (lower-tail quantile)
    thr_block = float(np.quantile(block_neg_scores, args.target_fpr))
    thr_prc = calibrate_threshold(np.array(prc_neg_scores), args.target_fpr)
    fpr_block = float(np.mean(np.array(block_neg_scores) <= thr_block))
    fpr_prc = float(np.mean(np.array(prc_neg_scores) >= thr_prc))

    rows = []
    for a in angles:
        block_hits = prc_hits = known_hits = 0
        block_times = []
        prc_times = []
        psnrs = []
        for img in pos_imgs:
            # Block watermark
            c = bc.encode(block_key, rng=rng)
            bits = c.reshape(b, m)
            marked = embed_weak(img, layout, bits)
            psnrs.append(psnr(img, marked))
            rot = center_crop_or_pad(rotate_pad(marked, a), args.size)
            r_b, dt_b = block_residual_score(block_key, rot, layout, L)
            block_times.append(dt_b)
            block_hits += int(passes_lower(r_b, thr_block))

            # PRC watermark (same layout)
            c2 = encode_bits(prc_key)
            bits2 = c2.reshape(b, m)
            marked2 = embed_weak(img, layout, bits2)
            rot2 = center_crop_or_pad(rotate_pad(marked2, a), args.size)
            sc_p, dt_p = prc_full_search_score(prc_key, rot2, layout, L)
            prc_times.append(dt_p)
            prc_hits += int(sc_p >= thr_prc)

            # Known-angle PRC diagnostic
            got = extract_bits(rot2, layout, angle_offset_deg=a).reshape(-1)
            known_hits += int(score_from_bits(prc_key, got) >= thr_prc)

        row = {
            "angle": a,
            "L": L,
            "target_fpr": args.target_fpr,
            "fpr_block_emp": fpr_block,
            "fpr_prc_emp": fpr_prc,
            "tpr_block": block_hits / len(pos_imgs),
            "tpr_prc_full": prc_hits / len(pos_imgs),
            "tpr_prc_known": known_hits / len(pos_imgs),
            "ms_block_med": float(np.median(block_times)),
            "ms_block_p95": float(np.percentile(block_times, 95)),
            "ms_prc_med": float(np.median(prc_times)),
            "ms_prc_p95": float(np.percentile(prc_times, 95)),
            "ms_neg_block_med": float(np.median(block_neg_times)),
            "ms_neg_prc_med": float(np.median(prc_neg_times)),
            "psnr_mean": float(np.mean(psnrs)),
            "n_pos": len(pos_imgs),
            "n_neg": len(neg_imgs),
            "candidates_block": L,
            "candidates_prc": m * L,
        }
        rows.append(row)
        print(
            f"ang={a:.1f} TPR_block={row['tpr_block']:.2f} TPR_prc={row['tpr_prc_full']:.2f} "
            f"known={row['tpr_prc_known']:.2f} ms_b={row['ms_block_med']:.1f} "
            f"ms_p={row['ms_prc_med']:.1f} FPR_b={fpr_block:.3f} FPR_p={fpr_prc:.3f}"
        )

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wri.writeheader()
        wri.writerows(rows)

    # Advantage: similar TPR and lower median time
    mean_tpr_b = float(np.mean([r["tpr_block"] for r in rows]))
    mean_tpr_p = float(np.mean([r["tpr_prc_full"] for r in rows]))
    mean_ms_b = float(np.mean([r["ms_block_med"] for r in rows]))
    mean_ms_p = float(np.mean([r["ms_prc_med"] for r in rows]))
    speedup = mean_ms_p / max(mean_ms_b, 1e-9)
    cont = (mean_tpr_b >= 0.85 * mean_tpr_p - 1e-9) and (speedup >= 1.5)
    summary = {
        "continue": cont,
        "mean_tpr_block": mean_tpr_b,
        "mean_tpr_prc": mean_tpr_p,
        "mean_ms_block": mean_ms_b,
        "mean_ms_prc": mean_ms_p,
        "speedup": speedup,
        "target_fpr": args.target_fpr,
        "emp_fpr_block": fpr_block,
        "emp_fpr_prc": fpr_prc,
        "n_neg": args.n_neg,
        "note_1e3": "n_neg too small for 1e-3; report 1e-2 only",
        "csv": str(out),
        "prc_source": "vendor/PRC-Watermark/src/prc.py (numpy+galois adapter)",
    }
    out.with_suffix(".json").write_text(json.dumps(summary, indent=2))
    print(f"wrote {out}")
    print(f"speedup≈{speedup:.1f}x continue={cont}")


if __name__ == "__main__":
    main()
