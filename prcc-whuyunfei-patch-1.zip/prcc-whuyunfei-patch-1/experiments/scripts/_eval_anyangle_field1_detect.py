#!/usr/bin/env python3
"""Detection eval for pk_ring_anyangle with FIELD=1.0 (SD full pipeline).

  python -m rotation_wm._eval_anyangle_field1_detect
  python -m rotation_wm._eval_anyangle_field1_detect --n-seeds 16
"""

from __future__ import annotations

import argparse
import json
import os
import warnings
from datetime import datetime

import numpy as np

import rotation_wm.pk_ring_anyangle as aa
from rotation_wm.key_util import load_key
from rotation_wm.pk_eval_rot import verify_after_rotate
from rotation_wm.schemes.pk_ring_anyangle import PkRingAnyangleScheme
from rotation_wm.sd_generate import generate_clean_negatives, generate_with_scheme
from stable_diffusion.schedulers import ddim_scheduler
from stable_diffusion.utils import build_stable_diffusion_pipeline, get_inference_parameter_values

aa.FIELD = 1.0

OUTPUT_ROOT = os.path.join(os.path.dirname(__file__), "output")
PROMPT = "a photo of a beautiful woman"
STEPS = 15


def _f1(tp: int, tn: int, fp: int, fn: int) -> dict:
    p = tp / max(tp + fp, 1)
    r = tp / max(tp + fn, 1)
    f1 = 0.0 if p + r == 0 else 2 * p * r / (p + r)
    return {"precision": round(p, 4), "recall": round(r, 4), "f1": round(f1, 4), "tp": tp, "tn": tn, "fp": fp, "fn": fn}


def main() -> None:
    warnings.filterwarnings("ignore")
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-seeds", type=int, default=12)
    ap.add_argument("--n-neg", type=int, default=8)
    ap.add_argument("--seed-base", type=int, default=100)
    ap.add_argument("--seed-step", type=int, default=11)
    ap.add_argument("--angle-seed", type=int, default=20261012)
    args = ap.parse_args()

    pos_seeds = [int(args.seed_base) + int(args.seed_step) * i for i in range(int(args.n_seeds))]
    rng = np.random.default_rng(int(args.angle_seed))
    seed_angles = {int(s): [float(rng.uniform(0.0, 360.0)), float(rng.uniform(0.0, 360.0))] for s in pos_seeds}

    key = load_key()
    scheme = PkRingAnyangleScheme()
    model_cache = os.path.join(os.path.dirname(os.path.dirname(__file__)), "model_cache")
    pipe, _ = build_stable_diffusion_pipeline(
        get_inference_parameter_values()["model_id"], model_cache, ddim_scheduler()[0]
    )
    scheme.bind_pipe(pipe)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = os.path.join(OUTPUT_ROOT, f"anyangle_field1_detect_{ts}")
    os.makedirs(out_dir, exist_ok=True)

    print(f"=== any-angle FIELD={aa.FIELD} detection ===", flush=True)
    neg_images = generate_clean_negatives(pipe, PROMPT, n=int(args.n_neg), seed_base=910, steps=STEPS)
    neg_peaks = [float(scheme.verify(key, img, pipe).peak) for _t, img in neg_images]
    from rotation_wm.pk_ring_anyangle import default_threshold

    floor = float(default_threshold())
    q85 = float(np.quantile(neg_peaks, 0.85)) if neg_peaks else floor
    thr = float(max(floor, q85 + 0.03))
    scheme._thr = thr

    pr = float(scheme.pseudorandom_metric(key))
    tp = tn = fp = fn = 0
    rot_ok = rot_total = 0

    for i, seed in enumerate(pos_seeds):
        wm = generate_with_scheme(scheme, pipe, key, PROMPT, seed, STEPS)
        r0 = scheme.verify(key, wm, pipe, peak_threshold=thr)
        if r0.verified:
            tp += 1
        else:
            fn += 1
        for deg in seed_angles[seed]:
            rr = verify_after_rotate(scheme, key, pipe, wm, deg, peak_threshold=thr)
            rot_total += 1
            if rr.verified:
                rot_ok += 1
        if (i + 1) % 2 == 0 or i == 0:
            print(f"  [{i+1}/{len(pos_seeds)}] seed={seed} clean={'PASS' if r0.verified else 'FAIL'} peak={r0.peak:.3f}", flush=True)

    for p in neg_peaks:
        if p >= thr:
            fp += 1
        else:
            tn += 1

    cm = _f1(tp, tn, fp, fn)
    summary = {
        "scheme": "pk_ring_anyangle",
        "field": float(aa.FIELD),
        "threshold": round(thr, 4),
        "neg_peaks": [round(p, 4) for p in neg_peaks],
        "pr": round(pr, 4),
        "pr_pass": bool(pr >= 0.99),
        **cm,
        "clean_pass": tp,
        "clean_total": len(pos_seeds),
        "clean_pass_rate": round(tp / max(len(pos_seeds), 1), 4),
        "rot_pass": rot_ok,
        "rot_total": rot_total,
        "rot_pass_rate": round(rot_ok / max(rot_total, 1), 4),
        "fpr": round(fp / max(fp + tn, 1), 4),
        "pos_seeds": pos_seeds,
    }
    path = os.path.join(out_dir, "summary.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print("\n--- FIELD=1.0 ---", flush=True)
    print(f"threshold={thr:.4f}  PR={pr:.4f}", flush=True)
    print(f"clean detect: {tp}/{len(pos_seeds)} = {100*summary['clean_pass_rate']:.1f}%", flush=True)
    print(f"rot detect:   {rot_ok}/{rot_total} = {100*summary['rot_pass_rate']:.1f}%", flush=True)
    print(f"FPR: {fp}/{fp+tn} = {100*summary['fpr']:.1f}%  F1={cm['f1']:.3f}", flush=True)
    print(f"Saved {path}", flush=True)


if __name__ == "__main__":
    main()
