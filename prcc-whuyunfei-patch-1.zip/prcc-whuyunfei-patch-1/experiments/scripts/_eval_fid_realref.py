#!/usr/bin/env python3
"""FID vs real-world reference images (Oxford-IIIT Pet test set).

Downloads reference photos, generates SD images (clean / any-angle wm), computes
clean-FID with Inception features.

  python -m rotation_wm._eval_fid_realref
  python -m rotation_wm._eval_fid_realref --n-seeds 24 --max-ref 500
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import warnings
from datetime import datetime

import numpy as np
import torch
import torchvision
import scipy.linalg

# scipy>=1.14: sqrtm no longer accepts ``disp``; clean-fid still uses legacy API.
_orig_sqrtm = scipy.linalg.sqrtm


def _sqrtm_compat(a, disp=False):
    out = _orig_sqrtm(a)
    return out if isinstance(out, tuple) else (out, None)


scipy.linalg.sqrtm = _sqrtm_compat  # noqa: E402

from cleanfid import fid
from PIL import Image

from rotation_wm.key_util import load_key
from rotation_wm.schemes.pk_ring_anyangle import PkRingAnyangleScheme
from rotation_wm.sd_generate import generate_clean, generate_with_scheme
from stable_diffusion.schedulers import ddim_scheduler
from stable_diffusion.utils import build_stable_diffusion_pipeline, get_inference_parameter_values

OUTPUT_ROOT = os.path.join(os.path.dirname(__file__), "output")
DATA_ROOT = os.path.join(os.path.dirname(__file__), "data", "fid_oxford_pet_test")
PROMPT = "a photo of a beautiful woman"
STEPS = 15


def _export_oxford_pet_test(out_dir: str, *, max_images: int) -> int:
    os.makedirs(out_dir, exist_ok=True)
    existing = [f for f in os.listdir(out_dir) if f.lower().endswith((".jpg", ".jpeg", ".png"))]
    if len(existing) >= max_images:
        return len(existing)
    root = os.path.join(os.path.dirname(__file__), "data", "oxford_pet_torchvision")
    ds = torchvision.datasets.OxfordIIITPet(
        root=root, download=True, split="test", target_types="category"
    )
    n = min(int(max_images), len(ds))
    for i in range(n):
        path = os.path.join(out_dir, f"pet_{i:05d}.jpg")
        if os.path.isfile(path):
            continue
        img, _ = ds[i]
        if isinstance(img, Image.Image):
            img.convert("RGB").save(path, quality=95)
        else:
            Image.fromarray(np.asarray(img)).convert("RGB").save(path, quality=95)
    return n


def _generate_folder(
    pipe,
    key,
    scheme,
    out_dir: str,
    seeds: list[int],
    *,
    label: str,
) -> None:
    os.makedirs(out_dir, exist_ok=True)
    for seed in seeds:
        path = os.path.join(out_dir, f"seed{seed}.png")
        if os.path.isfile(path):
            continue
        print(f"  [{label}] seed={seed}", flush=True)
        if scheme is None:
            img = generate_clean(pipe, PROMPT, seed=seed, steps=STEPS)
        else:
            img = generate_with_scheme(scheme, pipe, key, PROMPT, seed, STEPS)
        img.save(path)


def main() -> None:
    warnings.filterwarnings("ignore")
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-seeds", type=int, default=32, help="SD seeds (same for clean/wm)")
    ap.add_argument("--max-ref", type=int, default=500, help="real reference images cap")
    ap.add_argument("--seed-base", type=int, default=100)
    args = ap.parse_args()

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = os.path.join(OUTPUT_ROOT, f"fid_realref_{ts}")
    ref_dir = os.path.join(run_dir, "ref_oxford_pet")
    clean_dir = os.path.join(run_dir, "gen_clean_sd")
    wm_dir = os.path.join(run_dir, "gen_anyangle_wm")
    os.makedirs(run_dir, exist_ok=True)

    print("=== FID vs real photos (Oxford-IIIT Pet test) ===", flush=True)
    print("Downloading / caching reference images...", flush=True)
    n_ref = _export_oxford_pet_test(ref_dir, max_images=int(args.max_ref))
    print(f"Reference folder: {n_ref} images -> {ref_dir}", flush=True)

    seeds = [int(args.seed_base) + i * 11 for i in range(int(args.n_seeds))]
    key = load_key()
    scheme = PkRingAnyangleScheme()
    model_cache = os.path.join(os.path.dirname(os.path.dirname(__file__)), "model_cache")
    pipe, _ = build_stable_diffusion_pipeline(
        get_inference_parameter_values()["model_id"], model_cache, ddim_scheduler()[0]
    )

    print("Generating clean SD images...", flush=True)
    _generate_folder(pipe, key, None, clean_dir, seeds, label="clean")
    print("Generating any-angle watermarked SD images...", flush=True)
    _generate_folder(pipe, key, scheme, wm_dir, seeds, label="anyangle")

    device = "cuda" if torch.cuda.is_available() else "cpu"
    num_workers = 0 if os.name == "nt" else 4
    print(f"Computing clean-FID (device={device})...", flush=True)
    fid_clean = float(
        fid.compute_fid(
            ref_dir,
            clean_dir,
            mode="clean",
            num_workers=num_workers,
            device=device,
        )
    )
    fid_wm = float(
        fid.compute_fid(
            ref_dir,
            wm_dir,
            mode="clean",
            num_workers=num_workers,
            device=device,
        )
    )
    fid_pair = float(
        fid.compute_fid(
            clean_dir,
            wm_dir,
            mode="clean",
            num_workers=num_workers,
            device=device,
        )
    )

    summary = {
        "metric": "FID (clean-fid, Inception-v3)",
        "reference": {
            "dataset": "Oxford-IIIT Pet",
            "split": "test",
            "n_images": n_ref,
            "path": ref_dir,
            "note": "Real-world pet photographs; not paired with generations.",
        },
        "generated": {
            "prompt": PROMPT,
            "steps": STEPS,
            "n_seeds": len(seeds),
            "seeds": seeds,
            "clean_dir": clean_dir,
            "anyangle_wm_dir": wm_dir,
        },
        "fid_to_reference_lower_is_better": {
            "clean_sd": round(fid_clean, 4),
            "anyangle_wm": round(fid_wm, 4),
            "delta_wm_minus_clean": round(fid_wm - fid_clean, 4),
        },
        "fid_clean_vs_wm_lower_is_better": round(fid_pair, 4),
        "interpretation": (
            "fid_to_reference: each SD set vs real Oxford Pet test photos (domain gap if "
            "prompt is portraits). fid_clean_vs_wm: paired same-seed clean vs any-angle "
            "watermark — primary watermark distortion proxy."
        ),
    }
    out_json = os.path.join(run_dir, "fid_summary.json")
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    print("\n--- Results ---", flush=True)
    print(f"FID(clean SD  -> real pet test): {fid_clean:.4f}", flush=True)
    print(f"FID(any-angle -> real pet test): {fid_wm:.4f}", flush=True)
    print(f"Delta ref (wm - clean):        {fid_wm - fid_clean:+.4f}", flush=True)
    print(f"FID(clean SD <-> any-angle):   {fid_pair:.4f}", flush=True)
    print(f"Saved: {out_json}", flush=True)


if __name__ == "__main__":
    main()
