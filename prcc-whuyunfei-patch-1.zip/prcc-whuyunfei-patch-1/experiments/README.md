# PRCC experiments

Block-circulant zero-bit PRCC under simultaneous ring shifts \(T_k\), plus
spatial multi-ring channel and residual-angle search.

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python3 -m src.bootstrap_images   # proxy set only
python3 -m src.bootstrap_photos   # Kodak kodim01–24 → data/photos/
```

Optional: clone [PRC-Watermark](https://github.com/XuandongZhao/PRC-Watermark) to
`../vendor/PRC-Watermark` (adapter vendors KeyGen/Encode/Detect; no diffusion).

## Five-phase exploration

```bash
# Phase 1 — security probes / parameter exclusion
python3 -m src.bench_security_scan --quick --out ../figures/security_scan.csv
# notes/phase1-security-scan.md

# Phase 2 — multi-ring weak embed capacity
python3 -m src.bench_channel_capacity --quick --out ../figures/channel_capacity.csv
# notes/phase2-channel.md

# Phase 3 — residual-angle search (L candidates)
python3 -m src.bench_residual_angle --n-images 8 --out ../figures/residual_angle.csv
# notes/phase3-residual-angle.md

# Phase 4 — fair compare vs PRC-Watermark code (search-calibrated FPR)
python3 -m src.bench_fair_compare --L 4 --target-fpr 0.05 --out ../figures/fair_compare.csv
# notes/phase4-fair-compare.md

# Phase 5 — combo attacks on holdout images
python3 -m src.bench_attacks --out ../figures/attacks.csv
# notes/phase5-attacks.md

python3 -m pytest tests/ -q
```

## Low-FPR round

COCO val2017 splits are fixed in `data/coco/splits.json`. See `notes/round-low-fpr.md`.

```bash
python3 -m src.bootstrap_coco
python3 -m src.bench_score_hist
python3 -m src.bench_capacity_scan
python3 -m src.bench_integer_fpr
python3 -m src.bench_blind_angles
python3 -m src.bench_embed_trace
```

## Restructure round

Pure-code noise budget, two-row \(H\), lattice carrier. See `notes/round-restructure.md`.

```bash
python3 -m src.bench_pure_code
python3 -m src.bench_two_row
python3 -m src.bench_lattice_carrier
```

## Three metrics (lattice, ~35 dB)

PSNR ≈ 35 dB, blind-search FPR 95% upper ≤ 1%, rot+JPEG70 single-encode TPR ≥ 90%.
See `notes/round-three-metrics.md` and `figures/three_metrics.json`.

```bash
python3 -m src.bench_three_metrics
```

## Arbitrary angle / multi-key

Frozen steps; θ ~ Unif[0,360)+JPEG70; residual-δ TPR curve (grid + midpoints);
per-key calibration. See `notes/round-arbitrary-angle.md`.

```bash
python3 -m src.bench_arbitrary_angle
```

## Denser residual search

Paired L=8/16/32 on m=64,w=1,η=0 (same key, no L in seed); known-angle
control; θ=kΔ+δ. See `notes/round-dense-search.md`.

```bash
python3 -m src.bench_dense_search
```

## Center sync (half-pixel offset)

Keep-center rotation vs pad+crop; true-center oracle; blind 2-center × L=8.
See `notes/round-center-sync.md`.

```bash
python3 -m src.bench_center_sync
```

## Formal baseline C

Locked 2-center × L=8 detector; calib FPR target 0.5% with margin; full
3000/600 holdout. See `notes/round-baseline-C.md`.

```bash
python3 -m src.bench_baseline_C
```

## Performance boundary (four rounds)

See `notes/round-performance-boundary.md` and the paper outline
`notes/paper-method-experiments.md`.

```bash
python3 -m src.bench_psnr_scan
python3 -m src.coco_confirm
python3 -m src.bench_confirm_holdout --step 0.141640625
python3 -m src.bench_prc_fair_C --step 0.141640625
python3 -m src.bench_attack_boundary --step 0.141640625
python3 -m src.bench_jpeg_unified --step 0.141640625
```

## Reliable-channel round

Kodak splits: tune `01–08`, calibrate `09–16`, test `17–24`. See `notes/round-reliable-channel.md`.

```bash
python3 -m src.bench_reeval
python3 -m src.bench_reuse_timing
python3 -m src.bench_embed_compare
python3 -m src.bench_soft_detect
python3 -m src.bench_code_advantage
```

## Legacy / algebra

```bash
python3 -m src.bench_counterexample
python3 -m src.demo_block_circulant
python3 -m src.bench_ring_channel --embed spatial --m 8 --radii 28,48 --trials 4
```

## Notes

- Soundness: uniform strings + known constant-block false accepts; image FPR separate.
- Default working layout after phase 2: `m=8,b=4,strength=0.05,guard=0.15`, mean-shift.
- Residual search default: hard syndrome, `L=4`.
- Lessons: `../notes/失败尝试与经验教训.md`
