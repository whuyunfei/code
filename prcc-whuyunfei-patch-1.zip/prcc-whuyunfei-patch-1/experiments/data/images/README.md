Proxy structured images for channel experiments.
Replace with real photographs when possible; keep at least 20 files.
